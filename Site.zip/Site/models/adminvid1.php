<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 *@author Саламатов Дмитрий Викторович
 */
class StorecableModelAdminvid1 extends JModelLegacy
{
    public function getStore()
    {
        echo "SAD";
    }
}