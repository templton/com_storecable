<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 *@author Саламатов Дмитрий Викторович
 */
class StorecableModelViewfirm extends JModelList
{

//Получить данные Поставщика
    public function getSeller()
    {
       $sellerid=JRequest::getVar('sellerid');
       $makerid=JRequest::getVar('makerid');
       if ($sellerid>0){$id=$sellerid;}else{$id=$makerid;}
       $data=StoreHelper::getDataSeller(0,$id);
       /*
        //Разбить телефоны
        if (strlen($data->phone)>5){
            $data->phone=explode('|',$data->phone);   
        }else{
            unset($data->phone);
        }
        
        //Разбить мыло
        $data->email=explode('|',$data->email);
        
        //Разбить график работы
        $data->mode=explode('|',$data->mode);
        */
        
        return $data;
    }
    
}