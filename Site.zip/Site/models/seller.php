<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 *@author Саламатов Дмитрий Викторович
 */
class StorecableModelSeller extends JModelList
{
    protected $limit;
    
    function __construct() {
		  parent::__construct();
	}
    
    
//Переопределим функцию выбора данных (для получения склада поставщика)    
    protected function getListQuery()
    {
        if ($_GET['layout']=='maker'){
            //Режим оформления заявки на производство кабеля
            //Запросить список всех кабелей
            $db=JFactory::getDBO();
            //Установить кол-во позиций на одной странице
            $this->setState('list.limit','100');
            
            $query=$db->getQuery(true);
            $query->select('`a`.`id` as `cableid`, `a`.`name` as `cable`,
                        `b`.`name` as `cablekv`,
                        CONCAT_WS(" ",`a`.`name`,`b`.`name`) as `fullname`
                        ');
            $query->from('`#__store_cable` as `a`');
            $query->join('left','`#__store_cablekv` as `b` ON `b`.`id`=`a`.`cablekvid`');
        }else{
        //Запрос данных для склада
        if ($_GET['layout']=='store'){
            //Установить кол-во позиций на одной странице
            $this->setState('list.limit','30');
            
            $seller=StoreHelper::getDataSeller();
            $query=JFactory::getDBO()->getQuery( true );
            //Первым запросом выберем все нужные записи, но проиозводителя берем только id
            $queryDepth='SELECT `a`.`id` as `id`, `c`.`name` as `cable`, `a`.`count` as `count`,
                        `a`.`gost` as `gost`, `a`.`makerid` as `makerid`, 
                        `a`.`sellerid` as `sellerid`, `a`.`price` as `price`';
            $queryDepth.=',`a`.`cablesizeid` as `cablesizeid`';
            $queryDepth.=',`c`.`cablekvid` as `cablekvid`';
            $queryDepth.=' FROM `#__store_store` as `a`';
            $queryDepth.=' INNER JOIN `#__store_seller` as `b` ON `a`.`sellerid`=`b`.`id`';
            $queryDepth.=' INNER JOIN `#__store_cable` as `c` ON `a`.`cableid`=`c`.`id`';
            //$queryDepth.=' INNER JOIN `#__store_cablekv` as `e` ON `e`.`id`=`a`.`cablekvid`';
            $queryDepth.=' WHERE `a`.`sellerid`="'.StoreHelper::getDataSeller()->id.'"';
            //И окончательным запросом берем все данные из первого и дополнительно выбираем имя производителя
            $query->select('`d`.`id` as `id`,`d`.`cable` as `cable`,`d`.`count` as `count`,
                            `d`.`id`,`d`.`gost` as `gost`,`e`.`name` as `maker`,
                            `d`.`price` as `price`,
                            `d`.`cablekvid` as `cablekvid`,`d`.`cablesizeid` as `cablesizeid`,
                            `g`.`name` as `cablekv`,
                            `h`.`name` as `cablesize`
                            ');
            $query->from("(".$queryDepth.") as `d`");
            $query->join('left','`#__store_seller` as `e` ON `d`.`makerid`=`e`.`id`');
            $query->join('left','`#__store_cablekv` as `g` ON `g`.`id`=`d`.`cablekvid`');
            $query->join('left','`#__store_cablesize` as `h` ON `h`.`id`=`d`.`cablesizeid`');
        }
        }
        //echo $query;
        return $query;
    }
    
    //Получить данные Поставщика
    public function getSeller()
    {
        $data=StoreHelper::getDataSeller();
        /*
        //Разбить телефоны
        if (($data->phone)){
            $data->phone=explode('|',$data->phone);   
        }
        //Разбить мыло
        $data->email=explode('|',$data->email);
        //Разбить график работы
        $data->mode=explode('|',$data->mode);
        //Разобрать контактных лиц
        $data->face=base64_decode($data->face);
        $data->face=explode('|',$data->face);
        for ($i=0;$i<count($data->face);$i++){
            $data->face[$i]=json_decode($data->face[$i]);        
        }
        /*
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        */
        return $data;
    }
     
    
    public function getStore()
    {
        $data=StoreHelper::getStore();
        return $data;
    }
    
//
public function addOrder(){
    $cable=$_SESSION['cable'];
    if (count($cable)==0) {return;}
    
    //Подготовить список кабелей
    $cableid='';
    foreach ($cable as $item){
        $cableid.=$item['cableid'].'|';
    }
    $cableid=substr($cableid,0,strlen($cableid)-1);
    //echo $cableid;
    
    //id производителя - всегда текущий авторизованный
    $sellerid=StoreHelper::getDataSeller()->id;
    //Дата подачи заявки установится в классе таблицы
    
    $data=new stdClass();
    $data->cableid=$cableid;
    $data->sellerid=$sellerid;
    
    //Вставить заявку
    $table=$this->getTable('Store_setorder');
    $table->bind($data);
    //print_r($data);
    if ($table->check()){
        if (!$table->store()){
            echo "Ошибка записи заявки!";
        }
    }else{
        echo "Ошибка записи заявки - не пройдена проверка данных";
    }
    $insertid=$table->id;
    
    $_SESSION['orderidconfirm']=$insertid;
    
    //Вставить вложения
    /*
    for ($i=0;$i<count($_SESSION['doc']);$i++){
        $doc[$i]['filename']=$_SESSION['doc']['filename'];
        $doc[$i]['filepath']=$_SESSION['doc']['filepath'];
        $doc[$i]['description']=$_SESSION['doc']['description'];
    }
    */
    $doc=$_SESSION['doc'];
    $table=$this->getTable('Store_doc');
    
    for ($i=0;$i<count($doc);$i++){
        $doc[$i]['flag']=$insertid;
        $table->bind($doc[$i]);
        //print_r($doc);
        if ($table->check()){
            if (!$table->store()){
                echo "Ошибка записи заявки!";
            }
        }else{
            echo "Ошибка записи заявки - не пройдена проверка данных";
        }
    }
    
}

//Получить список ордеров
public function getOrders(){
    $table=$this->getTable('store_setorder');
    $data=$table->loadFull(StoreHelper::getDataSeller()->id);
    return  $data;
}    
    
    
//Получить список файлов предуставноленных баннеров
public function getPics(){
    $pics=Salam::getFilesDir(JPATH_SITE.'/images/banners/setbanners');
    for ($i=0;$i<count($pics);$i++){
        $data[$i]=new stdClass();
        $data[$i]->filename = $pics[$i];
        $data[$i]->img      = '<img src="'.JURI::base().'images/banners/setbanners/'.$pics[$i].'">';
    }
    return $data;
}    
    
    
//Получить список позиций
public function getPosition(){
    $db=JFactory::getDBO();
    $query='SELECT * FROM `#__store_position`';
    $db->setQuery($query);
    $data=$db->LoadObjectList();
    return $data;
}    
    
//Получить список заявок на баннеры
public function getBannerorders(){
    $data=StoreHelper::getBannerOrders(StoreHelper::getDataSeller()->id);
    return $data;
}    
    
    
}
