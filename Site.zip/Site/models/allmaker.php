<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 *@author Саламатов Дмитрий Викторович
 */
class StorecableModelAllmaker extends JModelList
{
    protected function getListQuery(){        
        //Параметры поиска
        $cond=StoreHelper::getSearchParam();
        $query=StoreHelper::getQuerySklad($cond);
        return $query;
    }
}