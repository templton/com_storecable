<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 *@author Саламатов Дмитрий Викторович
 */
class StorecableModelSearch extends JModelList
{
    function __construct() {
		  parent::__construct();
	}
    
    protected function getListQuery(){        
        $param=urldecode(JRequest::getVar('param'));
        $param=json_decode($param);
        for ($i=0;$i<10;$i++){
            if ($param->$i){
                $data[]=$param->$i;
            }
        }
        $cond=StoreHelper::getSearchParam();
        $cond->param=$data;
                        
        //Получить запрос
        //$query=StoreHelper::getQuerySklad($cond);
        $query=StoreHelper::getMainQuerySklad($cond);
        return $query;
    }

}