<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 *@author Саламатов Дмитрий Викторович
 */
class StorecableModelSkladmore extends JModelList
{
    //Переопределим функцию выбора данных (для получения склада поставщика)    
    protected function getListQuery(){
        $cond=StoreHelper::getSearchParam();
        $query=StoreHelper::getQuerySklad($cond);
        return $query;
    }
}