<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access

if ($_SESSION['onseller']!='1' && $_SESSION['onsklad']!='1'){
    $_SESSION['onseller']='0';
    $_SESSION['onsklad']='1';
}


?>
<div id="serachblock">
    <form method="GET" action="index.php?option=com_storecable&view=search&task=search" id="formusersearch">
        <div class="intownblock">
                <input type="text" name="intown" class="intown" id="intown" placeholder="Город поиска" value="<?php echo $_GET['intown']; ?>" />
        </div>
        <div class="searchform">
            <div class="inputpoisk">
                <input type="text" name="cable" class="cable" id="cable" placeholder="Введите макроразмер" value="<?php echo $_GET['cable']; ?>" />
            </div>
            <div class="seacrhattr">
                <div class="oncable inblock attr <?php if ($_SESSION['onsklad']=='1') {echo 'selectedattr';} ?>" onclick='setoncable()'>По наличию</div>
                <div class="onseller inblock attr <?php if ($_SESSION['onseller']=='1') {echo 'selectedattr';} ?>" onclick='setonseller()'>По производителю</div>
            </div>
        </div>
        <div class="submitblock">
            <input type="submit" value="Найти"/>
        </div>
        
    </form>
</div>
<script language="javascript">

onSeller='<?php if ($_SESSION['onseller']=='1'){echo "1";}else{echo "0";} ?>';//Искать по производителю
onSklad='<?php if ($_SESSION['onsklad']=='1'){echo "1";}else{echo "0";} ?>';//Искать по наличию

//Установить поиск по налицию
function setoncable(){
    jQuery(".oncable").addClass("selectedattr");
    jQuery(".onseller").removeClass("selectedattr");
    onSklad='1';
    onSeller='0';
    //Сразу отправим форму, если поле поиска не пустое
    if (jQuery("#cable").val()){
        jQuery("#formusersearch").submit();   
    }
    //show();
}

//Установить поиск по поставщикам
function setonseller(){
    jQuery(".oncable").removeClass("selectedattr");
    jQuery(".onseller").addClass("selectedattr");
    onSklad='0';
    onSeller='1';
    //Сразу отправим форму, если поле поиска не пустое
    if (jQuery("#cable").val()){
        jQuery("#formusersearch").submit();   
    }
    //show();
}

//Подготовка данных ку отправке
jQuery(function($){
  jQuery("#formusersearch").submit(function(e){
    //Разбить параметры поиска
    var data=[];
    var get=jQuery(".cable").val();
    //Убрать пробелы по краям
    get=get.replace(/(^ +)|( +$)/gi,'');
    //Заменить все возможные разделители на пробелы
    get=get.replace('*',' ');
    get=get.replace('-',' ');
    get=get.replace('х',' ');
    get=get.replace('x',' ');
    get=get.replace('.',',');
    //Убрать запрещенные символы
    get=get.replace('"','');
    get=get.replace("'",'');
    get=get.replace("&",'');
    get=get.replace("%",'');
    get=get.replace("$",'');
    get=get.replace("#",'');
    get=get.replace(":",'');
    get=get.replace("^",'');
    get=get.replace(";",'');
    get=get.replace("@",'');
    //Разбить строку на массив параметров
    get=get.split(' ');
    var mas='{';
    for (i=0;i<get.length;i++){
        //get[i]=get[i].replace(/(^ +)|( +$)/gi,'');
        mas+='"'+i+'":'+'"'+get[i]+'"';
        if (i!=(get.length-1)){mas+=','}
    }
    mas+='}';
    //console.log('json='+mas);
    var param='<input type="hidden" name="param" value="'+encodeURI(mas)+'">';
    //Добавить фильтры поиска   
    jQuery("#formusersearch").append(param);
    
    //В параметрах точку заменить на запятую
    
    
    /*
    var name=get.split(' ');
    console.log(name);
    //Если массив name состоит всего из одного элемента, значит, в поиске только один параметр
    //либо имя кабеля, либо макроразмер кабеля
    if (name.length==1){
        //В макроразмере не может быть букв, поэтому если в параметре есть хоть одна буква,
        //то считаем, что поиск по названию кабеля
        //иначе по макроразмеру
        var pat=/[А-ЯA-Z]/i;
        if (pat.exec(name)!=null){
            size='';   
        }else{
            var size=name[0];
            name='';
        }
    }else{
        name=name[0];
        var size=get.substr(name.length+1);
        //Если в size есть кВ, то этот параметр для cablekv
        if (/кв/i.exec(size)!=null){
            kv=size;
            size='';
        }   
        //Если в поле name нет букв, то - это макроразмер
    }
    
    
    //Убрать пробелы по краям
    size=size.replace(/(^ +)|( +$)/gi,'');
    //убрать из макроразмера всевозможные разделители
    size=size.replace('*','х');size=size.replace(' ','х');size=size.replace('-','х');size=size.replace('.',',');
    size=size.replace('"','');size=size.replace("'",'');size=size.replace(/(^ +)|( +$)/gi,'');
    //Добавить в форму отредактированые данные
    var name='<input type="hidden" name="name" value="'+name+'">';
    var size='<input type="hidden" name="size" value="'+size+'">';
    kv='<input type="hidden" name="kv" value="'+kv+'">';
    jQuery("#formusersearch").append(name);
    jQuery("#formusersearch").append(size);
    jQuery("#formusersearch").append(kv);
    
    var name='<input type="hidden" name="name" value="вв">';
    jQuery("#formusersearch").append(name);
    */
   
    //Фильтры поиска по наличию, по поставщику
    var seller='<input type="hidden" name="onseller" value="'+onSeller+'">';
    var sklad='<input type="hidden" name="onsklad" value="'+onSklad+'">';
    //Добавить фильтры поиска   
    jQuery("#formusersearch").append(seller);
    jQuery("#formusersearch").append(sklad);
    
    //Отправить сам текстовый запрос, чтобы потом его снова подставить
    var cabledata=jQuery(".cable").val();
    //Убрать служебные символы
    cabledata=cabledata.replace(/(^ +)|( +$)/gi,'');
    cabledata=cabledata.replace('"','');
    cabledata=cabledata.replace("'",'');
    cabledata='<input type="hidden" name="cabledata" value="'+cabledata+'">';
    //alert('name='+name+', size='+size+', kv='+kv);
    //alert('ok');
     
    
})  
})
</script>