//Валидация данных форм


//Проверка формы регистрации поставщика
function validateseller($data)
{
    /*
    jQuery("#registrseller").submit();   
    return;
    */
    
    var er='0';
    $data.find("input").each(function(){
        if (jQuery(this).val().length<3)
            {
                jQuery(this).addClass("red");
                alert("Не достаточная длина для: "+jQuery(this).attr("placeholder"));
                er='1';
                return false;
                
            }
    })
    if (er=='1') {return;}
    
//Проверка email
    var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
    if(!pattern.test($data.find(".email").val())){
            $data.find(".email").addClass("red");
            alert("Электронный адрес введен не корректно");
            return false;
        }
//Проверка логина на валидность
    var pattern = /^([a-z0-9_\.-])+$/i;
if(!pattern.test($data.find(".login").val())){
            $data.find(".login").addClass("red");
            alert("Запрещенные символы в логине");
            return false;
        }        
        
    
    //Проверка логина, email, ИНН
    var url=siteUrl+'/index.php?option=com_storecable&view=registrseller&task=registrseller.testloginAJAX';
    url+='&login='+$data.find("input.login").val()+"&email="+$data.find("input.email").val();
    url+='&inn='+$data.find("input.inn").val();
    //console.log(url);
    jQuery.ajax({
        url:url,
        dataType:'json',
        success:function(data){
            console.log(data);
            var login=data.login;
            var email=data.email;
            var inn=data.inn;
            var ogrn=data.ogrn;
            //return;
//Проверка логина
            if (login=='1'){
                jQuery("input.login").addClass("red");
                alert("Такой логин уже занят");
                return;
            }
//Проверка email
            if (email=='1'){
                jQuery("input.mail").addClass("red");
                alert("Адрес электронной почты уже используется");
                return;
            }
//Проверка ИНН
            if (inn=='1'){
                jQuery("input.inn").addClass("red");
                alert("ИНН уже используется");
                return;
            }
//Проверка ОГРН
            if (ogrn=='1'){
                jQuery("input.ogrn").addClass("red");
                alert("ОГРН уже используется");
                return;
            }                                                                      
//Проверка пароля
            if ($data.find("input.password").val()!=$data.find("input.password1").val()){
                jQuery("input.password").addClass("red");
                jQuery("input.password1").addClass("red");
                alert("Введенные пароли не совпадают!");
                return;        
            }  
    
        //Проверка прошла успешно
        jQuery("#registrseller").submit();   
            
        },
        error:function(){
            alert("Ошибка! Повторите попытку.");
        }
    })      
}