jQuery(document).ready(function(){
    
//все input с классом onlyint - можно вводить только числа

jQuery('.onlyint').bind("change keyup input click", function() {
    if (this.value.match(/[^0-9]/g)) {
        this.value = this.value.replace(/[^0-9]/g, '');
    }   
    
});



    
    //Все поля с классом onlychar - только символы как в логине
jQuery('.onlychar').bind("change keyup input click", function() {
    var pat=/[-\s`~!@#$%^&*()_=+\\|\[\]{};:'",.<>\/?]/;
    if (this.value.match(pat)) {
        this.value = this.value.replace(pat, '');
    }
});    

})

/*
    var pattern = /^([a-z0-9_\.-])+$/i;
if(!pattern.test($data.find(".login").val())){
            $data.find(".login").addClass("red");
            alert("Запрещенные символы в логине");
            return false;
        }  
        */
        
        
function startonlyint(){
    //все input с классом onlyint - можно вводить только числа
jQuery('.onlyint').bind("change keyup input click", function() {
    if (this.value.match(/[^0-9]/g)) {
        this.value = this.value.replace(/[^0-9]/g, '');
    }
});
}

//Проверка электронного адреса
function valid_email(el){
    var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
    if(!pattern.test(jQuery(el).val())){
            jQuery(el).addClass("red");
            alert("Электронный адрес введен не корректно");
            return '0';
        }else{
            return '1';
        }   
}        