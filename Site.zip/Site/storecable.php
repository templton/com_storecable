<?php
defined( '_JEXEC' ) or die; // No direct access
/**
 * Component storecable
 * @author Саламатов Дмитрий Викторович
 */
 
//Если папка для баннеров пользователей не существует, то добавить ее
define(USER_BANNERS_CATALOG,'userbanners');
define(PATH_USER_BANNERS, JPATH_SITE.'/images/banners/'.USER_BANNERS_CATALOG);
if (!file_exists(PATH_USER_BANNERS)){
    mkdir(PATH_USER_BANNERS);
}
//Добавить константу пути к папке баннеров пользователей
 
require_once JPATH_COMPONENT.'/helpers/storecable.php';

$doc=JFactory::getDocument();
$doc->addStyleSheet(JURI::base().'/components/com_storecable/assets/styles/storecable.css');
$doc->addScript("components/com_storecable/assets/scripts/jquery-2.2.0.min.js");
$doc->addScript("components/com_storecable/assets/scripts/helper.js");
$doc->addScript("components/com_storecable/assets/scripts/jquery.maskedinput-1.2.2.js");
$doc->addScript("/media/editors/tinymce/tinymce.min.js");

//Виджет автозавершения ввода
            $doc->addScript("components/com_storecable/assets/scripts/ui/jquery-ui.min.js");
            $doc->addStyleSheet("components/com_storecable/assets/styles/ui/jquery-ui.min.css");
//Дополнительные функции
$doc->addScriptDeclaration('var SiteUrl="'.JURI::base().'"');            

//Основной помощник
if(!class_exists('StoreHelper'))require(JPATH_COMPONENT."/helpers/helper.php");
if(!class_exists('Salam'))require(JPATH_COMPONENT."/helpers/salam.php");
if(!class_exists('StoreHelper'))require(JPATH_COMPONENT."/helpers/helperdb.php");


$controller = JControllerLegacy::getInstance( 'storecable' );
$controller->execute( JFactory::getApplication()->input->get( 'task' ) );
$controller->redirect();