<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewSeller extends JViewLegacy
{
    	/**
	 * Method of display current template
	 * @param type $tpl
	 */
	public function display( $tpl = null )
	{
	   //Вид по умолчанию - склад
       if (!$_GET['layout']){
            $_GET['layout']='store';
       }
      
       //Получить данные текущего Поставщика
       $this->seller=$this->get('Seller');
       
       //Если запрошен вид Store, то получить данные для склада
       if ($_GET['layout']=='store'){
            //Склад поставщика
            $this->items=$this->get('Items');
            $this->pagination = $this->get( 'Pagination' );
            self::prepareItems();
       }
       
       //Если запрошен maker, то получить список всех кабелей
       if ($_GET['layout']=='maker'){
            //Инициализация doc - список документов
            if (!isset($_SESSION['doc'])){
                $_SESSION['doc']=array();
                $this->doc=$_SESSION['doc'];
            }else{
                //Получить список уже загруженных документов
                $this->doc=$_SESSION['doc'];
            }
            //Инициализация cable - список кабелей
            if (!isset($_SESSION['cable'])){
                $_SESSION['cable']=array();
            }
            $this->cable=$_SESSION['cable'];
            
            
            //echo $this->getState('list.limit');
            $this->items=$this->get('Items');
            $this->pagination = $this->get( 'Pagination' );
            self::prepareItems();
            
            //Получить журнал поданных заявок
            $this->orders=$this->get('Orders');
       } 
       
       
       //Данные для страницы баннеров
       if ($_GET['layout']=='buybanner'){
            //Загрузить картинки предустановленных баннеров
            $this->pics=$this->get('Pics');
            //Получить список позиций баннеров
            $this->position=$this->get('Position');
            //Получить объект заявок
            $this->banners=$this->get('Bannerorders');
       }
       
       
       //Запрошен вид кабелей, которые я произвожу
       if ($_GET['layout']=='edituser'){
            
       }
       
            
            //echo $this->get('Item');
       
       //Подключить скрипт валидации формы
       /*
       $doc = JFactory::getDocument();
       $doc->addScriptDeclaration('var siteUrl="'.JURI::base().'"');
       $doc->addScriptDeclaration('var componentUrl="'.JURI::base().'/components/com_storecable"');
       */
		parent::display( $tpl );
	}
    
    //Подготовить список кабеля
    public function prepareItems(){
        if ($_GET['layout']=='maker'){
            //Режим оформления заявки на производство кабеля
            //Создадим из набора список чекбоксов и выбранные кабели сразу отметить
            $cable=$_SESSION['cable'];
            for ($i=0;$i<count($this->items);$i++){
                $checked='';
                $num=StoreHelper::arraySearch('cableid',$this->items[$i]->cableid,$cable);
                //echo $num."<br>";
                //echo (int)$num."<br>";
                //echo $this->items[$i]->cableid." - id<br>";
                if ((int)$num>=-1) {$checked=' checked="true" ';}
                $checkbox='<input type="checkbox" '.$checked.' name="" class="checkboxcable" id="'.$this->items[$i]->cableid.'" onchange="setList(this)" value=""><span class="checkboxlabel" id="'.$this->items[$i]->cableid.'">'.$this->items[$i]->fullname."</span>";
                $this->items[$i]->checkbox=$checkbox;
                $checked='';
            }
        }else{    
            for ($i=0;$i<count($this->items);$i++){
                $this->items[$i]->fullname=$this->items[$i]->cable.' '.$this->items[$i]->cablesize;
                if (strlen($this->items[$i]->cablekv)>0){
                    $this->items[$i]->fullname.=' - '.$this->items[$i]->cablekv;
                }
            }
        }
        /*
        echo "<pre>";
        print_r($this->items);
        echo "</pre>";
        */
    }

}