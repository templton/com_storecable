<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
?>
<div class="inblock vatop">
    <form>
        <h4>Сменить пароль</h4>
        <input type="text" name="password" placeholder="Новый пароль" />
        <br />
        <input type="submit" />
    </form>
</div>

<div class="inblock vatop kontdatablock">
    
</div>
