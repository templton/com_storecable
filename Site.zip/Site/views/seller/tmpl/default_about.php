<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
/*
echo "<pre>";
print_r($this->seller);
echo "</pre>";
*/

?>
<form action="<?php echo JRoute::_("index.php?option=com_storecable&view=seller&layout=about&task=seller.about"); ?>" method="POST" id="aboutform">
<input type="button" value="Сохранить" class="btn btn-primary" onclick="aboutformPrepare()" />
<input type="hidden" name="option" value="com_storecable" />
<input type="hidden" name="view" value="seller" />
<input type="hidden" name="layout" value="about" />
<input type="hidden" name="task" value="seller.about" />
<input type="hidden" name="sellerid" value="<?php echo $this->seller->id; ?>" />
<input type="hidden" name="icofilename" value="<?php echo $this->seller->logo; ?>" />
<input type="hidden" name="logopathserver" value="<?php echo $this->seller->logopathserver; ?>" />
</form>

<h4>Логотип</h4>
<div class="dellogoblock">
    <div class="del dellogo" onclick="deletelogo()"></div>
    <div class="dellogotext"> - удалить логотип</div>
</div>
<div class="logofirm">
    <?php if (strlen($this->seller->logo)>10) { ?>
        <img src="<?php echo $this->seller->logo; ?>" class="logoimg" />
    <?php } else { ?>
        <span class="nologo">Логотип не загружен</span>
    <?php } ?>
</div>
<input type="file"  value="Загрузить новый логотип" />

<h4>О фирме</h4>
<script type="text/javascript">
tinyMCE.init({
        mode : "textareas",
        theme : "modern",
        editor_selector : "mceAdvanced"
});
</script>
<textarea name="aboutblock" id="aboutblock" class="mceAdvanced" style="width:95%">
    <?php echo urldecode($this->seller->about); ?>
</textarea>


<script language="javascript">
//Загрузка файлов на сервер
files='';
jQuery('input[type=file]').change(function(){
    files = this.files;
    loadfiles();
});
function loadfiles(){
    var data = new FormData();
    jQuery.each( files, function( key, value ){
        data.append( key, value );
    });
    var url='index.php?option=com_storecable&task=seller.uploadfiles&uploadfiles=1&sellerid=<?php echo StoreHelper::getDataSeller()->id; ?>&desc='+jQuery(".desc").val();
    url+='&uploaddir=<?php echo JPATH_COMPONENT.'/assets/images/logos/'; ?>';
    url+='&filenameprifix=ico.seller.id'+<?php echo $this->seller->id; ?>;
    url+='&newfilename=companyico';
    console.log(url);
    jQuery.ajax({
        url:url,
        type: 'POST',
        data: data,
        cache: false,
        dataType: 'json',
        processData: false, // Не обрабатываем файлы (Don't process the files)
        contentType: false, // Так jQuery скажет серверу что это строковой запрос
        beforeSend:function(){
            //Установить иконку загрузки
            /*
            var load='<tr class="load'+loads+'"><td><div class="load"></div></td></tr>'; 
            jQuery('.loadedfiles').append(load);
            */ 
            jQuery(".logofirm").addClass("load");
            jQuery(".logofirm").html('');
        },
        success: function( respond, textStatus, jqXHR ){
            console.log(respond);
            //var loads=respond.loads;
            respond=respond.data;
            //Удалить иконку загрузки
            //jQuery('.loadedfiles .load'+loads).remove();
            // Если все ОК
 
            if( typeof respond.error === 'undefined' ){
                // Файлы успешно загружены, делаем что нибудь здесь
                jQuery(".logofirm").removeClass('load');
                var filename=SiteUrl+'components/com_storecable/assets/images/logos/'+respond.files[0].filename;
                //Вывести логотип на экран
                var img='<img src="'+filename+'?'+(new Date()).getTime()+'">';
                jQuery(".logofirm").html(img);
                //Добавить путь к логотипу на форму
                jQuery("#aboutform input[name='icofilename']").val(filename);
                jQuery("#aboutform input[name='logopathserver']").val("<?php echo JPATH_COMPONENT.'/assets/images/logos/';?>"+respond.files[0].filename);
 
                // выведем пути к загруженным файлам в блок '.ajax-respond'
                //var files_path = respond.files;
                //var files_name = respond.filesname;
                //var html = '<tr><td><div class="del"></div></td><td>';
                /*
                jQuery.each( files_path, function( key, val ){ html += val.filename+' ('+val.desc+')' +'</td></tr>'; } )
                jQuery('.loadedfiles').append( html );
                */
                
                for (var i=0;i<jQuery(respond.files).length;i++){
                    //console.log(i);
                    //respond[i].filename;
                    /*
                    html = '<tr class="trlist'+respond.files[i].num+'"><td><div class="del" onclick="removelist('+respond.files[i].num+')"></div></td><td>';
                    html += respond.files[i].filename+' ('+respond.files[i].description+')' +'</td></tr>';
                    jQuery('.loadedfiles').append( html );
                    */
                }
                
            }
            else{
                console.log('ОШИБКИ ОТВЕТА сервера: ' + respond.error );
            }
        },
        error: function( jqXHR, textStatus, errorThrown ){
            console.log('ОШИБКИ AJAX запроса: ' + textStatus );
        }
    });
}


//Подготовка формы к отправке
function aboutformPrepare(){
    //Добавить на форму текстовку о фирме
    var input='<input type="hidden" name="text" value="'+encodeURI(tinyMCE.activeEditor.getContent())+'">';
    jQuery("#aboutform").append(input);
    //console.log(input);
    //return;
    jQuery("#aboutform").submit();
    
}


//Удалить логотип
function deletelogo(){
    jQuery("#aboutform input[name='icofilename']").val('');
    jQuery(".logofirm").html('<span class="nologo">Логотип не загружен</span>');
    //Удалить файл с сервера
    var url=SiteUrl+'/index.php?option=com_storecable&task=seller.deletelogofile&sellerid=<?php echo $this->seller->id; ?>';
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            console.log(data);
            jQuery("#aboutform input[name='icofilename']").val('');
            jQuery("#aboutform input[name='logopathserver']").val('');
        },
        error:function(){
            alert("Логотип будет удален из Ваших данных. Но файл с сервера удалить не получилось");
        }
    })
}

</script>