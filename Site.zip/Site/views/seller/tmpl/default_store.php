<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
$adminparam=StoreHelper::getAllParam();
if ($adminparam->showprice=='0') {
    $style='style="display: none;"';
}else{
    $style='';
}
//echo "style=".$style."<br>";
    
?>

<script>

//Поиск марки кабеля
jQuery(function(){
    $( "#typecable" ).autocomplete({
      source: 'index.php?option=com_storecable&view=seller&task=seller.searchcable',
      select:getCableSize
    });     
})

//Поиск производителя
jQuery(function(){
    $( ".maker" ).autocomplete({
      source: 'index.php?option=com_storecable&view=seller&task=seller.searchmaker'
    });     
})

//Поиск производителя
function startmaker(){
jQuery(function(){
    $( ".maker" ).autocomplete({
      source: 'index.php?option=com_storecable&view=seller&task=seller.searchmaker'
    });     
})
}

//Первый запуск для уже созданых форм
startmaker();

//Добавить кабель
function addcable()
{
    //Нельзя вносить нулевое кол-во кабеля
    if (jQuery("#count").val()==0){
        alert("Введите кол-во кабеля в метрах!");
        return;
    }
    
    var gost=0;
    if (jQuery("#gost").prop("checked")){
        gost=1;
    }   
    var url=SiteUrl+"index.php?option=com_storecable&view=seller&task=seller.addcableJS";
    url+='&cable='+jQuery("#typecable").val()+'&cablesizeid='+jQuery(".cablesizeblock select option:selected").val();
    url+="&count="+jQuery("#count").val();
    url+="&maker="+jQuery("#maker").val();
    url+="&gost="+gost;
    url+="&price="+jQuery("#price").val();;
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            console.log(data);
            //alert(data.res.err);
            
            if (data.res.err=='1'){
                    alert(data.res.mes);
                    return;
                }else{
                    //Выставить позицию в таблицу
                    var id=data.res.id;
                    var gost='';
                    if (data.res.gost=='1'){
                        gost='ГОСТ';
                    }
                    var tr='<tr class="id'+id+'" style="color: red;">';
                    tr+='<td>*</td>';
                    tr+='<td name="cable">'+data.res.fullname+'</td>';
                    tr+='<td name="count">'+data.res.count+'</td>';
                    tr+='<td name="price" <?php echo $style; ?> >'+data.res.price+'</td>';
                    tr+='<td name="gost">'+gost+'</td>';
                    tr+='<td name="maker">'+data.res.maker+'</td>';
                    tr+='<td name="edit"><div class="edit" onclick="aditcable('+"'"+id+"'"+')"></div></td>';
                    tr+='<td name="del"><div class="del" onclick="delcable('+"'"+id+"'"+')"></div></td>';
                    tr+='</tr>';
                    jQuery(tr).insertAfter("table.res tbody tr:first");
                    //console.log(tr);
    
                    //alert("Кабель успешно добавлен на склад.");
                    jQuery(".messageblock").html("Кабель успешно добавлен на склад.");
                }
        },
        error:function(){
            alert("Не удалось добавить кабель. Мы уже работаем над устранением ошибки.");
        }
    })
}

//Удалить кабель со склада
function delcable(id)
{
    var url=SiteUrl+"index.php?option=com_storecable&task=seller.deletecable&id="+id;
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            //console.log(data);
            jQuery("table.res tr.id"+id).remove();
        }
    })
}

//Подготовить поля для редактирования кабеля
function aditcable(id){
    //Подготовить для редактирование Поставщика
    var maker=jQuery("table.res tr.id"+id+" td[name=maker]").text();
    var field='<input type="text" name="maker" class="maker" value='+"'"+maker+"'"+'>';
    jQuery("table.res tr.id"+id+" td[name=maker]").html(field);
    startmaker();
    //Подготовить для редактирования поле кол-ва
    var count=jQuery("table.res tr.id"+id+" td[name=count]").text();
    var field='<input type="text" name="count" class="count onlyint" value='+"'"+count+"'"+'>';
    jQuery("table.res tr.id"+id+" td[name=count]").html(field);
    
    //Подготовить поле цены
    var price=jQuery("table.res tr.id"+id+" td[name=price]").text();
    var field='<input type="text" name="price" class="price onlyint" value='+"'"+price+"'"+'>';
    jQuery("table.res tr.id"+id+" td[name=price]").html(field);
    
    //Подготовить для редактирования checkbox ГОСТ
    var gost;
    if (jQuery("table.res tr.id"+id+" td[name=gost]").attr("gost")=='1'){
        gost="CHECKED";
    }
    gost='<input type="checkbox" name="gost" '+gost+' >';
    jQuery("table.res tr.id"+id+" td[name=gost]").html(gost);
    //Сменить иконку редактирования на кнопку
    var button='<input type="button" onclick="editcableStart('+"'"+id+"'"+')" value="Изменить">';
    jQuery("table.res tr.id"+id+" td[name=edit]").html(button);
    
    //Старт функции ограничения ввода - только целые числа
    startonlyint();
}

//Внести изменения по кабелю на складе Поставщика
function editcableStart(id){
   //Нельзя вносить нулевое кол-во кабеля
   $tr=jQuery("table.res tr.id"+id);
   $count=$tr.find("td[name=count] input");
   $price=$tr.find("td[name=price] input");
   $gost=$tr.find("td[name=gost] input");
   $maker=$tr.find("td[name=maker] input");
    if ($count.val()==0){
        $count.addClass("red");
        alert("Введите кол-во кабеля в метрах!");
        return;
    }
    
    var gost=0;
    console.log($gost);
    if ($gost.prop("checked")){
        gost=1;
    }   
    var url=SiteUrl+"index.php?option=com_storecable&task=seller.addcableJS&edit=1";
    url+="&count="+$count.val();
    url+="&maker="+$maker.val();
    url+="&gost="+gost;
    url+="&id="+id;
    url+="&price="+$price.val();
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            console.log(data);
            if (data.res.err=='1'){
                alert(data.res.mes);
                return;
            }
            //Убираем формы редактирования и кнопку
                //кол-во
            var count=jQuery("table.res tr.id"+id+" td[name=count] input").val();
            jQuery("table.res tr.id"+id+" td[name=count]").html(count);
                //Цена
            var price=jQuery("table.res tr.id"+id+" td[name=price] input").val();
            jQuery("table.res tr.id"+id+" td[name=price]").html(price);
                //Производитель
            var maker=jQuery("table.res tr.id"+id+" td[name=maker] input").val();
            jQuery("table.res tr.id"+id+" td[name=maker]").html(maker);
                //ГОСТ
            var text='';
            if (jQuery("table.res tr.id"+id+" td[name=gost] input").prop("checked"))
            {
                text='ГОСТ';
            }
            jQuery("table.res tr.id"+id+" td[name=gost]").html(text);
                //Кнопка
            var ico='<div class="edit" onclick="aditcable('+"'"+id+"'"+')"></div>';
            jQuery("table.res tr.id"+id+" td[name=edit]").html(ico);
        },
        error:function(){
            alert("Не получилось обновить позицию. Мы уже работаем над этой ошибкой.");
        }
    })
}

//Пагинация для первой страницы
jQuery(document).ready(function(){
    var href;
    jQuery("div.pagination ul.pagination-list a").each(function(){
        if (href=jQuery(this).attr("href")){
            //console.log(href);
            //console.log(href.indexOf('start'));
            if (href.indexOf('start')=='-1'){
                href+='&start=1';
                jQuery(this).attr('href',href);
            }   
        }
    })
})

//Подставить макроразмер
function getCableSize(event, ui){
    var cable=ui.item.label;
    var url=SiteUrl+'index.php?option=com_storecable&task=seller.getsizeselect&cable='+cable;
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            //console.log(data);
            jQuery(".cablesizeblock").html(data.select);
        },
        error: function(){
            alert("Ошибка получения маркроразмеров кабеля. Мы уже работаем над устранением этой ошибки.");
        }
    })
}


</script>

<h4>Добавить новый кабель на склад:</h4>
<div class="messageblock"></div>
<form>
    <table>
        <tr>
            <th>Марка кабеля</th>
            <th>Макроразмер</th>
            <th>Кол-во</th>
            <th>Производитель</th>
            <th>ГОСТ</th>
            <th <?php echo $style; ?> >Цена</th>
            <th></th>
        </tr>
        <tr>
            <td>
                <input type="text" name="typecable" id="typecable" class="typecable" placeholder="Введите первые буквы" />   
            </td>
            <td>
                <div class="cablesizeblock"></div>
            </td>
            <td>
                <input type="text" name="count" id="count" class="count onlyint" />
            </td>
            <td>
                <input type="text" name="maker" id="maker" class="maker" placeholder="Наименование производителя" />
                
            </td>
            <td>
                <input type="checkbox" name="gost" id="gost" class="gost" value="1" />
            </td>
            <td <?php echo $style; ?>>
                <input type="text" name="price" id="price" class="price onlyint" />
            </td>
        </tr>
        <tr>
            <td colspan="5">
                <input type="button" value="Добавить" onclick="addcable()" />
            </td>
        </tr>
    </table>
</form>

<!-- Склад поставщика -->
<div id="storesellerblock">

<table class="res">
    <tr>
        <th>№</th>
        <th>Кабель</th>
        <th>Кол-во</th>
        <th <?php echo $style; ?> >Цена</th>
        <th>Гост</th>
        <th>Производитель</th>
        <th></th>
        <th></th>
    </tr>
<?php
    $count=1;
    foreach ($this->items as $item)
    {
        $gost='';
        if ($item->gost=='1'){
            $gost='ГОСТ';
        }
        echo '<tr class="id'.$item->id.'">';
        echo '<td>'.$count.'</td>';
        echo '<td name="cable">'.$item->fullname.'</td>';
        echo '<td name="count">'.$item->count.'</td>';
        echo '<td name="price" '.$style.'>'.$item->price.'</td>';
        echo '<td name="gost" gost="'.$item->gost.'">'.$gost.'</td>';
        echo '<td name="maker">'.$item->maker.'</td>';
        echo '<td name="edit"><div class="edit" onclick="aditcable('."'".$item->id."'".')"></div></td>';
        echo '<td name="del"><div class="del" onclick="delcable('."'".$item->id."'".')"></div></td>';
        echo "</tr>";
        $count++;
    }
?>    
</table>
</div><!-- Конец склада поставщика -->
<?php
    echo $this->pagination->getPagesCounter();
    echo $this->pagination->getListFooter();
?>
