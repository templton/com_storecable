<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access

unset($menu);
$menu[0]['title']='Моя компания';
$menu[0]['layout']='edituser';
/*
$menu[1]['title']='Филиалы';
$menu[1]['layout']='filials';
*/
$menu[1]['title']='Склад';
$menu[1]['layout']='store';
/*
$menu[2]['title']='Учетная запись';
$menu[2]['layout']='geristration';
*/
$menu[3]['title']='Заказать баннер';
$menu[3]['layout']='buybanner';

$menu[4]['title']='Мое производство';
$menu[4]['layout']='maker';

$menu[5]['title']='О фирме';
$menu[5]['layout']='about';

?>
<div class="mainblock">

<div class="menublock">
    <ul class="sellermenu menu">
        <?php
            unset($list);
            foreach ($menu as $item)
            {
                $list.='<li>';
                if ($_GET['layout']==$item['layout']){
                    $list.='<span class="currentitem">'.$item['title'].'</span>';    
                }
                else{
                    //Для пагинации добавить start=1
                    $list.='<a href="'.JRoute::_("index.php?start=1&option=com_storecable&view=seller&layout=".$item['layout']).'">'.$item['title'].'</a>';
                }
                $list.='</li>';
            }
            echo $list;
        ?>
    </ul>
</div>

<?php
if ($_GET['layout'])
{
 echo $this->loadTemplate($_GET['layout']);   
}
?>

</div>