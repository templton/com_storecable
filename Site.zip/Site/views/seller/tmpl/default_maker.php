<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access

/*
$doc=$_SESSION['doc'];
$num=count($doc);
$doc[$num]['file']="file";
$doc[$num]['path']="path";
$_SESSION['doc']=$doc;
*/
//unset($_SESSION['cable']);
/*
echo "<pre>";
print_r($_SESSION['cable']);
echo "</pre>";
*/
/*
echo "<pre>";
print_r($this->orders);
echo "</pre>";
*/

/*
echo "<pre>";
print_r($this->SESSION['cable']);
echo "</pre>";
*/
//unset($_SESSION['cable']);
/*
$cable=$_SESSION['cable'];
unset($cable[0]);
$_SESSION['cable']=$cable;
*/


?>
<div class="messageblock">
    <div class="closeblock"></div>
    <?php echo $_SESSION['ermes']; ?>
</div>
<script language="javascript">
jQuery(".closeblock").bind("click",function(){
    jQuery(".messageblock").remove();
}) 
</script>
<input type="button" class="btn btn-info" data-toggle="collapse" data-target="#toggleSample" value="Помощь">
<input type="button" class="btn btn-info btnorders" data-toggle="collapse" data-target="#orders" value="Статус заявок">
<div id="toggleSample" class="collapse">
{article <?php echo StoreHelper::getParam('helpmakerid'); ?>}[text]{/article}
</div>

<div id="orders" class="collapse">
    <table class="res">
        <tr>
            <th>Дата</th>
            <th>Список позиций</th>
            <th>Загруженные файлы</th>
            <th>Статус</th>
            <th>Примечание</th>
        </tr>
        <?php $countpos=0; ?>
        <?php foreach ($this->orders as $order){ ?>
            <tr>
                <td><?php echo $order->datesend; ?></td>
                <td>
                    <div>Всего: <?php echo count($order->cables); ?></div>
                    <input type="button" class="btn default" data-toggle="collapse" data-target="#cables<?php echo $countpos; ?>" value="Показать" />
                    <div id="cables<?php echo $countpos; $countpos++; ?>" class="collapse">
                    <?php
                        foreach ($order->cables as $cab){
                            echo $cab->cable."<br>";     
                        } 
                    ?>
                    </div>
                </td>
                <td>
                    <?php if (count($order->doc)>0) {?>
                    <div>Всего: <?php echo count($order->doc); ?></div>
                    <input type="button" class="btn default" data-toggle="collapse" data-target="#docs<?php echo $countpos; ?>" value="Показать" />
                    <div id="docs<?php echo $countpos; $countpos++; ?>" class="collapse">
                    <?php foreach ($order->doc as $doc){ ?>
                        <a href="<?php echo JUri::base().'components/com_storecable/files/'.$doc->filename; ?>" download  >
                            <?php 
                                echo $doc->filename;
                                if (strlen($doc->description)>0){
                                    echo ' ('.$doc->description.')';
                                } 
                            ?>
                        </a><br />
                    <?php } ?>
                    </div>
                    <?php } else { ?>
                    Нет загруженных документов
                    <?php } ?>
                </td>
                
                <td>
                    <?php
                        if ($order->status=='0') {echo "На рассмотрении";}
                        if ($order->status=='1') {echo "Заявка одобрена";}
                        if ($order->status=='-1') {echo '<span class="errortext">Отказано</span>';}
                    ?>                    
                </td>
                <td>
                    <?php
                        if (strlen($order->description)>0){
                            echo $order->description;   
                        }
                    ?>
                </td>
            </tr>
        <?php } ?> 
    </table>
</div>


<div id="contentblock">
    <div class="confirmblock">
        <form method="POST" action="index.php?option=com_store&view=seller&layout=maker&task=seller.addorder" id="formseller">
            <input type="button" class="btn btn-primary" value="Оформить заявку" onclick="prepform()" />
            <input type="hidden" name="option" value="com_storecable" />
            <input type="hidden" name="view" value="seller" />
            <input type="hidden" name="layout" value="maker" />
            <input type="hidden" name="task" value="seller.addorder" />
            <input type="hidden" name="token" value="<?php echo StoreHelper::getToken('token'); ?>" />
        </form>
    </div>
    
    <div class="searchcableblock">
        <input type="text" name="typecable" id="typecable" class="typecable ui-autocomplete-input" placeholder="Введите первые буквы" autocomplete="off">
    </div>
    
    <div class="listcable">
        <div class="headblock">Выбор кабеля</div>
        <div>
        <table>
            <tr>
                <th><input type="checkbox" class="" onchange="setAll()" /></th>
                <th> - выбрать все</th>
            </tr>
                <?php foreach ($this->items as $cable) { ?>
                    <tr>
                        <td colspan="2"><?php echo $cable->checkbox; ?></td>
                    </tr>
                <?php } ?>
        </table>
        </div>
    </div>
    
    <div class="listdoc">
        <div class="headblock">Документы</div>
        <div>
            <form>
                <input type="file" multiple="multiple" />
                <br />
                <input type="text" class="desc" placeholder="Описание" />
                <br />
                <input type="button" value="Загрузить" onclick="loadfiles()" />
            </form>
            <div>
                <!-- Загруженные файлы -->
                <table class="loadedfiles">
                    <?php 
                        if (count($this->doc)>0) {
                            $count=0;
                    ?>
                    <?php 
                        foreach ($this->doc as $doc){
                            if (strlen($doc['filename'])>1) {
                    ?>
                        <tr class="trlist<?php echo $count; ?>">
                            <td><div class="del" onclick="removelist(<?php echo $count; ?>)"></div></td>
                            <td><?php echo $doc['filename'].' ('.stripcslashes($doc['description']).')'; ?></td>
                        </tr>
                    <?php
                        }
                        $count++; 
                        } //конец foreach 
                    ?>
                    <?php } //конец if ?>
                </table>
            </div>
            <div class="ajax-respond">
            </div>
        </div>
    </div>
    
    <div class="listresult">
        <div class="headblock">Отобранные позиции</div>
        <div>
            Всего: <span class="all"><?php echo count($this->cable); ?></span>
            <hr />
        </div>
        <?php
                foreach($this->cable as $cable){
                    //print_r($cable);
                    ?>
                    <div class="delplus" id="<?php echo $cable['cableid']; ?>" onclick="deleteList(<?php echo $cable['cableid']; ?>)"><?php echo $cable['cable']; ?></div>
                    <?php
                }
            ?>
    </div>
    <div class="confirmblock">
        <?php
            echo $this->pagination->getListFooter();
        ?>
    </div>
</div>

<script lang="javascript">
loads=0;//счетчик загрузок
//Пагинация для первой страницы
jQuery(document).ready(function(){
    var href;
    jQuery("div.pagination ul.pagination-list a").each(function(){
        if (href=jQuery(this).attr("href")){
            //console.log(href);
            //console.log(href.indexOf('start'));
            if (href.indexOf('start')=='-1'){
                href+='&start=1';
                jQuery(this).attr('href',href);
            }   
        }
    })
})

//Загрузка файлов на сервер
files='';
jQuery('input[type=file]').change(function(){
    files = this.files;
});
function loadfiles(){
    var data = new FormData();
    jQuery.each( files, function( key, value ){
        data.append( key, value );
    });
    loads++;
    jQuery.ajax({
        url: 'index.php?option=com_storecable&task=seller.uploadfiles&uploadfiles=1&sellerid=<?php echo StoreHelper::getDataSeller()->id; ?>&desc='+jQuery(".desc").val()+'&loads='+loads,
        type: 'POST',
        data: data,
        cache: false,
        dataType: 'json',
        processData: false, // Не обрабатываем файлы (Don't process the files)
        contentType: false, // Так jQuery скажет серверу что это строковой запрос
        beforeSend:function(){
            //Установить иконку загрузки
            var load='<tr class="load'+loads+'"><td><div class="load"></div></td></tr>'; 
            jQuery('.loadedfiles').append(load); 
        },
        success: function( respond, textStatus, jqXHR ){
            console.log(respond);
            var loads=respond.loads;
            respond=respond.data;
            //Удалить иконку загрузки
            jQuery('.loadedfiles .load'+loads).remove();
            // Если все ОК
 
            if( typeof respond.error === 'undefined' ){
                // Файлы успешно загружены, делаем что нибудь здесь
 
                // выведем пути к загруженным файлам в блок '.ajax-respond'
                //var files_path = respond.files;
                //var files_name = respond.filesname;
                var html = '<tr><td><div class="del"></div></td><td>';
                /*
                jQuery.each( files_path, function( key, val ){ html += val.filename+' ('+val.desc+')' +'</td></tr>'; } )
                jQuery('.loadedfiles').append( html );
                */
                
                for (var i=0;i<jQuery(respond.files).length;i++){
                    //console.log(i);
                    //respond[i].filename;
                    html = '<tr class="trlist'+respond.files[i].num+'"><td><div class="del" onclick="removelist('+respond.files[i].num+')"></div></td><td>';
                    html += respond.files[i].filename+' ('+respond.files[i].description+')' +'</td></tr>';
                    jQuery('.loadedfiles').append( html );
                }
                
            }
            else{
                console.log('ОШИБКИ ОТВЕТА сервера: ' + respond.error );
            }
        },
        error: function( jqXHR, textStatus, errorThrown ){
            console.log('ОШИБКИ AJAX запроса: ' + textStatus );
        }
    });
}


//Удалить загруженный файл
function removelist(num){
    //Удалить из списка
    jQuery("tr.trlist"+num).remove();
    //Запрос на удаление с сервера
    var url="index.php?option=com_storecable&task=seller.deletefile&num="+num;
    //console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        type:"get",
        success:function(data,textStatus,jqXHR){
            //console.log(data);
            if (data.error=='1'){
                alert("Не получилось удалить файл. Обновите страницу и повторите попытку.");
            }
        },
        error:function(jqXHR,textStatus,errorThrown){
            alert("Не получилось отправить или обработать запрос");
            console.log("Ошибка AJAX: "+textStatus);
        }
    })
}

//Изменение состояния checkbox
function setList($data){
    var id;
    //Если элемент всего один, то обернем его в массив
    if (jQuery($data).length==1){
        $data[0]=$data;   
    }
    //Пройтись по всем элементам массива
    for (i=0;i<jQuery($data).length;i++){
        id=jQuery($data[i]).attr("id");
        if (jQuery('.listcable input[id="'+id+'"]').attr("checked")){
            //создать элемент
            var $el='<div class="delplus" id="'+id+'" onclick="deleteList('+id+')">'+jQuery("span[id='"+id+"']").html()+'</div>';
            //Добавить поизицию в список
            jQuery(".listresult").append(jQuery($el));
        }else{
            //Удалить позициюю из списка
            jQuery('.listresult div[id="'+id+'"]').remove();
            //deleteFromOrder(id);
        }
    }
    addToOrder($data);
    updatecount();
}

//Удалить кабель из сессии
function deleteFromOrder(id, data=0){
        //Удалить из сессии
        var url="index.php?option=com_storecable&task=seller.deleteCableFromOrder&cableid="+id;
        console.log(url);
        jQuery.ajax({
            url:url,
            dataType:"json",
            success:function(data){
                console.log(data);
            },
            error:function(jqXHR,textStatus,errorThrown){
                alert("Не получилось отправить запрос");
                console.log(textStatus);
            }
        });
}


//Добавить позиции в сессию
function addToOrder($data){
    //Подготовить данные к отправке.
    //data[i]['cable']
    //data[i]['cableid']
    //data[i]['set']=1(добавить), =0(удалить)    
    var i,id;
    var cable=new Array();
    //var data='({';
    var data='|';
    var tt,val;
    for (i=0;i<jQuery($data).length;i++){
        cable[i]=new Array();
        id=jQuery($data[i]).attr('id');
        cable[i]['cable']=jQuery('.listcable span[id="'+id+'"]').html();
        cable[i]['cableid']=id;
        if (jQuery($data[i]).attr("checked")){
            cable[i]['set']='1';
        }else{
            cable[i]['set']='0';
        }
        //Объединить запрос в строку (на сервере разобъем по маске)
        data+=cable[i]['cable']+'#'+cable[i]['cableid']+'#'+cable[i]['set']+'|';        
    }
    data=({data:data});
    var url="index.php?option=com_storecable&task=seller.addCableIntoOrder";
    console.log(url);
    //Добавить в сессию
    jQuery.ajax({
        url:url,
        type:"POST",
        dataType:"json",
        data:data,
        success:function(data){
            console.log(data);
        },
        error:function(jqXHR,textStatus,errorThrown){
            alert("Не получилось отправить запрос");
            console.log(textStatus);
        }
    });
     
}

//Удалить позицию из списка и снять основной checkbox, если он присутствует на экране
function deleteList(id)
{
    //Удалить позицию из списка
    jQuery('.listresult div[id="'+id+'"]').remove();
    jQuery('.listcable input[id="'+id+'"]').removeAttr("checked");
    updatecount();
    deleteFromOrder(id);
}


//Сделать инверсию выбора списка
function setAll(){
    var data=new Array();
    jQuery(".listcable .checkboxcable").each(function(){
        if (jQuery(this).attr("checked")){
            jQuery(this).removeAttr("checked");
        }else{
            jQuery(this).attr("checked","true");   
        }
        data.push(jQuery(this));
    })
    setList(data);
    updatecount();
}

//Обновить счетчик кол-ва выбранных позиций
function updatecount(){
    var count=jQuery(".listresult div[id]").length;
    jQuery(".all").html(count);
}

//Подготовка формы к отправке
function prepform(){
    //Проверить, чтобы был хотя бы один загруженный документ
    if (jQuery("table.loadedfiles tr").length==0){
        alert("Вам необходимо загрузить документы, подтверждающие статус Производителя");
        return false;
    }
    //Проверить,  чтобы был выбран хотя бы один кабель
    if (jQuery(".delplus").length==0){
        alert("Вы не выбрали ни одну позицию. Заявка пуста");
        return false;
    }
    
    jQuery("#formseller").submit();
}

//Поиск марки кабеля
jQuery(function(){
    $( "#typecable" ).autocomplete({
      source: 'index.php?option=com_storecable&view=seller&task=seller.searchcable',
      select:insertCable
    });     
})

//Вставить кабель из поля быстрого поиска
//Подставить макроразмер
function insertCable(event, ui){
    var cable=ui.item.label;
    var id;
    //Выяснить id кабеля
    var url=SiteUrl+'index.php?option=com_storecable&task=seller.getcableid&cable='+cable;
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            console.log(data);
            id=data.id;
            var tr='<tr><td colspan="2">';
            tr+='<input type="checkbox" name="" class="checkboxcable" id="'+id+'" onchange="setList(this)" value="">';
            tr+='<span class="checkboxlabel" id="'+id+'">'+cable+'</span>';
            tr+='</td></tr>';
            jQuery(".listcable table tbody").prepend(tr);
            jQuery(".listcable input[id='"+id+"']").first().click();
            console.log(jQuery(".listcable input[id='"+id+"']"));
        },
        error:function(){
            alert("Ошибка запроса");
        }
    })
}

</script>