<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
?>
<h4>Заказать баннер</h4>
<?php
$data=file_get_contents(JURI::base().'index.php?option=com_content&view=article&id=1');
//echo $data;
?>
<input type="button" class="btn default" data-toggle="collapse" data-target="#helpbanner" value="Помощь">
<input type="button" class="btn default" data-toggle="collapse" data-target="#bannerorders" value="Мои заявки">
<input type="button" class="btn btn-primary" data-toggle="collapse" value="Заказать" onclick="ordersend();">

<!-- Помощь, как заказать баннер -->
<div class="collapse" id="helpbanner">
{article <?php echo StoreHelper::getParam('helpbannerid'); ?>}[text]{/article}
</div>

<!-- История заявок -->
<div id="bannerorders" class="collapse">
    <table class="res">
        <tr>
            <th></th>
            <th>ID</th>
            <th>Дата заявки</th>
            <th>Период размещения (дней)</th>
            <th>Дата активации</th>
            <th>Дата завершения</th>
            <th>Позиция</th>
            <th>Баннер</th>
            <th>Статус</th>
            <th>Примечание</th>
        </tr>
        <?php foreach ($this->banners as $banner) { ?>
            <tr class="banner<?php echo $banner->bannerid; ?>">
                <td><div class="del" onclick='deleteorder(<?php echo $banner->bannerid; ?>)'></div></td>
                <td><?php echo $banner->bannerid; ?></td>
                <td><?php echo $banner->dateorder; ?></td>
                <td><?php echo $banner->period/3600/24; ?></td>
                <td>
                    <?php
                        if (strtotime($banner->datebegin)>0){
                            echo date('d-m-Y', strtotime($banner->datebegin));
                        }
                    ?>
                </td>
                <td>
                    <?php
                        if (strtotime($banner->dateend)>0){
                            echo date('d-m-Y', strtotime($banner->dateend));
                        }
                    ?>
                </td>
                <td><?php echo $banner->position; ?></td>
                <td><a href="<?php echo $banner->bannerpath; ?>"><img src="<?php echo $banner->bannerpath; ?>" class="smallbanner"></a></a></td>
                <td <?php if ($banner->status=='-1'){echo 'class=".errortext"';} ?>>
                    <?php
                        if ($banner->status=='-1'){echo "Отказ";}
                        if ($banner->status=='0'){echo "В работе";}
                        if ($banner->status=='1'){echo "Одобрено";}
                     ?>
                </td>
                <td>
                    <?php echo $banner->description; ?>
                </td>
            </tr>
        <?php } ?>
    </table>
</div>

<!-- Выбор готового баннера -->
<div id="modalPics" class="modal fade" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title">Предуставноленные баннеры</h4>
      </div>
      <div class="modal-body">
        <?php foreach ($this->pics as $pic){ ?>
            <div onclick='setimg("<?php echo $pic->filename; ?>")' class="picblock"><?php echo $pic->img; ?></div>
        <?php } ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="closemodal">Отмена</button>
      </div>
    </div>
  </div>
</div>




<div class="setbannerorder">
    <form action="index.php?option=com_storecable&view=seller&layout=buybanner&task=seller.buybanner" id="bannerFrom">
        <table>
            <tr>
                <td>Позиция баннера: </td>
                <td>
                    <select name="bannerposition">
                        <?php foreach ($this->position as $position) { ?>
                            <option value="<?php echo $position->id; ?>"><?php echo $position->title; ?></option>
                        <?php } ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Срок размещения: </td>
                <td>
                    <input type="text" name="bannercount" placeholder="Кол-во" class="onlyint" />
                    <select name="bannerperiod" placeholder="Период">
                        <option value="week" selected="true">Неделя</option>
                        <option value="month">Месяц</option>
                    </select>
                </td>
            </tr>
        <input type="hidden" name="sellerid" value="<?php echo $this->seller->id; ?>" />
        <input type="hidden" name="filepic" id="filepic" value="1" /> <!-- Путь до баннера-->
        <input type="hidden" name="option" value="com_storecable" />
        <input type="hidden" name="view" value="seller" />
        <input type="hidden" name="layout" value="buybanner" />
        <input type="hidden" name="task" value="seller.buybanner" />
        <input type="hidden" name="tokenorder" value="<?php echo StoreHelper::getToken("tokenorder"); ?>" />
    </form>
            <tr>
                <td colspan="2">Загрузите баннер со своего компьютера:</td>
            </tr>
            
            <tr class="ban-1">
                <td colspan="2">
                    <form>
                        <input type="file" multiple="multiple" />      
                    </form>
                    <div class="loadedfiles">
                    </div>
                </td>
            </tr>
            
            <tr>
                <td colspan="2">Или выберите готовый баннер:</td>
            </tr>
            
            <tr class="ban-2">
                <td colspan="2">
                    <input type="button" class="btn default" value="Выбрать готовый баннер" onclick='jQuery("#modalPics").modal("show")' />
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="loadedimage">
                        <img src="<?php echo JURI::base().'components/com_storecable/assets/images/none.jpg' ?>" />
                    </div>
                </td>
            </tr>
        </table>
</div>


<script language="javascript">


//Загрузка файлов на сервер
files='';
jQuery('input[type=file]').change(function(){
    files = this.files;
    loadfiles();
});

function loadfiles(){
    var data = new FormData();
    jQuery.each( files, function( key, value ){
        data.append( key, value );
    });
    jQuery.ajax({
        url: 'index.php?option=com_storecable&task=seller.uploadbanner&uploadfiles=1&sellerid=<?php echo StoreHelper::getDataSeller()->id; ?>',
        type: 'POST',
        data: data,
        cache: false,
        dataType: 'json',
        processData: false, // Не обрабатываем файлы (Don't process the files)
        contentType: false, // Так jQuery скажет серверу что это строковой запрос
        beforeSend:function(){
            //Установить иконку загрузки
            var load='<tr class="loadbanner"><td><div class="load"></div></td></tr>'; 
            
            jQuery('.loadedfiles').append(load); 
        },
        success: function( data, textStatus, jqXHR ){
            console.log(data);
            var filename=SiteUrl+'images/banners/<?php echo USER_BANNERS_CATALOG; ?>/'+data.upload.filename[0];
            jQuery(".loadedimage img").attr('src',filename);
            jQuery("#filepic").val(filename);
            //var loads=respond.loads;

            //Удалить иконку загрузки
            jQuery('.loadedfiles .loadbanner').remove();
            // Если все ОК
 /*
            if( typeof data.error === 'undefined' ){
                // Файлы успешно загружены, делаем что нибудь здесь
 
                // выведем пути к загруженным файлам в блок '.ajax-respond'
                //var files_path = respond.files;
                //var files_name = respond.filesname;
                var html = '<tr><td><div class="del"></div></td><td>';
                /*
                jQuery.each( files_path, function( key, val ){ html += val.filename+' ('+val.desc+')' +'</td></tr>'; } )
                jQuery('.loadedfiles').append( html );
                */
                
                /*
                for (var i=0;i<jQuery(data.files).length;i++){
                    //console.log(i);
                    //respond[i].filename;
                    
                    html = '<tr class="trlist'+respond.files[i].num+'"><td><div class="del" onclick="removelist('+respond.files[i].num+')"></div></td><td>';
                    html += respond.files[i].filename+' ('+respond.files[i].description+')' +'</td></tr>';
                    jQuery('.loadedfiles').append( html );
                }
                */
                /*
            }
            else{
                console.log('ОШИБКИ ОТВЕТА сервера: ' + data.error );
            }
            
            
*/            
            
        },
        error: function( jqXHR, textStatus, errorThrown ){
            console.log('ОШИБКИ AJAX запроса: ' + textStatus );
        }
    });
}

//Установить предустановленный баннер
function setimg(filename){
    filename=SiteUrl+'images/banners/setbanners/'+filename;
    jQuery("#closemodal").click();
    jQuery(".loadedimage img").attr('src',filename);
    jQuery("#filepic").val(filename);
}

//Отправка заявки
function ordersend(){
    if (jQuery("input#filepic").val()=='1'){
        alert("Выберите баннер");
        return false;
    }
    jQuery('#bannerFrom').submit();
} 

<?php if ($_SESSION['bannerordered']=='1') { ?>
<?php unset($_SESSION['bannerordered']); ?>
    alert("Заявка отправлена");
<?php } ?>

//Удалить ордер
function deleteorder(orderid){
    var url='<?php echo JURI::base().'index.php?option=com_storecable&task=seller.deletebanner&id='; ?>'+orderid;
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            console.log(data);
            jQuery("tr.banner"+orderid).remove();
        },
        error:function(){
            alert("Не получилось удалить заявку");
        }
    })
}

</script>