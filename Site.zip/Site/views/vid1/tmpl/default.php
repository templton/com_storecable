<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
?>
<div class="item-page">
	<h1></h1>
</div>