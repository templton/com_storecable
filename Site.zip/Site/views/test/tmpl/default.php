<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
die;

$db=JFactory::getDBO();
$query='SELECT * FROM `#__store_alldata`';
$db->setQuery($query);
$data=$db->LoadObjectList();
for ($i=4099;$i<count($data);$i++)
//for ($i=3999;$i<4100;$i++)
{
    $cable=$data[$i]->cable;
    $cable=explode(' ',$cable);
    $data[$i]->cable=$cable[2];
    $cablenative=$data[$i]->cable;
    if (strlen($cable[4])>0){
        $data[$i]->cable.=' '.$cable[3].' '.$cable[4];
    }
    $cable=$data[$i]->cable;
    echo $cable."<br>";
    $cablesize=explode('|',$data[$i]->table);
    foreach ($cablesize as $size)
    {
        $size=trim(substr($size,strlen($cablenative)));
        $t=explode(' ',$size);
        if (count($t)>0){$sizename=$t[0];}else{$sizename='none';$kv='none';}
        if (count($t)>1){$kv=$t[count($t)-1];}else{$kv='none';}
        $info=StoreHelper::getCableName($cablenative,'name');
        //print_r($info);
        $idinfo=-1;
        if (count($info)>0){
            for($j=0;$j<count($info);$j++){
                if ($info[$j]->shortname==$cable){
                  $idinfo=$j;  
                }
            }
            //�������� id �������� size
            if (strlen($sizename)>0){
                $query='SELECT * FROM `#__store_cablesize` WHERE `name` LIKE "'.$sizename.'"';
                //echo $query;
                $db->setQuery($query);
                $id=$db->LoadObject();
                if (count($id)>0){
                    $id=$id->id;
                }else{
                    //�������� ����� ������ � �������� id ����������� ������
                    $query='INSERT INTO `#__store_cablesize` (`name`) VALUES("'.$sizename.'")';
                    $db->setQuery($query)->query();
                    $id=$db->insertid();
                }
                echo $data[$i]->id." -> cablekv=".$info[$idinfo]->cablekv."(".$info[$idinfo]->cablekvid.") - size=".$sizename." (".$id.")<br>";
                //����� ��� ����������� ������
                $query='SELECT * FROM `#__store_cabledata` WHERE `cablesizeid`="'.$id.'" AND `cableid`="'.$data[$i]->id.'"';
                $db->setQuery($query);
                $tt=$db->LoadObjectList();
                if (count($tt)>0){
                                
                }else{
                    $query='INSERT INTO `#__store_cabledata` (`cableid`,`cablesizeid`) VALUES("'.$data[$i]->id.'","'.$id.'")';
                    $db->setQuery($query);
                    $db->query();
                }
            }
        }
        //echo $size."--[".$sizename."(".$kv.")] / ";
    }
    echo "<hr>";
}


/*
$query='SELECT * FROM `#__store_cable`';
$data=$db->setQuery($query)->LoadObjectList();
foreach ($data as $item){
    $query=$db->getQuery(true);
    $item->name=trim($item->name);
    $fields=array(
        '`name`="'.$item->name.'"'
    );
    $cond='`id`="'.$item->id.'"';
    $query->update('#__store_cable')->set($fields)->where($cond);
    $db->setQuery($query);
    $db->execute();
}
*/

?>



