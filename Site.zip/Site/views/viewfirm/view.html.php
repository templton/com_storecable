<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewViewfirm extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
	public function display( $tpl = null )
	{
	   //Получить данные контрагента
       $this->seller=$this->get('Seller');
	   parent::display( $tpl );
	}

}