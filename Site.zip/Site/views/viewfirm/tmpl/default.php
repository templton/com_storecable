<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
/*
echo "<pre>";
print_r($this->seller);
echo "</pre>";
*/
?>

<!-- Вставить форму поиска -->
<?php require(JPATH_COMPONENT.'/include/searchform.php'); ?>

<!-- Логотип -->
<?php if (strlen($this->seller->logo)){ ?>
    <img src="<?php echo $this->seller->logo; ?>" />
<?php } ?>


<h1>Карточка контрагента - <?php echo $this->seller->name; ?></h1>

<!-- Основной блок -->
<div class="blockfirm">
<table class="infotable">
    <tr>
        <td>Город</td>
        <td><?php echo $this->seller->town; ?></td>
    </tr>
    
    <tr>
        <td>Адрес</td>
        <td>
            <?php
                $adr="ул. ".$this->seller->street;
                if (strlen($this->seller->bilding)>0){
                    $adr.=', корпус '.$this->seller->bilding;
                }
                if (strlen($this->seller->house)>0){
                    $adr.=', дом '.$this->seller->house;
                }
                if (strlen($this->seller->office)>0){
                    $adr.=', офис '.$this->seller->office;
                }
                echo $adr;
            ?>
        </td>
    </tr>
    
    <tr>
        <td>Телефон</td>
        <td><?php                
                if (strlen($this->seller->phone[0])>0){
                foreach ($this->seller->phone as $phone){
                    ?>
                    <span class="email"><?php echo $phone; ?></span><br />
                    <?php
                }
                }
            ?></td>
    </tr>
    
    <tr>
        <td>E-Mail</td>
        <td><?php
                if (strlen($this->seller->email[0])>0) {
                foreach ($this->seller->email as $email){
                    ?>
                    <span class="email"><?php echo $email; ?></span><br />
                    <?php
                }
                }
            ?></td>
    </tr>
    <tr>
        <td>ИНН</td>
        <td><?php echo $this->seller->inn; ?></td>
    </tr>
    <tr>
        <td>Режим работы</td>
        <td>
            <table>
                <?php
                    if (strlen($this->seller->mode[1])<2){
                        ?>
                        <tr>
                            <td>ПН-ПТ: </td>
                            <td><?php echo $this->seller->mode[0] ?></td>
                        </tr>
                        <?php
                    }else{
                        ?>
                        <tr>
                            <td>ПН-ЧТ: </td>
                            <td><?php echo $this->seller->mode[0] ?></td>
                        </tr>
                        <tr>
                            <td>ПТ: </td>
                            <td><?php echo $this->seller->mode[1] ?></td>
                        </tr>
                        <?php
                    }
                ?>
                <tr>
                    <td>СБ: </td>
                    <td><?php
                            if (strlen($this->seller->mode[2])>3){
                                echo $this->seller->mode[2];
                            }else{
                                ?><span>ВЫХОДНОЙ</span><?php
                            }
                         ?>
                    </td>
                </tr>
                <tr>
                    <td>ВС: </td>
                    <td><?php
                            if (strlen($this->seller->mode[3])>3){
                                echo $this->seller->mode[3];
                            }else{
                                ?><span>ВЫХОДНОЙ</span><?php
                            }
                         ?>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
<table>
    <tr>
        <th>Проверить Контрагента</th>
    </tr>
    <tr>
        <td>
            <a href="https://egrul.nalog.ru/" target="_blank">ЕГРЮЛ</a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="https://focus.kontur.ru/entity?query=<?php echo $this->seller->ogrn; ?>" target="_blank">Контур. Фокус</a>
        </td>
    </tr>
    <tr>
        <td>
            <a href="https://sbis.ru/contragents/<?php echo $this->seller->inn ?>" target="_blank">СБИС</a>
        </td>
    </tr>
    
</table>
<!-- Контактные лица -->
<div class="faceblockview">
<table class="faceblocktable">
    <?php if (strlen($this->seller->face[0]->fio)>0) { ?>
    <?php $facecount=0; ?>
        <?php foreach ($this->seller->face as $item) { ?>
        <?php $facecount++; ?>
            <tr>
                <td colspan="2"><h4>Контактное лицо <?php echo $facecount; ?></h4></td>
            </tr>
            <tr>
                <td>Имя</td>
                <td><?php echo $item->fio; ?></td>
            </tr>
            
            <?php if (strlen($item->phone)>0) { ?>
                <tr>
                    <td>Телефон</td>
                    <td><?php echo $item->phone; ?></td>
                </tr>
            <?php } ?>
            
            <?php if (strlen($item->skype)>0) { ?>
                <tr>
                    <td>Skype</td>
                    <td><?php echo $item->skype; ?></td>
                </tr>
            <?php } ?>
            
            <?php if (strlen($item->icq)>0) { ?>
                <tr>
                    <td>ICQ</td>
                    <td><?php echo $item->icq; ?></td>
                </tr>
            <?php } ?>
            
            <?php if (strlen($item->whatsupp)>0) { ?>
                <tr>
                    <td>WhatsUpp</td>
                    <td><?php echo $item->whatsupp; ?></td>
                </tr>
            <?php } ?>
        <?php } ?>
    <?php } ?>
</table>
</div>
</div><!-- Основной блок -->

<!-- О фирме -->
<div class="blocinfo">
<input type="button" class="btn btn-info" data-toggle="collapse" data-target="#aboutfirmblock" value="О компании">
<div class="aboutfirmblock collapse" id="aboutfirmblock">
    <?php if (strlen($this->seller->about)>1) { ?>
        <h4 class="aboutfitm">О компании</h4>
        <div class="abouttextblock">
            <?php echo urldecode($this->seller->about); ?>
        </div>
    <?php } ?>
</div>
</div>