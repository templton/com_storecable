<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access

/*
unset ($_SESSION['onsklad']);
unset ($_SESSION['onseller']);
*/
/*
$db=JFactory::getDBO();
$query='SELECT * FROM `#__store_cable` WHERE LOWER (`name`) REGEXP LOWER ("(а)+.*(2)*.*(2)*") ORDER BY `name`';
$db->setQuery($query);
$data=$db->LoadObjectList();
echo "<pre>";
print_r($data);
echo "</pre>";
*/


/*
echo "<pre>";
print_r($this->items);
echo "</pre>";
*/
$user=JFactory::getUser();
?>

<script language="javascript">

//Пагинация для первой страницы
jQuery(document).ready(function(){
    var href;
    jQuery("div.pagination ul.pagination-list a").each(function(){
        if (href=jQuery(this).attr("href")){
            //console.log(href);
            //console.log(href.indexOf('start'));
            if (href.indexOf('start')=='-1'){
                href+='&start=1';
                jQuery(this).attr('href',href);
            }   
        }
    })
})



function show(){
    alert('onSeller='+onSeller);
    alert('onSklad='+onSklad);
}


</script>

<?php
            $document = &JFactory::getDocument();
            $renderer = $document->loadRenderer('modules');
            $options = array('style' => 'xhtml');
            $position = 'banner-1';
            echo $renderer->render($position, $options, null);
            ?>


<h1>Поиск кабеля</h1>

<!-- Вставить форму поиска -->
<?php require(JPATH_COMPONENT.'/include/searchform.php'); ?>

<!-- Главная таблица -->
<?php
    $settown=$_SESSION['settown'];
    
    if (count($this->items)>0){
    //Показать город
    if (strlen($settown['name'])>0 && $settown['id']=='0'){ ?>
        <span class="notownlabel">Город <?php echo $settown['name'] ?> не найден. Проверьте правильность написания города. Либо такого города нет в нашей базе. Результаты поиска выданы без учета указанного города. </span>
    <?php } ?>
    <div class="tableresult">
        <table class="cableblock">
            <tr>
                <th>Наименование</th>
                <th>
                    <?php
                        if ($_SESSION['onseller']=='1'){
                                echo "Производитель";
                            }else{
                                echo "Кол-во, км";
                            }
                    ?>
                </th>
                
                <!-- Показать поставщика для зарегистрированных пользователей -->
                <?php if ($user->id>0 && $_SESSION['onsklad']=='1') { ?>
                    <th>Поставщики</th>
                    <th>Город</th>
                <?php } ?>
            </tr>
            <?php
            $countpos=0;//Счетчик позиций. В середине списка нужно вставить баннер из позиции banner-2
            foreach ($this->items as $cable){
                $countpos++;
            
            //Смотрим условие для вставки баннера$countpos
            if (round(count($this->items)/2)==$countpos){
                ?> <tr><td colspan="2"> <?php
                $document = &JFactory::getDocument();
                $renderer = $document->loadRenderer('modules');
                $options = array('style' => 'xhtml');
                $position = 'banner-2';
                echo $renderer->render($position, $options, null);
                ?> </td></tr> <?php
            }
            
                ?><tr>
                    <?php
                        //Ссылка на вид просмотра кабеля по поставщикам
                        $link=JRoute::_("index.php?option=com_storecable&view=skladmore&cableid=".$cable->cableid."&cablesizeid=".$cable->cablesizeid.'&intown='.$settown['name'].'&cable='.$_GET['cable']); 
                    ?>
                    <td>
                        <?php
                        if ($_SESSION['onseller']=='1'){
                                //Данные для поиска по Производителям
                                ?><?php echo $cable->fullname; ?><?php
                        }else{
                            //Данные для поиска по кол-ву
                            ?><a href="<?php echo $link; ?>"><?php echo $cable->fullname; ?></a><?php
                            
                        }
                        ?>
                    </td>
                    <td><?php
                            if ($_SESSION['onseller']=='1'){
                                //Данные для поиска по Производителям
                                ?>
                                    <a class="standart" href="<?php echo JRoute::_("index.php?option=com_storecable&view=viewfirm&makerid=".$cable->sellerid.'&intown='.$settown['name'].'&cable='.$_GET['cable']); ?>"><?php echo $cable->seller; ?></a>
                                    
                                <?php
                            }else{
                                //Данные для поиска по кол-ву
                                echo $cable->count;
                            }  
                        ?>
                    </td>
                    
                    <!-- Показать поставщика для зарегистрированных пользователей -->
                    <?php if ($user->id>0 && $_SESSION['onsklad']=='1') { ?>
                        <td>
                            <?php $link=JRoute::_("index.php?option=com_storecable&view=viewfirm&sellerid=".$cable->sellerid.'&cable='.$_GET['cable'].'&intown='.$_GET['intown']); ?>
                            <a href="<?php echo $link; ?>"><?php echo $cable->seller; ?></a>
                        </td>
                        <td class="towntd">
                            <?php echo $cable->town;?>
                        </td>
                    <?php } ?>
                    
                </tr><?php
            }
            ?>
        </table>
    </div>
    <div class="divnouser">
        <?php if ($_GET['onsklad']=='1' && $user->id==0){ ?>
            <div class="nousertext">
                Информация по Поставщикам доступна только для авторизованных пользователей.
            </div>
        <?php } ?>
    </div>
        <?php
    }else{
        ?>
        <div class="noresult">
            <div>
                Ничего не нашлось. Поробуйте изменить параметры поиска.
            </div>
        </div>
        <?php
    }
?>


<?php
if (count($this->items)>0){
    echo $this->pagination->getListFooter();
    }
?>