<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewSearch extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
public function display( $tpl = null )
{
    //Поиск кабеля
    /*
    echo "<pre>";
    print_r($_GET);
    echo "</pre>";
    */
    if ($_GET['param']){
    
    //Установить фильтр на будущее
    if (JRequest::getVar('onseller')=='1'){
        $_SESSION['onseller']='1';
        $_SESSION['onsklad']='0';
    }else{
        $_SESSION['onseller']='0';
        $_SESSION['onsklad']='1';
    }
    $this->items=$this->get('Items');
    
    if (JRequest::getVar('onsklad')=='1'){
        //$this->items=StoreHelper::addMakerInData($this->items);   
    }
    /*
    $data=StoreHelper::getSearchParam();
    $this->get=http_build_query($data);
    echo $this->get;
    */
    $prefix='cable='.$_GET['cable'].'&onseller='.$_SESSION['onseller'].'&onsklad='.$_SESSION['onsklad'];
    $prefix.='&param='.$_GET['param'].'&intown='.$_GET['intown'];
    $this->pagination = $this->get( 'Pagination' );
    //Передать префикс в пагинацию
    $this->pagination->prefix=$prefix.'&cabledata='.JRequest::getVar("cabledata").'&';
    }
    parent::display( $tpl );
}

}