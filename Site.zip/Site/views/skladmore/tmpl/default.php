<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
$this->linkseller=$this->linkseller.'&cable='.$_GET['cable'].'&intown='.$_GET['intown'];
$adminparam=StoreHelper::getAllParam();
/*
echo "<pre>";
print_r($adminparam);
echo "</pre>";
*/
?>

<!-- Вставить форму поиска -->
<?php require(JPATH_COMPONENT.'/include/searchform.php'); ?>

<h1>Кабель <?php echo $this->items[0]->fullname; ?></h1>

<?php
    if (count($this->items)>0){
        ?>
        <table class="skladtable">
            <tr>
            
                <th>Наличие на складах <a href="<?php echo $this->linkseller; ?>" class="postavshik">узнать поставщиков</a></th>
                <!-- <th>Производители</th> -->
                <?php if ($adminparam->showprice=='1') { ?>
                    <th>Цены (руб/км)</th>
                <?php } ?>
            </tr>
            <tr>
                <td>
                    <table class="skladdetail">
                        <?php foreach ($this->items as $cable){ ?>
                            <tr>
                                <td><?php echo $cable->count; ?></td>
                                <td>км</td>
                                <td><?php echo $cable->town; ?></td>
                            </tr>
                        <?php } ?>
                    </table>
                </td>
                
                <!-- Колонка с производителями -->
                <!--
                <td>
                    <table class="skladdetail">
                        <?php foreach ($this->items as $cable){ ?>
                            <tr>
                                <td>
                                    <a class="standart" href="<?php echo JRoute::_("index.php?option=com_storecable&view=viewfirm&makerid=".$cable->makerid); ?>"><?php echo $cable->maker; ?></a>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>
                </td>
                -->
                
                <?php if ($adminparam->showprice=='1') { ?>
                <td>
                    <table class="skladdetail">
                        <?php foreach ($this->items as $cable){ ?>
                            <tr>
                                <td>
                                        <span class="price">
                                            <?php if ($cable->price>0){echo $cable->price;}else{echo '&nbsp;' ;} ?>
                                        </span>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>
                </td>  
                <?php } ?>
                              
            </tr>
        </table>
        <?php
    } 
?>

<?php
if (count($this->items)>0){
    echo $this->pagination->getListFooter();
    }
?>

<?php
$document = &JFactory::getDocument();
                $renderer = $document->loadRenderer('modules');
                $options = array('style' => 'xhtml');
                $position = 'banner-3';
                echo $renderer->render($position, $options, null);
?>