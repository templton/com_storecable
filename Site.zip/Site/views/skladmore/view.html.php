<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewSkladmore extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
	public function display( $tpl = null )
	{
		$this->items=$this->get('Items');    
        $this->pagination=$this->get('Pagination');
        $this->items=StoreHelper::addMakerInData($this->items);
        //Сформировать ссылку на страницу поставщиков по текущему кабелю
        $param=StoreHelper::getSearchParam();
        $this->linkseller=JRoute::_("index.php?option=com_storecable&view=allmaker&cableid=".$param->cableid.'&cablesizeid='.$param->cablesizeid);
        
		parent::display( $tpl );
	}
    

}