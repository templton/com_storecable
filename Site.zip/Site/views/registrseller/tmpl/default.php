<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
/*
$config = & JFactory::getConfig();
echo "<pre>";
print_r($config);
echo "</pre>";
*/

//Если пользователь авторизован, то пусть сначала выйдет из учетной записи
if (JFactory::getUser()->id>0){
    ?>
    <span class="errmesage">Вы уже авторизованы на сайте. Выйдите из своей учетной записи, чтобы пройти регистрацию.</span>
    <?php
    return;
}


?>
<div class="item-page">
	<h1>Регистрация поставщика</h1>
    <div class="registblock">
        <form id="registrseller" method="POST" action="index.php">
            <input type="text" name="login" class="login" placeholder="Логин" />
            <input type="password" name="password" class="password" placeholder="Пароль" />
            <input type="password" name="password1" class="password1" placeholder="Повторите пароль" />
            <input type="text" name="email" class="email" placeholder="E-Mail" />
            <input type="text" name="nameooo" class="nameooo" placeholder="Название организации" />
            <input type="text" name="inn" class="inn" placeholder="ИНН" />
            <input type="text" name="ogrn" class="ogrn" placeholder="ОГРН" />
            <input type="text" name="city" class="city" placeholder="Город" autocomplete="off" data-kladr-type="city">
            <div id="kladr_autocomplete">
                <ul class="autocomplete1 autocomplete" style="top: 30px; left: 8px; width: 158px; display: none;"></ul>
                <div class="spinner1 spinner" style="top: 10px; left: 150px; display: none; background-position: 0% 38.6889%;">
                </div>
            </div>
            
            
            <input type="hidden" name="token" value="<?php echo $this->token; ?>" />
            <input type="hidden" name="option" value="com_storecable" />
            <input type="hidden" name="task" value="registrseller.registration" />
            <input type="hidden" name="view" value="registrseller" />
            
            <input type="button" value="Зарегистрироваться" onclick="validateseller(jQuery('#registrseller'))" />
        </form>
    </div>
</div>

<script language="javascript">
    jQuery("#registrseller input").bind("click change",function(){
        jQuery(this).removeClass("red");
    })
    
    //ИНН - только цифры
    jQuery('.inn').bind("change keyup input click", function() {
    if (this.value.match(/[^0-9]/g)) {
        this.value = this.value.replace(/[^0-9]/g, '');
    }
    });
    
    //ОГРН - только цифры
    jQuery('.ogrn').bind("change keyup input click", function() {
    if (this.value.match(/[^0-9]/g)) {
        this.value = this.value.replace(/[^0-9]/g, '');
    }
    });
    
    //Тольоко логин 
    jQuery('.email').bind("change keyup input click", function() {
    if (this.value.match(/[^A-Za-z0-9-_@.]/g)) {
        this.value = this.value.replace(/[^A-Za-z0-9-_@.]/g, '');
    }
    });



</script>

<?php
$date=date("y-m-d").' '.date("H:i:s");
$date= date("y-m-d");
$time = date("H:i:s");
echo $date.' '.$time;
?>
