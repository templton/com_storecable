<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewRegistrseller extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
	public function display( $tpl = null )
	{
	   //Подключить общего помощника
       if(!class_exists('StoreHelper'))require(JPATH_COMPONENT."/helpers/helper.php");
       //Подключить скрипт валидации формы
       $doc = JFactory::getDocument();
       //$doc->addScript("components/com_storecable/assets/scripts/jquery-2.2.0.min.js");
       $doc->addScript("components/com_storecable/assets/scripts/validation.js ");
       $doc->addScript("components/com_storecable/assets/scripts/jquery.kladr.min.js");
       $doc->addScript("components/com_storecable/assets/scripts/simple.js");
       
       $doc->addStyleSheet("components/com_storecable/assets/styles/simple.css");
       $doc->addStyleSheet("components/com_storecable/assets/styles/jquery.kladr.min.css");
       
       $doc->addScriptDeclaration('var siteUrl="'.JURI::base().'"');
       $doc->addScriptDeclaration('var componentUrl="'.JURI::base().'/components/com_storecable"');
       
       $this->token=StoreHelper::getToken('token');
		storecableSiteHelper::setDocument( '' );
		parent::display( $tpl );
	}

}