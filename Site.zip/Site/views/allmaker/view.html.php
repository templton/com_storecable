<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewAllmaker extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
	public function display( $tpl = null )
	{
	   $this->items=$this->get('Items');
       $this->items=StoreHelper::addMakerInData($this->items);
       $this->pagination=$this->get('Pagination');
	   parent::display( $tpl );
	}

}