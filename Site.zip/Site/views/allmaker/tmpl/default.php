<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
$adminparam=StoreHelper::getAllParam();

//Что бы посмотреть информацию по поставщикам, необходимо авторизоваться
if (JFactory::getUser()->id==0){
    ?>
    <span class="errmesage">
        Эта информация доступна только для зарегистрированных пользователей.
        <br />
        Пожалуйста, зарегистрируйтесь как <a href="<?php echo JRoute::_('index.php?option=com_users&view=registration'); ?>">Покупатель</a>
         или как <a href="<?php echo JRoute::_("index.php?option=com_storecable&view=registrseller"); ?>">Поставщик/Производитель</a>
    </span>
    <?php
    return;
}
?>


<!-- Вставить форму поиска -->
<?php require(JPATH_COMPONENT.'/include/searchform.php'); ?>

<h1>Поставщики кабеля <?php echo $this->items[0]->fullname; ?></h1>
<?php
    if (count($this->items)>0){
        ?>
        <table class="report">
            <tr>
                <th>Кабель</th>
                <?php if ($adminparam->showprice=='1') { ?>
                    <th>Цена (руб/км)</th>
                <?php } ?>
                <th>Кол-во, км</th>
                <!-- <th>Производитель</th> -->
                <th>Поставщик</th>
                <th>Город</th>
            </tr>
            <?php
                foreach ($this->items as $cable){
                    ?>
                    <tr>
                        <td><?php echo $cable->fullname; ?></td>
                        <?php if ($adminparam->showprice=='1') { ?>
                            <td><?php echo $cable->price; ?></td>
                        <?php } ?>
                        <td><?php echo $cable->count; ?></td>
                        <!-- Колонка с производителями -->
                        <!--
                        <td><a class="standart" href="<?php echo JRoute::_("index.php?option=com_storecable&view=viewfirm&makerid=".$cable->makerid.'&intown='.$_GET['intown'].'&cable='.$_GET['cable']); ?>"><?php echo $cable->maker; ?></a></td>
                        -->
                        
                        <td><a class="standart" href="<?php echo JRoute::_("index.php?option=com_storecable&view=viewfirm&sellerid=".$cable->sellerid.'&intown='.$_GET['intown'].'&cable='.$_GET['cable']); ?>"><?php echo $cable->seller; ?></a></td>
                        <td><?php echo $cable->town; ?></td>
                    </tr>
                    <?php
                }
            ?>
        </table>
        <?php
    }
?>