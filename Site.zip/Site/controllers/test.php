<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author Саламатов Дмитрий Викторович
 */
class StorecableControllerTest extends JControllerLegacy
{

}