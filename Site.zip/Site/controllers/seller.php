<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author Саламатов Дмитрий Викторович
 */
class StorecableControllerSeller extends JControllerLegacy
{
    public function __construct() {
        //Если папка для баннеров пользователей не существует, до добавить ее
		parent::__construct();
	}
    
public function display($cachable = false, $urlparams = false) {
		parent::display();
	}
    

//Поиск марки кабеля по начальным буквам
    public function searchcable()
    {
        if ($_GET['term']){
            //признак исключения позиций по уже существующим в таблице контрагентов
            if (JRequest::getVar("makerid")){
                $makerid=JRequest::getVar("makerid");
            }else{
                $makerid=0;
            }
            
            $data=StoreHelper::getTypesCable($_GET['term'],$makerid);
            unset($cable);
            foreach ($data as $item)
            {
                $suf='';
                if (strlen($item->cablekv)>0){
                    $suf=' - '.$item->cablekv;
                }
                $cable[]=$item->name.$suf;
            }
            echo json_encode($cable);
            exit; 
        }
    }
    
//Поиск производителя Полнотекстный
    public function searchmaker()
    {
        if ($_GET['term']){  
            $data=StoreHelper::getMakers($_GET['term']);
            unset($cable);
            foreach ($data as $item)
            {
                $cable[]=$item->name;
            }
            echo json_encode($cable);
            exit; 
        }
    }
    
//Добавить кабель на склад текущего поставщика
    public function addcableJS()
    {
        $json=new stdClass();
        $data=new stdClass();
        $input = JFactory::getApplication()->input;
        $data->cable=JRequest::getVar('cable');
        $data->count=JRequest::getVar('count');
        $data->maker=JRequest::getVar('maker');
        $data->gost=JRequest::getVar('gost');
        $data->price=JRequest::getVar('price');
        $data->cablesizeid=JRequest::getVar('cablesizeid');
        if ($_GET['edit']){
            $data->id=JRequest::getVar('id');
            $data->edit=JRequest::getVar('edit');   
        }
        //echo $data->cable;
        
        $json->res=StoreHelper::addCable($data);
        $json->data=$data;
        
        echo json_encode($json);
        exit;
    }        
    
    public function deletecable()
    {
        $id=JRequest::getVar('id');
        $db=JFactory::getDBO();
        $query='DELETE FROM `#__store_store` WHERE `id`="'.$id.'"';
        $db->setQuery($query);
        $db->query();
        $res=new stdClass();
        $res->res='Запись с id='.$id." удалена.";
        echo json_encode($res);
        exit;
    }
    
    //Получить макроразмеры кабеля по его имени
    public function getsizeselect(){
        $res=new stdClass();
        $cable=JRequest::getVar('cable');
        //Получить id кабеля по имени
        $id=StoreHelper::getIdCable($cable);
        //Получить селект макроразмеров
        $select=StoreHelper::getCableSizeSelect($id);
        $res->select=$select;
        //echo $select."<br>";
        echo json_encode($res);
        jExit();
    }     
    
    //Сохранить новые данные пользователя
    public function saveuser(){
        $res=new stdClass();
        $res->get=$_GET;
        $res->save=StoreHelper::saveuser();
        echo json_encode($res);
        jExit();
    }
    
//Загрузка баннеров на сервер
public function uploadbanner(){
    $res=new stdClass();
    $res->result='1';
    $res->get=$_GET;
    $res->post=$_POST;
    $filenameprefix=$_GET['sellerid'].'.'.date('Y-m-d').'.'.date("G-i-s");
    $res->upload=Salam::uploadfile(PATH_USER_BANNERS,$filenameprefix);
    echo json_encode($res);
    jExit();
}    
    
//Загрузка файлов на сервер
public function uploadfiles(){
    $res=new stdClass();
    $data = array();
    $sellerid=StoreHelper::getDataSeller()->id;
 
    if( isset( $_GET['uploadfiles'] ) ){
        $error = false;
        $files = array();
 
        if ($_GET['uploaddir']){
            $uploaddir = $_GET['uploaddir'];
        }else{
            $uploaddir = JPATH_COMPONENT.'/files/';   
        }
        
        if ($_GET['filenameprifix']){
            $prefix=$_GET['filenameprifix'];
        }else{
            $prefix=$uid = md5(uniqid('seller.'.$_GET['sellerid'], true));
            $prefix=substr($prefix,0,10);
            $prefix='seller.'.$_GET['sellerid'].'.'.date("G-i-s").'.'.$prefix.'.';
        }

        $count=0;
        foreach( $_FILES as $file ){
            //$res->newfilename=$newfile;
            /*
            echo json_encode($res);
            jExit();
            */
            $newfilename=JRequest::getVar('newfilename');
            if (strlen($newfilename)>2){
                $res->newfilename=$newfilename;
                $res->ext=end(explode('.',basename($prefix.$file['name'])));
                $newfile=$prefix.$newfilename.'.'.end(explode('.',basename($prefix.$file['name'])));
                //$res->sad="SAD";
            }else{
                $newfile=basename($prefix.$file['name']);   
            }
            
            if( move_uploaded_file( $file['tmp_name'], $uploaddir . $newfile ) ){
                //Убрать загрузку реальных адресов файлов
                //$files[] = realpath( $uploaddir . $file['name'] );
                //Реальные пути установить в сессию order
                //Внесем документы пользователя в переменную заявки
                $doc=$_SESSION['doc'];
                $num=count($doc);
                $doc[$num]['filename']=$newfile;
                $doc[$num]['filepath']=realpath( $uploaddir . $newfile);
                $doc[$num]['description']=addslashes($_GET['desc']);
                $doc[$num]['sellerid']=$sellerid;
                $_SESSION['doc']=$doc;
                
                
                $files[$count]['filename'] = $newfile;
                $files[$count]['description'] = $_GET['desc'];
                $files[$count]['num']=$num;
                $count++;
                
                //$filesname[]=realpath( $file['name'] );
            }
            else{
                $error = true;
            }
        }
 
        $data = $error ? array('error' => 'Ошибка загрузки файлов.') : array('files' => $files );
        
        
        $res->data=$data;
        $res->loads=JRequest::getVar('loads');
        $res->uploaddir=$uploaddir;
 
        echo json_encode( $res );
    }
    jExit();
}

//Удалить файл с сервера
public function deletefile(){
    $res=new stdClass();
    $num=JRequest::getVar('num');
    $doc=$_SESSION['doc'];
    $filepath=$doc[$num]['filepath'];
    /*
    $res->get=$_GET;
    $res->num=$num;
    $res->filepath=$filepath;
    */
    $doc[$num]['filepath']='';
    $doc[$num]['filename']='';
    $doc[$num]['description']='';
    $_SESSION['doc']=$doc;
    /*
    if (unlink($filepath)){
        $res->error='0';
    }else{
        $res->error='1';
    }
    */
    $res->error='0';
    echo json_encode($res);
    jExit();
}

//Обновить массив в сессии
public function updateCable(){
    $order=$_SESSION['cable'];
    $count=0;
    foreach($order as $item){
        $cable[$count]['cableid']=$item['cableid'];
        $cable[$count]['cable']=$item['cable'];
        $count++;
    }
    $_SESSION['cable']=$cable;
}

//Добавить кабель в набор
public function addCableIntoOrder(){
    $res=new stdClass();
    unset($temp);
    $c=0;
    
    //Данные для обработки из POST запроса
    $data=$_POST['data'];
    //Разбить первоначально на объекты
    $data=explode('|',$data);
    //Собрать массив с данными
    for($i=0;$i<count($data);$i++){
        //разбить объект
        $ex=explode("#",$data[$i]);
        //собрать данные
        if (strlen($ex[0])>0){
            $temp[$c]['cable']=$ex[0];
            $temp[$c]['cableid']=$ex[1];
            $temp[$c]['set']=$ex[2];
            $c++;   
        }
    }
    //Обработка полученных данных
    for ($i=0;$i<count($temp);$i++){
        //Определить, что делать с текущей позицией
        if ($temp[$i]['set']=='0'){
            //Удаление позиции из сессии
            $num=StoreHelper::arraySearch('cableid',$temp[$i]['cableid'],$_SESSION['cable']);
            if ((int)$num>=-1){
                unset($_SESSION['cable'][$num]);
                //Удалили внутренний элемент - запросим упрядоченный order по новой
                self::updateCable();
            }
        }else{
            //Добавление позиции в сессию
            //Сначала проверить нет ли уже такой позиции в сессоии
            $num=StoreHelper::arraySearch('cableid',$temp[$i]['cableid'],$_SESSION['cable']);
            if ((int)$num>=-1){
                //Позиция уже есть - ничего не делаем
            }else{
                //Позиции еще нет - добавляем в сессию
                $count=count($_SESSION['cable']);
                $_SESSION['cable'][$count]['cableid']=$temp[$i]['cableid'];
                $_SESSION['cable'][$count]['cable']=$temp[$i]['cable'];
            }
        }
    }
    //$res->temp=$temp;
    //$res->session=$_SESSION['cable'];
    $res->count=count($_SESSION['cable']);
    //$res->salam='500';
    $res->get=$_GET;
    echo json_encode($res);
    jExit();
}

//Удалить кабель из набора
public function deleteCableFromOrder(){
    $id=JRequest::getVar('cableid');
    $cable=$_SESSION['cable'];
    //Проверить, чтобы такого элемента еще не было в массиве
    $num=StoreHelper::arraySearch('cableid',$id,$cable);
    
    if ((int)$num>=-1){
        unset($cable[$num]);
    }
    $_SESSION['cable']=$cable;
    
    $res=new stdClass();
    $res->num=$num;
    echo json_encode($res);
    jExit();
}


//Добавить заявку на производство кабеля
public function addorder(){
    if (count($_SESSION['cable'])==0){
        $_SESSION['ermes']="Завяка пуста. Добавьте кабели в список.";
        self::display();
        return;
    }
    //Подготовка списка кабелей
    $model = $this->getModel('seller');
    $model->addOrder();
    
    $seller=StoreHelper::getDataSeller();
    
    
//Отправка почты пользователю
    $html='
        <p>На сайте '.JURI::base().' Вы оформили заявку на получения статуса Производителя следующих позиций:</p>
    ';
    $count=1;
    /*
    echo "<pre>";
    print_r($_SESSION['cable']);
    echo "</pre>";
    */
    $cableitems=$_SESSION['cable'];
    foreach ($cableitems as $item){
        $html.=$count.' - '.$item['cable']."<br>";
        $count++;
    }
    $html.='
        <p>Статус Вашей заявки Вы можете посмотреть в личном кабинете '.JURI::base().'lichnyj-kabinet</p>
        <p>О результате рассмотрения заявки Администрацией сайта Вам будет дополнительно отправлено письмо на этот же адрес электронной почты.</p>
    '; 
    $sender=array(
        StoreHelper::getParam('answeremail'),StoreHelper::getParam('answername')
    );
    $email=$seller->email;
    $email=explode("|",$email);
    $email=$email[0];
    if (strlen($email[0])==0){
        echo "Не указан адрес электронной почты";
        return;
    }
    StoreHelper::sendemail($email,$sender,$html);
    

//Отправка почты администратору
    $html='
        <p>На сайте '.JURI::base().' оформлена заявка на получение статуса производителя. Подробности: </p>
        <p>Компания  - '.$seller->name.'</p>
        <p>ID заявки - '.$_SESSION['orderidconfirm'].'</p>
        <p>Чтобы рассмотреть заявку перейдите в администраторскую часть сайта</p>
    ';    
    $email=StoreHelper::getParam('adminemail');
    StoreHelper::sendemail($email,$sender,$html);
    
    unset($_SESSION['orderidconfirm']);
    unset($_SESSION['cable']);
    unset($_SESSION['doc']);
    $_SESSION['ermes']="Заявка добавлена";
    
    header("Location: ".jRoute::_("index.php?option=com_storecable&view=seller&layout=maker"));
    //self::display();
}

//Создать заявку на баннер
public function buybanner(){
    $seller=StoreHelper::getDataSeller();
    //print_r($_GET);
    
    
    if ($_SESSION['tokenorder']!=$_GET['tokenorder'])
        {
            self::display();
            return;
        }
    
      
    //Установить период времени заказа в формате UNIX
    //echo JRequest::getVar('bannerperiod')."<br>";
    $period=(JRequest::getVar('bannerperiod')=='week' ? (int)JRequest::getVar('bannercount')*7 : (int)JRequest::getVar('bannercount')*7);
    
    if (JRequest::getVar('bannerperiod')=='week'){
        //$period=(int)JRequest::getVar('bannercount')*7;
        $period=strtotime("+".JRequest::getVar('bannercount')." week",strtotime(date('Y-m-d')));
        $period=$period-strtotime("now");
        $days=JRequest::getVar('bannercount').' (неделя)';
        echo "<hr>";
    }else{
        //$period=(int)JRequest::getVar('bannercount')*30;
        $period=strtotime("+".JRequest::getVar('bannercount')." month",strtotime(date('Y-m-d')));
        $period=$period-strtotime(date('Y-m-d'));
        $days=JRequest::getVar('bannercount').' (месяц)';
    }
    /*
    echo $period."<br>";
    $cur=strtotime("now");
    echo $cur."<br>";
    $cur=$cur+$period;
    echo date('d-m-Y', $cur);
    
    die;
      */
            
    $sellerid=JRequest::getVar('sellerid');
    $filepic=JRequest::getVar('filepic');
    $positionid=JRequest::getVar('bannerposition');
    $db=JFactory::getDBO();
    $query='INSERT INTO `#__store_banner`';
    $query.=' (`sellerid`,`dateorder`,`positionid`,`bannerpath`,`status`,`period`)';
    $query.=' VALUES ("'.$sellerid.'","'.date('Y-m-d').'","'.$positionid.'","'.$filepic.'","0","'.$period.'")';
    $db->setQuery($query);
    $db->execute();
    $insertid=$db->insertid();
    $_SESSION['bannerordered']='1';

//Отправка почты пользователю
    $html='
        <p>На сайте '.JURI::base().' Вы оформили заявку на размещение баннера:</p>
    ';
    $html.='<p>Место расположения баннера - '.StoreHelper::getPosition($positionid)->name.'</p>';
    $html.='<p>Период оформления: '.$days.'</p>';
    $html.='<p><img src="'.$filepic.'" /></p>';
    $html.='
        <p>Статус Вашей заявки Вы можете посмотреть в личном кабинете '.JURI::base().'lichnyj-kabinet</p>
        <p>О результате рассмотрения заявки Администрацией сайта Вам будет дополнительно отправлено письмо на этот же адрес электронной почты.</p>
    '; 
    $sender=array(
        StoreHelper::getParam('answeremail'),StoreHelper::getParam('answername')
    );
    $email=$seller->email;
    $email=explode("|",$email);
    $email=$email[0];
    if (strlen($email[0])==0){
        echo "Не указан адрес электронной почты";
        return;
    }
    StoreHelper::sendemail($email,$sender,$html);
    

//Отправка почты администратору
    $html='
        <p>На сайте '.JURI::base().' оформлена заявка на размещение баннера. Подробности: </p>
        <p>Компания  - '.$seller->name.'</p>
        <p>ID заявки - '.$insertid.'</p>
        <p>Чтобы рассмотреть заявку перейдите в администраторскую часть сайта</p>
    ';    
    $email=StoreHelper::getParam('adminemail');
    StoreHelper::sendemail($email,$sender,$html);


    self::display();
}

//Удалить ордер
public function deletebanner(){
    $res=new stdClass();
    $res->get=$_GET;
    $db=JFactory::getDBO();
    $query='DELETE FROM `#__store_banner` WHERE `id`="'.JRequest::getVar('id').'"';
    $db->setQuery($query);
    $db->execute();
    //$res->query=$query;
    echo json_encode($res);
    jExit();
}


//Получить id кабеля
public function getcableid(){
    $res=new stdClass();
    $cable=JRequest::getVar('cable');
    $id=Storehelper::getIdCable($cable);
    $res->get=$_GET;
    $res->id=$id;
    echo json_encode($res);
    jExit();
    
}

//Сохранить блок about
public function about(){
    /*
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
    */
    $icofilename=JRequest::getVar('icofilename');
    $text=JRequest::getVar("text");
    $sellerid=JRequest::getVar("sellerid");
    $logopathserver=JRequest::getVar('logopathserver');
    
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $fields=array(
        '`logo`="'.$icofilename.'"',
        '`about`="'.$text.'"',
        '`logopathserver`="'.$logopathserver.'"'
    );
    $query->update('`#__store_seller`')->set($fields)->where('`id`="'.$sellerid.'"');
    //echo $query."<br>";
    $db->setQuery($query);
    $db->execute();
    self::display();
}

//Удалить логотип пользователя
public function deletelogofile(){
    $data=new stdClass();
    $data->get=$_GET;
    
    $db=JFactory::getDBO();
    $sellerid=JRequest::getVar("sellerid");
    $query='SELECT `logopathserver` FROM `#__store_seller` WHERE `id`="'.$sellerid.'" LIMIT 1';
    $db->setQuery($query);
    $f=$db->loadObject()->logopathserver;
    $data->logopathserver=$f;
    $data->err=0;
    $query=$db->getQuery(true);
    $fields=array('
        `logopathserver`="",
        `logo`=""
    ');
    $query->update('`#__store_seller`')->set($fields)->where('`id`="'.$sellerid.'"');
    $db->setQuery($query);
    if (!$db->execute()){
        $data->err='1';
        $data->errmess='Не удалось обновить запись';
    }
    //$query=$db->getQuery(true);
    //$db->update('`#__store_seller`')->
    
    echo json_encode($data);
    jExit();
}

}