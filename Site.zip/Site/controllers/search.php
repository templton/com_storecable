<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author Саламатов Дмитрий Викторович
 */
class StorecableControllerSearch extends JControllerLegacy
{
    public function display($cachable = false, $urlparams = false) {
		parent::display();
	}
    
    public function search(){
        self::display();
    }

}