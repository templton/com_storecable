<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author Саламатов Дмитрий Викторович
 */
class StorecableControllerRegistrseller extends JControllerLegacy
{
    public function __construct() {
		parent::__construct();
	}
	
        
//Проверка на уникальность логина и email        
    public function testloginAJAX()
    {
        $this->json = new stdClass();
        $input = JFactory::getApplication()->input;
        //echo $input->getCmd( 'login' );
        ob_start();
        //Проверка логина
        $this->json->login= StoreHelper::testlogin(JRequest::getVar('login'));
        $this->json->loginname=JRequest::getVar('login');
        //Проверка адреса электронной почты
        $this->json->email= StoreHelper::testemail(JRequest::getVar('email'));
        $this->json->emailname=JRequest::getVar('email');
        //Проверка ИНН
        $this->json->inn= StoreHelper::testinn(JRequest::getVar('inn'));
        $this->json->innname=JRequest::getVar('inn');
        //Проверка ОГРН
        $this->json->ogrn= StoreHelper::testinn(JRequest::getVar('ogrn'));
        $this->json->ogrnname=JRequest::getVar('ogrn');
        
        echo json_encode($this->json);
        exit;
    }
    
    public function registration()
    {
        
        $input = JFactory::getApplication()->input;
        $login=$input->getCmd('login');
        
        /*
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";
        */
        
        //Проверить, чтобы такого логина не было
        if(StoreHelper::testlogin($login)=='1') {return;};
        
        //Проверить токен
        $token=$input->getCmd('token');
        if ($_SESSION['token']!=$token)
            {
                echo "Token Error!";
                exit;
            }
        unset($_SESSION['token']);
        
        $password=$input->getCmd('password');
        $password_base=$password;
        $db=JFactory::getDBO();
        
        //Вставить пользователя в таблицу joomla
        $date=date("y-m-d").' '.date("H:i:s");
        $email=JRequest::getVar('email');
        
        //print_r($email);
        
        $query='INSERT INTO `#__users` (`name`,`username`,`password`,`registerDate`,`email`,`block`)';
        $query.=' VALUES ("'.$login.'", "'.$login.'","'.md5($password).'","'.$date.'","'.$email.'","1")';
        $db->setQuery($query);
        $db->query();
        $id=$db->insertid();
        
        //Добавить пользователю нужную группу Registered
        $query='INSERT into `#__user_usergroup_map` (`user_id`,group_id)';
        $query.=' VALUES ("'.$id.'","2")';
        $db->setQuery($query);
        $db->query();
        
        //Добавить группу seller
        $query='SELECT `id` FROM `#__usergroups` WHERE `title` LIKE "seller" LIMIT 1';
        $db->setQuery($query);
        $group=$db->LoadObject();
        $group=$group->id;
        $query='INSERT into `#__user_usergroup_map` (`user_id`,group_id)';
        $query.=' VALUES ("'.$id.'","'.$group.'")';
        $db->setQuery($query);
        $db->query();
        
        //Определить id города. Если такого города еще нет, то внести новый город
        $city=addslashes(JRequest::getVar('city'));
        $city=trim($city);
        $querytown='SELECT `id` FROM `#__store_town` WHERE `name` LIKE "'.$city.'" LIMIT 1';
        $db->setQuery($querytown);
        $townid=$db->LoadObject();
        if (count($townid)>0){
            $townid=$townid->id;
        }else{
            $querytown='INSERT INTO `#__store_town` (`name`) VALUES ("'.$city.'")';
            $db->setQuery($querytown);
            $townid=$db->query();
            $townid=$db->insertid();
        }
        /*
        echo $townid."<br>".$querytown;
        die;
        */
        
        //Добавить пользователя в таблицу поставщиков
        $inn=JRequest::getVar('inn');
        $ogrn=JRequest::getVar('ogrn');
        $email=JRequest::getVar('email');
        $nameooo=addslashes(JRequest::getVar('nameooo'));
        $query='INSERT INTO `#__store_seller` (`townid`,`name`,`userid`,`inn`,`email`,`ogrn`)';
        $query.=' VALUES("'.$townid.'","'.$nameooo.'","'.$id.'","'.$inn.'","'.$email.'","'.$ogrn.'")';
        $db->setQuery($query);
        $db->query();
        
        //Сгенерировать код для активации и сохранить его в базе пользователей joomla
        $ssh=md5(uniqid($email, true));
        $query=$db->getQuery(true);
        $fields=array(  
            $db->quoteName('activation').'='.$db->quote($ssh)
        );
        $condition=array(
            $db->quoteName('id').'='.$db->quote($id)
        );
        $query->update('`#__users`')->set($fields)->where($condition);
        $db->setQuery($query);
        $resultssh=$db->execute();
        
        
        
        //Отправить письмо для активации учетной записи
        $mailer=JFactory::getMailer();
        $mailer->isHtml(true);
        $config = & JFactory::getConfig();
        $mailer->setSender(array('no-reply@sklad.kretex.ru',addslashes($config->fromname)));
        $mailer->addRecipient($email);
        $mailer->setBody('
        <p>Здравствуйте, '.$login.',</p>
        <p></p>
        <p>
        Благодарим вас за регистрацию на сайте '.addslashes($config->fromname).'. Ваша учётная запись создана, но должна быть активирована прежде, чем вы сможете ею воспользоваться.
        Чтобы активировать учётную запись, перейдите по ссылке ниже, или скопируйте её в адресную строку браузера:
        '.JURI::base()."index.php?option=com_storecable&task=registrseller.activate&view=registrseller&token=".$ssh.'
        </p> 
        <p>
        После активации вы сможете входить на сайт '.JURI::base().' с помощью указанных ниже логина и пароля:
        </p>
        <p>Логин: '.$login.'</p>
        <p>Пароль: '.$password_base.'</p>
        ');    
        $mailer->send();
        
        //Показать дальйшие инструкции
        $this->setMessage("Учётная запись для вас была создана. На указанный при регистрации адрес электронной почты была отправлена ссылка для её активации. Обратите внимание, что необходимо активировать учётную запись, перейдя по содержащейся в письме ссылке. Только после этого вы сможете проходить авторизацию на сайте под вашим логином и паролем.");
        $this->setRedirect('index.php');
        return false;
        
        //$this->setRedirect(JRoute::_('index.php?option=com_users&view=profile&layout=edit', false));
        
        //echo $query." - ".$id;
    }
    
//Активация пользователя
    public function activate(){
        //Запросить токен из базы
        $token=JRequest::getVar('token');
        $db=JFactory::getDBO();
        $query=$db->getQuery(true);
        $query->select('`id`');
        $query->from('`#__users`');
        $query->where('`activation`="'.$token.'"');
        $query->limit("1");
        $db->setQuery($query);
        $res=$db->LoadObject();
        //Если такого токена нет, то выдать ошибку
        if (count($res)==0){
            $this->setMessage("Неверный параметр. Пользователь уже активирован или неправильная ссылка для активации", 'warning');
            $this->setRedirect('index.php');
            return false;
        }
        //Активация пользователя
        $query=$db->getQuery(true);
        $fields=array(
            $db->quoteName('block').'='.$db->quote("0"),
            $db->quoteName('activation').'='.$db->quote("")
        );
        $where=array(
            $db->quoteName('id').'='.$db->quote($res->id)
        );
        $query->update('`#__users`')->set($fields)->where($where);
        $db->setQuery($query);
        $res=$db->execute();
        if ($res!='1'){
            $this->setMessage("Что-то пошло не так. Попробуйте обновить страницу", 'warning');
            $this->setRedirect('index.php');
            return false;
        }else{
            $this->setMessage("Ваша учетная запись активирована. Вы можете войти на сайт под своим логином и паролем, указанными при регистрации.");
            $this->setRedirect('index.php');
            return false;
        }
        
    }    
}