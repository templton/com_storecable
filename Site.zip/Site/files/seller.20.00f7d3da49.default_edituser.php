<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
// Загружаем тултипы.
JHtml::_('behavior.tooltip');

JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
			Joomla.submitform(task, document.getElementById("item-form"));
	};
');

?>


<h1>Контрагент <?php echo $this->seller->name; ?></h1>
<form action="<?php echo JRoute::_('index.php?option=com_storecable&layout=edit&id=' . (int) $this->item->id); ?>" method="post" name="adminForm" id="item-form">
    <?php
    print_r($this->seller);
    ?>
    <div>
        <input type="hidden" name="task" value="" />
        <?php echo JHtml::_('form.token'); ?>
    </div>
</form>