<?php
class FN_API
{
    var $host = "http://fornost.ru/partner/api/";
    var $user_login;
    var $user_password;
    var $site_id = 0;

    var $logged_in = false;

    var $error_array = array('Error'=>'Login or password are incorrect');

    function FN_API($login,$password)
    {
        $this->user_login = $login;
        $this->user_password = $password;

        $json = $this->send_request('login');
        $data = json_decode($json,true);
        if(!empty($data['success']))
        {
            $this->logged_in = true;
            //echo "Авторизация прошла успешно!";
        }
        else {
            //echo "Неавторизованно";
        }
    }

    function checkPrice($cart)
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['site_id'] = $this->site_id;
            $vars['cart'] = $cart;
            $json = $this->send_request('check_price',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    function getGoodsInfo($ids)
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['ids'] = $ids;
            $json = $this->send_request('get_product_info',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    function submitOrder($cart,$region,$fio,$tel,$mail='',$addr = '',$timezone = '')
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['site_id'] = $this->site_id;
            $vars['cart'] = $cart;
            $vars['region'] = $region;
            $vars['fio'] = $fio;
            $vars['tel'] = $tel;
            $vars['mail'] = $mail;
            $vars['addr'] = $addr;
            $vars['timezone'] = $timezone;
            $json = $this->send_request('submit_order',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    function cancelOrder($order_id)
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['order_id'] = $order_id;
            $json = $this->send_request('cancel_order',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    function getProductsForIDs($ids)
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['ids'] = $ids;
            $json = $this->send_request('get_products_for_ids',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    function checkOrder($cart)
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['site_id'] = $this->site_id;
            $vars['cart'] = $cart;
            $json = $this->send_request('check_order',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    function getOrderInfo($order_id)
    {
        if($this->logged_in)
        {
            $vars = array();
            $vars['site_id'] = $this->site_id;
            $vars['order_id'] = $order_id;
            $json = $this->send_request('get_order_info',$vars);
            $data = json_decode($json,true);
            return $data;
        }
        return $this->error_array;
    }

    private function send_request($func_name,$vars=array())
    {
        $send_string = $this->host.'?func='.$func_name;
        if(!empty($vars))
        {
            foreach($vars as $k=>$v)
            {
                $send_string .= '&'.$k.'='.urlencode($v);
            }
        }
        $send_string .= '&pass='.$this->user_password;
        $send_string .= '&login='.$this->user_login;

        $send_string = str_replace(" ","+",$send_string);

        $result = file_get_contents($send_string);
        return $result;
    }
}
?>