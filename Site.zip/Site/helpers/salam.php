<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 * Component helper
 * @author Саламатов Дмитрий Викторович
 */
class Salam
{
    
    function __construct()
    {
        //$db=JFactory::getDBO();    
    }
    
//Загрузка файлов на сервер
//$dest - куда копировать файлы
//$filenameprefix - префикс для имени файлов
static function uploadfile($uploaddir,$filenameprefix=""){
    $data=new stdClass();
    $data->ok="ok";
    $data->error=false;
    
    foreach($_FILES as $file){
        $newfile=$filenameprefix.'.'.basename($prefix.$file['name']);
        if( move_uploaded_file( $file['tmp_name'], $uploaddir.'/'. $newfile ) ){
            $data->filepath[]=$file['tmp_name'].$uploaddir.'/'.$newfile;
            $data->filename[]=$newfile;
        }else{
            $data->error=true;
        }
    }
    
    return $data;
}

//Список файлов в директории
static function getFilesDir($dir){
    $f = scandir($dir);
    foreach ($f as $file){
        if ($file=='.' || $file=='..') {continue;}
        $data[]=$file;
    }
    return $data;
}

//Список html файлов в директории
static function getFilesHtmlDir($dir){
    $f = scandir($dir);
    foreach ($f as $file){
    if(preg_match('/\.(php)/', $file))
        {
            echo $file.'<br/>';
        }
    }
}
    
}