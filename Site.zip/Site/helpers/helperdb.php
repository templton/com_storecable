<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 * Component helper
 * @author Саламатов Дмитрий Викторович
 */
class StoreHelperDB
{
    
    function __construct()
    {
        //$db=JFactory::getDBO();    
    }
    
//Получить значения полей заданной таблицы по id 
static function getDataTable($table, $id){
    $db=JFactory::getDBO();
    $query='SELECT * FROM `#__'.$table.'` WHERE `id`="'.$id.'"';
    $db->setQuery($query);
    $result=$db->LoadObject();
    return $result;
}

//Удалить запись из таблицы по id
static function delete($table,$id){
    $db=JFactory::getDBO();
    $query='DELETE FROM `#__'.$table.'` WHERE `id`="'.$id.'"';
    $db->setQuery($query);
    return $db->query();
}
    
   
}