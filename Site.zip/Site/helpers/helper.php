<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 * Component helper
 * @author Саламатов Дмитрий Викторович
 */
class StoreHelper
{
    
    function __construct()
    {
        //$db=JFactory::getDBO();    
    }
    
    static function getToken($name)
    {
        $_SESSION[$name] = md5(uniqid());
        return $_SESSION[$name];
    }
    
//Определить id города
static function getTownId($name){
    $db=JFactory::getDBO();
    $query='SELECT `id` FROM `#__store_town` WHERE `name` LIKE "'.$name.'"';
    $db->setQuery($query);
    $data=$db->LoadObject();
    if (count($data)>0){
        return $data->id;
    }else{
        return 0;
    }
}
    
    //Проверить существование логина
    static function testlogin($login)
    {
        $db=JFactory::getDBO();    
            $query='SELECT `username` FROM `#__users` WHERE `username` LIKE "'.$login.'"';
            $logins=$db->setQuery($query)->LoadObjectList();
            if (count($logins)>0)
                {return "1";}
                else
                {return "0";}
    }
    
    //Проверить существование email
    static function testemail($email, $id=0)
    {
        $db=JFactory::getDBO();    
            $query='SELECT `id`,`email` FROM `#__users` WHERE `email` LIKE "'.addslashes ($email).'"';
            if ($id>0){$query.=' AND `id`<>"'.$id.'"';}
            $emails=$db->setQuery($query)->LoadObjectList();
            if (count($emails)>0)
                {return "1";}
                else
                {return $emails[0]->id;}
    }    
    
//Проверить существование ИНН
//Если есть id, то проверяем всех, кроме id
    static function testinn($inn, $id=0)
    {
        $db=JFactory::getDBO();    
            $query='SELECT `id`,`inn` FROM `#__store_seller` WHERE `inn` LIKE "'.addslashes ($inn).'"';
            if ($id>0){
                $query.=' AND `id`<>"'.$id.'"';
            }
            $inn=$db->setQuery($query)->LoadObjectList();
            if (count($inn)>0)
                {return "1";}
                else
                {return $inn[0]->id;}
    }
    
//Проверить существование ОГРН
    static function testogrn($ogrn, $id=0)
    {
        $db=JFactory::getDBO();    
            $query='SELECT `id`,`ogrn` FROM `#__store_seller` WHERE `ogrn` LIKE "'.addslashes ($ogrn).'"';
            if ($id>0){
                $query.=' AND `id`<>"'.$id.'"';
            }
            $ogrn=$db->setQuery($query)->LoadObjectList();
            if (count($ogrn)>0)
                {return "1";}
                else
                {return $ogrn[0]->id;}
    }                    
    
    //Получить данные Поставщика
    //без параметров, занчит, поставщик - текущий авторизованный пользователь
    //$userid - связанный с поставщиком пользователь joomla
    //$id - конкретный поставщик
    static function getDataSeller($userid=0,$id=0)
    {
        if ($userid=='0'){
            $userid=JFactory::getUser()->id;
        }
        $db=JFactory::getDBO();
        $query=$db->getQuery(true);
        $query->select('`a`.`name` as `name`,`a`.`userid` as `userid`,`a`.`id` as `id`,
                        `a`.`inn` as `inn`,`a`.`townid` as `townid`,`a`.`street` as `street`,
                        `a`.`house` as `house`,`a`.`bilding` as `bilding`,`a`.`seller` as `seller`,
                        `a`.`maker` as `maker`,`a`.`mode` as `mode`,`a`.`phone` as `phone`,
                        `a`.`office` as `office`,`a`.`email` as `email`,`a`.`site` as `site`,
                        `a`.`ogrn` as `ogrn`,`a`.`face` as `face`,
                        `a`.`logo` as `logo`,`a`.`about` as `about`,
                        `a`.`logopathserver` as `logopathserver`,
                        `b`.`name` as `town`
                        ');
        $query->from('`#__store_seller` as `a`');
        $query->join('inner','`#__store_town` as `b` ON `b`.`id`=`a`.`townid`');
        if ($id>0){
            $query->where('`a`.`id`="'.$id.'"');    
        }else{
            $query->where('`a`.`userid`="'.$userid.'"');   
        }
        $data=$db->setQuery($query)->LoadObject();
        //echo $query;
        //print_r($data);
        //Разбить телефоны
        if (($data->phone)){
            $data->phone=explode('|',$data->phone);   
        }
        //Разбить мыло
        $data->email=explode('|',$data->email);
        //Разбить график работы
        $data->mode=explode('|',$data->mode);
        //Разобрать контактных лиц
        $data->face=base64_decode($data->face);
        $data->face=explode('|',$data->face);
        for ($i=0;$i<count($data->face);$i++){
            $data->face[$i]=json_decode($data->face[$i]);        
        }
        return $data;
    }
    
    //Получить данные организации по имени
    static function getSeller($name,$end='',$begin='')
    {
        if ($end=='1'){$end='%';}
        if ($begin=='1'){$begin='%';}
        $db=JFactory::getDBO();
        $query='SELECT * FROM `#__store_seller` WHERE `name` LIKE "'.$begin.addslashes ($name).$end.'" LIMIT 1';
        $db->setQuery($query);
        $data=$db->LoadObject();
        return $data;
    }    
           
    
    
    //Получить склад Поставщика
    static function getStore($userid=0)
    {
        if ($userid==0){
            $id=self::getDataSeller()->id;//текущий поставщик   
        }
        
        //Пагинация. Если в запросе есть start, countstr, то разбиваем страницу
        
        $db=JFactory::getDBO();
        $query='SELECT * FROM `#__store_store` WHERE `sellerid`="'.$id.'"';
        $db->setQuery($query);
        $store=$db->LoadObjectList();
        return $store;
    }
    
    
    //Получить список всех видов кабелей в базе
    //Если есть $term, то поиск по начальным буквам
    //Если есть $makerid, то исключить из полученного списка те кабели, которые уже есть в таблице Производителя store_cablemaker
    static function getTypesCable($term='',$makerid=0)
    {
        $db=JFactory::getDBO();
        $query='SELECT `a`.`name` as `name`, `b`.`name` as `cablekv` FROM `#__store_cable` as `a`';
        $query.=' LEFT JOIN `#__store_cablekv` as `b` ON `b`.`id`=`a`.`cablekvid`';
        if (strlen($term)>0){
            $query.=' WHERE `a`.`name` LIKE "'.addslashes ($term).'%"';
            //Исключить кабели, которые есть в таблице store_cablemaker
            if ($makerid>0){
                $query.=' AND `a`.`id` NOT IN (
                    SELECT `c`.`cableid` FROM `#__store_cablemaker` as `c` WHERE `c`.`makerid`="'.$makerid.'"
                )';
            }    
        }
        //echo "<br>".$query."<br>";
        
        $data=$db->setQuery($query)->LoadObjectList();
        return $data;
    }
    
    //Получить список всех производителей
    //Если задан $term, то выполнить полнотекстный поиск %%
    static function getMakers($term='')
    {
        $db=JFactory::getDBO();
        $query='SELECT * FROM `#__store_seller` WHERE `maker`="1"';
        if (strlen($term)>0){
            $query.=' AND `name` LIKE "%'.addslashes ($term).'%"';    
        }
        $data=$db->setQuery($query)->LoadObjectList();
        return $data;
    }
    
//Получить id записи любой таблицы по заданному 1-му полю через LIKE
    static function getId($table,$field,$val)
    {
        $db=JFactory::getDBO();
        $query='SELECT `id` FROM `#__'.$table.'` WHERE `'.$field.'` LIKE "'.addslashes ($val).'"';
        $data=$db->setQuery($query)->LoadObject();
        //echo $query;
        return $data->id;
    }
    
//Получить id кабеля по марке - не поддерживается
    static function getCableId($cable)
    {
        $id=self::getId('store_cable','name',$cable);
        return $id;
    }
    
//Внести позицию кабеля на склад
    static function addCable($data)
    {
        unset($res);
        $makerid=0;
        $cableid=0;
        $res['err']='0';
        $res['mes']='';
        $makerid=self::getSeller($data->maker)->id;
        $db=JFactory::getDBO();
        $CSeller=self::getDataSeller();
        $cablesizeid=$data->cablesizeid;
        $cableid=self::getIdCable($data->cable);
        
        
        //Не найден Производитель
        
        if (($makerid==0) && (strlen($data->maker)>0)){
            $res['err']='1';
            $res['sad']=15;
            $res['mes']='Проверьте правильность ввода Производителя! Производитель не найден!';
            return $res;
        }
        
        
        
        //Редактировать кабель
        if ($data->edit){
            $query = $db->getQuery(true);
            $fields = array(
                $db->quoteName('gost').'='.$db->quote($data->gost),
                $db->quoteName('count').'='.$db->quote($data->count),
                $db->quoteName('makerid').'='.$db->quote($makerid),
                $db->quoteName('price').'='.$db->quote($data->price)
            );
            $conditions = array(
                $db->quoteName('id').'="'.$data->id.'"' 
            );
            $query->update($db->quoteName('#__store_store'))->set($fields)->where($conditions);
            $db->setQuery($query);
            $res['result']=$db->execute();
            return ($res);
        }
        
        //Не найден макроразмер
        if ($cablesizeid==0){
            $res['err']='1';
            $res['mes']='Не найден макроразмер кабеля';
            return ($res);
        }
        
        //Не найден кабель
        if (!$cableid>0){
            $res['err']='1';
            $res['mes']='Проверьте правильность ввода марки кабеля! Кабель не найден!';
            $res['sad']=15;
            return ($res);
        }
        
        //echo $makerid;
        
        //Сперва проверить, если у поставщика эта позиция уже есть, то вывести ему сообщение об этом
        //Позиция считается такой же, если совпадают
        //1. Название
        //2. Производитель
        //3. ГОСТ
        $query='SELECT * FROM `#__store_store` WHERE `sellerid`="'.$CSeller->id.'" AND `cableid`="'.$cableid.'" AND `gost`="'.$data->gost.'"';
        //$query.=' AND `makerid`="'.$makerid.'"';
        $query.=' AND `makerid`="'.$makerid.'"';
        $query.=' AND `cablesizeid`="'.$cablesizeid.'"';
        //echo $query;
        $datares=$db->setQuery($query)->LoadObject();

        if (count($datares)>0){
           $res['id']=$datares->id;
           $res['mes']='Такой кабель уже есть на складе';
           $res['err']='1';
           $res['query']=$query;
           return $res; 
        }     
        
        //Кабеля на складе еще нет. Вносим
        $query='INSERT INTO `#__store_store` (`cableid`,`count`,`sellerid`,`makerid`,`gost`,`cablesizeid`,`price`)';
        $query.=' VALUES("'.$cableid.'","'.$data->count.'","'.$CSeller->id.'","'.$makerid.'","'.$data->gost.'","'.$cablesizeid.'","'.$data->price.'")';
        
        //$res->query=addslashes($query);
        
        
        $db->setQuery($query);
        $db->query();
        $res['id']=$db->insertid();
        $res['query']=$query;
        $res['cable']=$data->cable;
        $res['count']=$data->count;
        $res['gost']=$data->gost;
        $res['maker']=$data->maker;
        $res['price']=$data->price;
        $c=self::splitShortName($data->cable);
        $res['fullname']=$c->name.' '.self::getNameCablesize($cablesizeid);
        if (strlen($c->kv)>0){
            $res['fullname'].=' - '.$c->kv;
        }
        

        return $res;
    }
    
    //Получить имя макроразмера по id
    static function getNameCablesize($id){
        $db=JFactory::getDBO();
        $query='SELECT `name` FROM `#__store_cablesize` WHERE `id`="'.$id.'"';
        $db->setQuery($query);
        $name=$db->LoadObject();
        $name=$name->name;
        return $name;
    }
    
    //Получить полное название кабеля (марка кабеля + вольтаж) по id или по имени
    //$source - входящая величина
    //$mask='id', если входящая id
    //$mask='name', если входящая name
    //На выходе получится массив: имя кабеля с id + все вольтажи с id + все макроразмеры с id
    static function getCableName($source,$mask)
    {
        $db=JFactory::getDBO();
        $query='SELECT `a`.`id` as `id`,`a`.`name` as `cable`,`a`.`cablesizeid` as `cablesizeid`,`a`.`cablekvid` as `cablekvid`';
        $query.=', `b`.`name` as `cablekv`';
        //$query.=',`c`.`name` as `cablesize`';
        $query.=' FROM `#__store_cable` as `a`';
        $query.=' LEFT JOIN `#__store_cablekv` as `b` ON `b`.`id`=`a`.`cablekvid`';
        //$query.=' INNER JOIN `#__store_cablesize` as `c` ON `c`.`id`=`a`.`cablesizeid`';
        if ($mask=='id'){
            $where='WHERE `a`.`id`="'.$source.'"';
        }else{
            $where='WHERE `a`.`name` LIKE "'.$source.'"';
        }
        $query.=$where;
        $cable=$db->setQuery($query)->LoadObjectList();
//echo $query."<br><br>";

        for ($i=0;$i<count($cable);$i++){
            //$cable[$i]->shortname=$cable[$i]->cable.
            if ($cable[$i]->cablekvid>0){
                $cable[$i]->shortname=$cable[$i]->cable.' - '.$cable[$i]->cablekv;
            }else{
                $cable[$i]->shortname='none';
            }
            /*
            echo "<pre>";
            print_r($cable[$i]);
            echo "</pre>";
            */
        }
        return $cable;
        
        
    }
    
    
//Получить имя кабеля по id
    static function getCableNameShortOne($id){
        $db=JFactory::getDBO();
        $query=$db->getQuery(true);
        $query->select('CONCAT_WS (" ",`a`.`name`,`b`.`name`) as `cable`');
        $query->from('`#__store_cable` as `a`');
        $query->where('`a`.`id`="'.$id.'"');
        $query->join('left','`#__store_cablekv` as `b` ON `b`.`id`=`a`.`cablekvid`');
        $db->setQuery($query);
        $data=$db->LoadObject();
        return $data;
    }     
    
//Получить id макроразмера по наименованию
    static function getIdSize($size){
        $db=JFactory::getDBO();
        $query='SELECT `id` FROM `#__store_cablesize` WHERE `name` LIKE "'.$size.'"';
        $db->setQuery($query);
        $id=$db->LoadObject();
        $id=$id->id;
        return $id;
    }
    
//Получить id кабеля по короткому имени
    static function getIdCable($name){
        $cable=self::splitShortName($name);
        //print_r($cable);
        $db=JFactory::getDBO();
        $query='SELECT * FROM `#__store_cable` WHERE `name` LIKE "'.$cable->name.'"';
        if (strlen($cable->kv)>0){
            $query.=' AND `cablekvid`=(SELECT `id` FROM `#__store_cablekv` WHERE `name` LIKE "'.$cable->kv.'" LIMIT 1)';
        }
        $db->setQuery($query);
        if ($id=$db->LoadObject()){
            $id=$id->id;
        }else{
            $id=0;
        }
        return $id;
    }
    
//Получить id кабеля по полному имени ()
    static function getIdCableFull($name, $cablesizeid){
        $cable=self::splitShortName($name);
        //print_r($cable);
        $db=JFactory::getDBO();
        $query='SELECT * FROM `#__store_cable` WHERE `name` LIKE "'.$cable->name.'"';
        $query.=' AND `cablesizeid`="'.$cablesizeid.'"';
        //$query.=' AND `cablesizeid`=(SELECT `id` FROM `#__store_cablesize` WHERE `name` LIKE "'.$cablesizeid.'" LIMIT 1)';
        if (strlen($cable->kv)>0){
            $query.=' AND `cablekvid`=(SELECT `id` FROM `#__store_cablekv` WHERE `name` LIKE "'.$cable->kv.'" LIMIT 1)';
        }
        $db->setQuery($query);
        $id=$db->LoadObject();
        $id=$id->id;
        //echo $query;
        return $id;
    }    
     
    
//Разделить сокращенное имя кабеля на марку и вольтаж
    static function splitShortName($name){
        $res=new stdClass();
        $name=explode(' ',$name);
        $res->name=trim($name[0]);
        $kv=trim($name[count($name)-1]);
        if (strpos($kv,'кВ')){
            $res->kv=$kv;
        }else{
            $res->kv='';
        }
        return $res;
    }
    
//Получить список макроразмеров кабеля в виде выпадающего списка по id кабеля из таблицы store_cable
    static function getCableSizeSelect($id,$classname=''){
        $select='<select class="'.$classname.'">';
        $db=JFactory::getDBO();
        $query='SELECT `b`.`name` as `cablesize`, `b`.`id` as `id`';
        $query.=' FROM `#__store_cabledata` as `a`';
        $query.=' INNER JOIN `#__store_cablesize` as `b`';
        $query.=' ON `b`.`id`=`a`.`cablesizeid`';
        $query.=' WHERE `a`.`cableid`="'.$id.'"';
        $query.=' ORDER BY `cablesize`';
        $db->setQuery($query);
        $cablesize=$db->LoadObjectList();
        foreach ($cablesize as $item){
            $select.='<option value="'.$item->id.'">'.$item->cablesize.'</option>';
        }
        $select.='</select>';
        //echo $query;
        return $select;
    }    
    
//Сохранить данные пользователя
//Данные взять из массива $_GET
    static function saveuser(){
        //объединить телефоны
        $res=new stdClass();
        $res->error='0';
        
        //Получить id текущего Поставщика
        if (JRequest::getVar('sellerid')){
            $id=self::getDataSeller(0,JRequest::getVar('sellerid'))->id;
        }else{
            $id=self::getDataSeller()->id;
        }      
        
        $res->reguestid=$id;  
        
        //Проверить ИНН на уникальность
        $res->inn=self::testinn(JRequest::getVar('inn'),$id);
        if ($res->inn=='1'){
            $res->error='1';
            $res->errmes='ИНН уже используется';
            return $res;
        }
        //Проверить ОГРН на уникальность
        $res->ogrn=self::testogrn(JRequest::getVar('ogrn'),$id);
        if ($res->ogrn=='1'){
            $res->error='1';
            $res->errmes='ОГРН уже используется';
            return $res;
        }
        //Проверить телефон на уникальность
        
        $phone='';
        for ($i=0;$i<10;$i++){
            $cur=JRequest::getVar('phone-'.$i);
            if (strlen($cur)>0){
                $phone.=$cur.'|';
            }
        }
        //Убрать последнюю закрывашку
        if (strlen($phone)>10){
            $phone=substr($phone,0,strlen($phone)-1);
        }
        
        //объединить email
        $email='';
        for ($i=0;$i<10;$i++){
            $cur=JRequest::getVar('email-'.$i);
            if (strlen($cur)>0){
                //Проверить E-Mail на уникальность
                $res->testemail=self::testemail($cur, $id);
                if ($res->testemail=='1'){
                    $res->error='1';
                    $res->errmes='Электронный адрес '.$cur.' уже используется';
                    return $res;
                }
                $email.=$cur.'|';
            }
        }
        
        //echo $email;
        
        //Убрать последнюю закрывашку
        if (strlen($email)>10){
            $email=substr($email,0,strlen($email)-1);
        }
        
        //Собрать режим работы
        $work='';
        $work.=JRequest::getVar('wdbegin').'-'.JRequest::getVar('wdend');
        
        //Собрать пятницу
        //Собрать субботу
        $ptbegin=JRequest::getVar('ptbegin');
        $ptend=JRequest::getVar('ptend');
        if (strlen($ptbegin)>2){
            $work.='|'.$ptbegin.'-'.$ptend;
        }else{
            $work.='|0';
        }
        
        //Собрать субботу
        $sbbegin=JRequest::getVar('sbbegin');
        $sbend=JRequest::getVar('sbend');
        if (strlen($sbbegin)>2){
            $work.='|'.$sbbegin.'-'.$sbend;
        }else{
            $work.='|0';
        }
        
        //Собрать воскресенье
        $vsbegin=JRequest::getVar('vsbegin');
        $vsend=JRequest::getVar('vsend');
        if (strlen($vsbegin)>2){
            $work.='|'.$vsbegin.'-'.$vsend;
        }else{
            $work.='|0';
        }
        
        //Собрать контактных лиц - максимум 10 штук
        unset($face_data);
        for ($i=0;$i<10;$i++){
            //Собрать поля, которые были переданы
            unset($face);
            if (JRequest::getVar('face_fio'.$i)){
                $face['fio']       =JRequest::getVar('face_fio'.$i);
                $face['phone']     =JRequest::getVar('face_phone'.$i);
                $face['skype']     =JRequest::getVar('face_skype'.$i);
                $face['icq']       =JRequest::getVar('face_icq'.$i);
                $face['whatsupp']  =JRequest::getVar('face_whatsupp'.$i);
                $face_data.=json_encode($face)."|";
            }
        }
        //Убрать последнюю закрывашку
        if (strlen($face_data)>5){
            $face_data=substr($face_data,0,strlen($face_data)-1);
        }
        $face_data=base64_encode($face_data);
        $res->face_data=$face_data;
        
        //Построение запроса на обновление записи
        $db=JFactory::getDBO();
        $query=$db->getQuery(true);
        $fields=array(
            '`name`="'.addslashes(JRequest::getVar('namefirm')).'"',
            '`inn`="'.JRequest::getVar('inn').'"',
            '`street`="'.addslashes(JRequest::getVar('street')).'"',
            '`house`="'.addslashes(JRequest::getVar('house')).'"',
            '`bilding`="'.addslashes(JRequest::getVar('bilding')).'"',
            '`office`="'.addslashes(JRequest::getVar('office')).'"',
            '`site`="'.addslashes(JRequest::getVar('site')).'"',
            '`ogrn`="'.addslashes(JRequest::getVar('ogrn')).'"',
            '`face`="'.$face_data.'"',
            '`mode`="'.$work.'"',
            '`phone`="'.$phone.'"',
            '`email`="'.$email.'"',
        );
        $cond=array(
            '`id`="'.$id.'"'
        );
        $query->update('`#__store_seller`')->set($fields)->where($cond);
        //echo $query."<br>";
        //die;
        $db->setQuery($query);
        $result=$db->execute();

        
        $res->result=$result;
        $res->phone=$phone;
        $res->email=$email;
        $res->mode=$work;
        $res->id=$id;
        return $res;
    }
    
//Вспомогательная функция для создания условия    
static function setCondQuery($mas,$field){
    $data=' ( ';
    for ($i=0;$i<count($mas);$i++){
        $data.=$field.' LIKE '.$mas[$i];
        if ($i!=(count($mas)-1)) {$data.=' OR ';}   
    }
    $data.=' ) ';
    return $data;
}


static function getMainQuerySklad($cond){
    $db=JFactory::getDBO();
    //echo "<pre>";print_r($cond);echo "</pre>";
    
    //Логика поиска
    //Ищем по регулярным выражениям
    //Для cable     :   текстовые параметры - обязательны,  числовые - желательны
    //Для cablesize :   текстовые параметры - желательны,   числовые - обязательны
    //Для cablekv   :   все параметры - желательны
    //Дополнительно: если "кв" стоит после числового параметра, то "кв" в cable - желательный, а в cablekv - обязательный
    //Последовательность параметров должна быть соблюдена: P1 + P2 + P3. Местами параметры поиска менять нельзя
    
    //Подготовка - Если никаких параметров не пришло, то возврат
    
    //Определить id города, если он задан
     $intown=JRequest::getVar('intown');
        if (strlen($intown)>0){
            $intown=self::getTownId($intown);
            //echo $intown;
            $settown['name']=$_GET['intown'];
            $settown['id']=$intown;
            $_SESSION['settown']=$settown;
        }else{
            unset($_SESSION['settown']);
        }
    
    //1. Добавить к каждому параметру признак: text или num
    unset($p);
    for ($i=0;$i<count($cond->param);$i++){
        //echo $cond->param[$i]."<br>";
        if (preg_match("/[A-ZА-Я_]/i",$cond->param[$i])){
            $p[$i]['type']='text';
        }else{
            $p[$i]['type']='num';
        }
        $p[$i]['param']=$cond->param[$i];
    }
    //echo "<pre>";print_r($p);echo "</pre>";
    
    //2. Составить условие поиска для каждой таблицы
    unset($cable_condition);
    unset($cablesize_condition);
    unset($cablekv_condition);
    foreach($p as $item){
        $cable_condition.='('.$item['param'].')';
        $cablesize_condition.='('.$item['param'].')';
        $cablekv_condition.='('.$item['param'].')';
        if ($item['type']=='text'){
            //Проверка для параметра, содержащего "кв": если уже были какие-то параметры,
            //то данные параметр для cablr - необязательный, а для cablekv - обязательный
            if (preg_match("/.*((\++)|(\*+)).*кв\)$/i",$cable_condition)){
                $cable_condition.='*';
                $cablekv_condition.='+';
            }else{
                $cable_condition.='+';
                $cablekv_condition.='*';   
            }
            $cablesize_condition.='*';
        }else{
            $cable_condition.='*';
            $cablesize_condition.='+';
            $cablekv_condition.='*';
        }
        $cable_condition.='.*';
        $cablesize_condition.='.*';
        $cablekv_condition.='.*';
    }
    
    //Если последний параметр явно указывает на кв - ЧИСЛО+кв, то добавим обязательный поиск по cablekv
    $cablekv_condition_only='';
    if (preg_match("/.*\dкв$/i",$cond->param[count($cond->param)-1])){
        $cablekv_condition_only='.*('.$cond->param[count($cond->param)-1].')+';
    }
    //echo '$cable_condition='.$cable_condition."<br>";
    //echo '$cablesize_condition='.$cablesize_condition."<br>";
    //echo '$cablekv_condition='.$cablekv_condition."<br>";
    
    //3. Выберем все кабеля из базы, ссответствующие поиску
    $query=$db->getQuery(true);
    $select='`a`.`name` as `cable`,`a`.`id` as `cableid`,
            `c`.`name` as `cablesize`,`c`.`id` as `cablesizeid`,
            `d`.`name` as `cablekv`,`d`.`id` as `cablekvid`,
            `f`.`id` as `sellerid`,`f`.`name` as `seller`,
            CONCAT_WS(" ",`a`.`name`,`c`.`name`,`d`.`name`) as `fullname`';
    if ($cond->onsklad=='1'){
        $select.=',
            `e`.`count` as `count`,
            `g`.`name` as `town`
        ';
    }
    $query->select($select);
    //Выбрать cable
    $query->from('`#__store_cable` as `a`');
    if (strlen($cable_condition)>0){
        $query->where('LOWER (`a`.`name`) REGEXP LOWER ("'.$cable_condition.'")');   
    }
    //Добавить cablesize
    $query->join('inner','`#__store_cabledata` as `b` ON (`b`.`cableid`=`a`.`id`)');
    if (strlen($cablesize_condition)>0){
        $query->join('inner','`#__store_cablesize` as `c` ON (`c`.`id`=`b`.`cablesizeid` AND (LOWER (`c`.`name`) REGEXP LOWER("'.$cablesize_condition.'")))');   
    }else{
        $query->join('inner','`#__store_cablesize` as `c` ON (`c`.`id`=`b`.`cablesizeid`)');
    }
    //Добавить cablekv
    if (strlen($cablekv_condition_only)>0){
        $query->join('inner','`#__store_cablekv` as `d` ON (`d`.`id`=`a`.`cablekvid` AND (LOWER (`d`.`name`) REGEXP LOWER("'.$cablekv_condition_only.'")))');   
    }else{
        $query->join('left','`#__store_cablekv` as `d` ON (`d`.`id`=`a`.`cablekvid` AND (LOWER (`d`.`name`) REGEXP LOWER("'.$cablekv_condition.'")))');
    }
    
    //4. Из выбранных:
    if ($cond->onsklad=='1'){
        //Для поиска по кол-ву выберем те, которые есть на складах + добавить город, если он задан
        $query->join('inner','`#__store_store` as `e` ON (`e`.`cableid`=`a`.`id` AND `e`.`cablesizeid`=`c`.`id`)');
        //Добавить город, если задан
        $town_condition='';
        if ($settown['id']>0){
            $town_condition=' AND `f`.`townid`="'.$settown['id'].'"';
        }
        //Подключаем поставщиков
        $query->join('inner','`#__store_seller` as `f` ON (`f`.`id`=`e`.`sellerid` '.$town_condition.')');
        //Подключить название города
        $query->join('inner','`#__store_town` as `g` ON `g`.`id`=`f`.`townid`');
        //Сортировка: сначала по кабелю, потом по остаткам
        $query->order('`a`.`name`');
        $query->order('`e`.`count` DESC');
    }else{
        //Для поиска по Производителю выберем те, для которых заявлен Производитель
        //Подключаем таблицу Кабель<->Производитель
        $query->join('inner','`#__store_cablemaker` as `h` ON (`h`.`cableid`=`a`.`id`)');
        //Подключаем поставщиков
        //Добавить город, если задан
        $town_condition='';
        if ($settown['id']>0){
            $town_condition=' AND `f`.`townid`="'.$settown['id'].'"';
        }
        $query->join('inner','`#__store_seller` as `f` ON (`f`.`id`=`h`.`makerid` '.$town_condition.')');
        $query->order('`a`.`name`');
    }
    
    //echo $query."<br>";
    return $query;
}


   
    
//Получить query всего склада 
    public function getQuerySklad($cond){
        $db=JFactory::getDBO();
        
        //Определить id города
        $intown=JRequest::getVar('intown');
        if (strlen($intown)>0){
            $intown=self::getTownId($intown);
            //echo $intown;
            $settown['name']=$_GET['intown'];
            $settown['id']=$intown;
            $_SESSION['settown']=$settown;
        }else{
            unset($_SESSION['settown']);
        }
        
        if ($cond->onseller=='1'){
            
            //Поиск по Производителям
            $query=$db->getQuery(true);
            $query->select('`b`.`name` as `cable`, `b`.`id` as `cableid`,
                            `e`.`name` as `cablekv`,
                            `f`.`name` as `seller`,`f`.`id` as `sellerid`,
                            CONCAT_WS(" ",`b`.`name`,`e`.`name`) as `fullname`
                            ');
            $query->from('`#__store_cablemaker` as `a`');
            $query->join('inner','`#__store_cable` as `b` 
                            ON (`a`.`cableid`=`b`.`id` AND `b`.`name` LIKE "'.$cond->name.'%")');
            //Добавить вольтаж
            $query->join('left','`#__store_cablekv` as `e` ON `e`.`id`=`b`.`cablekvid`');
            //Добавить имя поставщика
            $query->join('inner','`#__store_seller` as `f` ON `f`.`id`=`a`.`makerid`'); 
            //echo $query;
        }else{
            
            //Поиск по кол-ву
            $query=$db->getQuery(true);
            $query->select('`c`.`name` as `cablesize`, `c`.`id` as `cablesizeid`,
                            `b`.`name` as `cable`, `b`.`id` as `cableid`,
                            `e`.`name` as `cablekv`,
                            `a`.`id` as `id`,`a`.`count` as `count`,`a`.`makerid` as `makerid`,`a`.`price` as `price`,
                            `f`.`name` as `seller`,`f`.`id` as `sellerid`,
                            `h`.`name` as `town`,
                            CONCAT_WS(" ",`b`.`name`,`c`.`name`,`e`.`name`) as `fullname` ');
            //Берем весь склад
            $query->from('`#__store_store` as `a`');
        
            //наименование кабеля - связать с главной таблицей и условием из поиска
                unset($b);
                $b[]='`a`.`cableid`=`b`.`id`';
                //Полнотекстный поиск названия кабеля
                //echo $cond->name."<br>";
                if ($cond->name){$b[]='`b`.`name` LIKE "%'.$cond->name.'%"';}
                //
                if ($cond->cableid){$b[]='`b`.`id`="'.$cond->cableid.'"';}
                $b_condition=implode(' AND ',$b);
                $query->join('inner','`#__store_cable` as `b` ON ('.$b_condition.')');
        
            //Добавить вольтаж
            $query->join('left','`#__store_cablekv` as `e` ON `e`.`id`=`b`.`cablekvid`');
            
            //Если задан город нахождения склада, то добавим в условие
            if ($intown>0){
                $whereintow=' AND `townid`="'.$intown.'"';
            }
        
            //Добавить таблицу поставщика
            $query->join('left','`#__store_seller` as `f` ON `f`.`id`=`a`.`sellerid`'.$whereintow);
        
            //размер кабеля - связат с главной таблицей и условие из поиска (если оно есть)
            if (strlen($cond->cablesize)>0){
                $wheresize=' AND `c`.`name` LIKE "'.$cond->cablesize.'%"';
            }else{
                $wheresize='';
            }
            
            if ($cond->cablesizeid>0){
                $wheresize=' AND `c`.`id` = "'.$cond->cablesizeid.'"';
            }else{
                $wheresize='';
            }        
            
            //Полнотекстный поиск по условию для главного поиска сайта
            if (strlen($cond->size)>0){
                $wheresize=' AND `c`.`name` LIKE "%'.$cond->size.'%"';
            }    
            
            $query->join('inner','`#__store_cablesize` as `c` ON (`c`.`id`=`a`.`cablesizeid` '.$wheresize.')');
        
            //Добавить город поставщика
            $query->join('inner','`#__store_town` as `h` ON `h`.`id`=`f`.`townid`');
        
            //$query->order('`b`.`name`');
            //$query->order('`c`.`name`');
            //$query->order('`e`.`name`');
            $query->order('`cable`');
            $query->order('`count` DESC');
        }
        //echo $query;
        return $query;        
    }
    
//Получить параметры поиска
static function getSearchParam(){
    $item=new stdClass();
    $param=array('onseller','onsklad',
                'name','size','seller',
                'cablesizeid','cableid','intown','cable');
    foreach($param as $key){
        if (JRequest::getVar($key)){
            $item->$key=JRequest::getVar($key);   
        }
    }
    /*
    $settown=$_SESSION['settown'];
    if (isset($settown['townname'])){
        $item->intown=$settown['townname'];
    }
    */
    /*
    echo "<pre>";
    print_r($item);
    echo "</pre>";
    */
    return $item;
} 

//Добавить в набор данных город Производителя (имя)
static function addMakerInData($data){
    $db=JFactory::getDBO();
    for ($i=0;$i<count($data);$i++){
        $query='SELECT `name`,`id` FROM `#__store_seller` WHERE `id`="'.$data[$i]->makerid.'" LIMIT 1';
        $db->setQuery($query);
        $data[$i]->maker=$db->LoadObject()->name;
        $data[$i]->makerid=$db->LoadObject()->id;
    }
    return $data;
}

//Получить запрос на выборку всех поставщиков
static function getQueryAllSeller($param){
    /*
    echo "<pre>";
    print_r($param);
    echo "</pre>";
    */
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->select('`a`.`name` as `name`,`a`.`seller` as `seller`,`a`.`maker` as `maker`,
                    `a`.`id` as `id`, `a`.`userid` as `userid`,
                    `b`.`name` as `town`,
                    `c`.`username` as `username`
                    ');
    $query->from('`#__store_seller` as `a`');
    
    //Добавить город
    $query->join('inner','`#__store_town` as `b` ON `a`.`townid`=`b`.`id`');
    
    //Добавить данные связанного пользователя Joomla
    $query->join('left','`#__users` as `c` ON `c`.`id`=`a`.`userid`');
    
    //Фильтр типу контрагента: поставщик, производитель, все
    unset($where);
    if ($param->kontragent=='maker'){
        $where[]='`maker`="1"';
    }
    if ($param->kontragent=='seller'){
        $where[]='`maker`="0"';
    }
    if (count($where)>0){
        $query->where($where);   
    }
    
    //Сортировка
    unset($orderby);
    if (strlen($param->orderby)>1){
        $orderby[]=$param->orderby.' '.$param->desc;
    }
    if (count($orderby)>0){
        $query->order($orderby);
    }
    //echo $query;
    return $query;
}

//Внести вид кабеля в базу Производителя
static function addMakerCable($cond){
    $db=JFactory::getDBO();
    $res=new stdClass();
    $query=$db->getQuery(true);
    
    //Если такой кабель уже есть в базе Контрагента, то вернем ошибку и сообщение
    $query->select('`cableid`');
    $query->from('`#__store_cablemaker`');
    $query->where('`makerid`="'.$cond->makerid.'" AND `cableid`="'.$cond->cableid.'"');
    $query->limit("1");
    $db->setQuery($query);
    $cableid=$db->LoadObject()->cableid;
    if ($cableid>0){
        $res->error=1;
        $res->errmess="Кабель ".self::getDataTable('store_cable',$cableid)->name." уже есть в базе контрагента";
        //print_r(getDataTable('store_cable',$id));
        $res->result='0';
        // //print_r($res);
        return $res;
    }
    
    $query=$db->getQuery(true);
    $field=array(
        $db->quoteName('makerid').'='.$db->quote($cond->makerid),
        $db->quoteName('cableid').'='.$db->quote($cond->cableid)
    );   
    $query->insert('`#__store_cablemaker`')->set($field);
    $db->setQuery($query);
    if($db->execute()){$res->result='1';}else{$res->result='0';};
    $res->id=$db->insertid();
    $res->cableid=$cond->cableid;
    $res->makerid=$cond->makerid;
    return $res;
}       


//Удалить кабель из базы Производителя
static function deleteMakerCable($cond){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->delete('`#__store_cablemaker`');
    $query->where('`cableid`="'.$cond->cableid.'" AND `makerid`="'.$cond->makerid.'"');
    //$query='DELETE FROM `#__store_cablemaker` WHERE '.'`cableid`="'.$cond->cableid.'" AND `makerid`="'.$cond->makerid.'"';
    $db->setQuery($query);
    return $db->execute();
}

//Получить значения полей заданной таблицы и id 
static function getDataTable($table, $id){
    $db=JFactory::getDBO();
    $query='SELECT * FROM `#__'.$table.'` WHERE `id`="'.$id.'"';
    $db->setQuery($query);
    $result=$db->LoadObject();
    return $result;
}

//Получить все виды кабелей производителя
static function getMakerCableQuery($makerid){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->select('`b`.`name` as `name`,`a`.`id` as `cablemakerid`,`c`.`name` as `cablekv`');
    $query->from('`#__store_cablemaker` as `a`');
    $query->join('inner','`#__store_cable` as `b` ON `a`.`cableid`=`b`.`id`');
    $query->join('left','`#__store_cablekv` as `c` ON `b`.`cablekvid`=`c`.`id`');
    $query->where('`makerid`="'.$makerid.'"');
    $query->order("`b`.`name`");
    return $query;
    //CONCAT_WS(" ",`b`.`name`,`c`.`name`,`e`.`name`) as `fullname` ');
}

//Создать полное имя в массиве объектов, по полям (соединить через пробел)
static function getFullName($object,$names){
    for ($i=0;$i<count($object);$i++){
        //Проверить, чтобы все присланные поля сущестовавили и соединить их
        $fullname='';
        foreach ($names as $item){
            if ($object[$i]->$item){
                $fullname.=$object[$i]->$item.' ';
            }
        }
        //убрать последний пробел
        if (strlen($fullname)>0){
            $fullname=substr($fullname,0,strlen($fullname)-1);
            $object[$i]->fullname=$fullname;
        }
        
    }
    return $object;
}

//Удалить контрагента
static function deleteUser($sellerid){
    $db=JFactory::getDBO();
    $result=new stdClass();
    
    //Получить id пользователя Joomla!
    $query='SELECT `userid` FROM `#__store_seller` WHERE `id`="'.$sellerid.'" LIMIT 1';
    $db->setQuery($query);
    $userid=$db->LoadObject()->userid;
    //echo "userid=".$userid."<br>";
    
    //1. Удалить данные из таблицы Производителей - store_cablemaker
    $query=$db->getQuery(true);
    $query->delete('`#__store_cablemaker`')->where('`makerid`="'.$sellerid.'"');
    $db->setQuery($query);
    $result->cablemaker=$db->execute();
    
    //2. Удалить данные со склада - store_store
    $query=$db->getQuery(true);
    $query->delete('`#__store_store`')->where('`sellerid`="'.$sellerid.'"');
    $db->setQuery($query);
    $result->storestore=$db->execute();
    
    //3. Удалить данные из таблицы Контрагентов - store_seller
    $query=$db->getQuery(true);
    $query->delete('`#__store_seller`')->where('`id`="'.$sellerid.'"');
    $db->setQuery($query);
    $result->storeseller=$db->execute();
    
    //4. Удалить связанного пользователя Joomla
    $query=$db->getQuery(true);
    $query->delete('`#__users`')->where('`id`="'.$userid.'"');
    $db->setQuery($query);
    $result->users=$db->execute();
    
    return $result;
}


//Получить запрос на несвязанных пользователей Joomla!
static function getNotRelativeQuery(){
    $query='SELECT `a`.`id` as `value`,CONCAT_WS(", id=",`a`.`username`,`a`.`id`) as `text` 
    FROM `#__users` as `a` 
    WHERE `a`.`id` NOT IN 
    (
        SELECT `b`.`userid` FROM `#__store_seller` as `b`
    ) 
    AND `a`.`username` NOT LIKE "admin"
    ';
    return $query;
}

//Привязать нового пользователя к Контрагенту
static function setRelativeUser($sellerid,$userid){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->update('`#__store_seller`')
        ->set('`userid`="'.$userid.'"')
        ->where('`id`="'.$sellerid.'"');
    $db->setQuery($query);
    return $db->execute();
}


//Привязать нового пользователя к Контрагенту
static function unsetRelativeUser($sellerid){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->update('`#__store_seller`')
        ->set('`userid`="0"')
        ->where('`id`="'.$sellerid.'"');
    $db->setQuery($query);
    return $db->execute();
}

//Поиск элемента в массиве
static function arraySearch($field,$val,$array){
    /*
    echo "Кол-во=".count($array)."<br>";
    print_r($array);
    echo "<br>";
    */
    foreach ($array as $key=>$el)
    {
        //echo $array[$key]['id']."<br>";
        if ($array[$key][$field]==$val){
            return $key;
        }
    }
    return '-100';
}

//Отправка почты
static function sendemail($Recipient,$sender=array('no-reply@sklad.kretex.ru', 'Name of sender'),$body){
    //Отправить письмо для активации учетной записи
    $mailer=JFactory::getMailer();
    $mailer->isHtml(true);
    $config = & JFactory::getConfig();
    $mailer->setSender($sender);
    $mailer->addRecipient($Recipient);
    $mailer->setBody($body);    
    $mailer->send();
}

//Получить параметр компонента
static function getParam($param){
    $db=JFactory::getDBO();
    $query='SELECT `val` FROM `#__store_settings` WHERE `name` LIKE "'.$param.'"';
    $db->setQuery($query);
    return $db->LoadObject()->val;
}

//Получить параметр компонента
static function getAllParam(){
    $db=JFactory::getDBO();
    $query='SELECT * FROM `#__store_settings`';
    $db->setQuery($query);
    $data=$db->LoadObjectList();
    $res=new stdClass();
    foreach ($data as $item){
        foreach ($item as $key=>$val){
            if ($key=='name'){
                $field=$val;
            }
            if ($key=='val'){
                $res->$field=$val;
            }
        }
    }
    return $res;
}

//Получить запрос на список заявок Производителей
//$filtr список полей для сортировки
static public function getOrdersQuery($param)
{
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->select('`a`.`id` as `id`, `a`.`datesend` as `datesend`,`a`.`datefeatured` as `datefeatured`,
            `a`.`status` as `status`, `a`.`description` as `description`,`a`.`sellerid` as `sellerid`,
            `b`.`name` as `name` ');
    $query->from('`#__store_setorder` as `a`');
    $query->join('inner','`#__store_seller` as `b` ON `a`.`sellerid`=`b`.`id`');
    unset($orderby);
    if (strlen($param->orderby)>1){
        $orderby[]=$param->orderby.' '.$param->desc;
    }else{
        $orderby[]='`status`, `datesend`,`name`';
    }
    $query->order($orderby);
    
    
    return $query;
}

//Получить детализацию заявки
static function getOrder($orderid){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->select('')
        ->from('');
}


//Получить список заявок для пользователя
static function getBannerOrders($sellerid){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->select('
            `a`.`id` as `bannerid`, `a`.`dateorder` as `dateorder`, `a`.`bannerpath` as `bannerpath`,
            `a`.`positionid` as `positionid`, `a`.`status` as `status`,`a`.`description` as `description`,
            `a`.`datebegin` as `datebegin`,`a`.`dateend` as `dateend`,`a`.`period` as `period`,
            `b`.`title` as `position` 
        ');
    $query->from('`#__store_banner` as `a`');
    $query->where('`sellerid`="'.$sellerid.'"');
    $query->join('inner','`#__store_position` as `b` ON `a`.`positionid`=`b`.`id`');
    $db->setQuery($query);
    $data=$db->LoadObjectList();
    return $data;
}

//Получить список всех заявок пользователей на баннеры
static function getBannerOrdersAll($onlyquery="0", $param=""){
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->select('
            `a`.`id` as `id`, `a`.`dateorder` as `dateorder`, `a`.`bannerpath` as `bannerpath`,
            `a`.`positionid` as `positionid`, `a`.`status` as `status`,`a`.`description` as `description`,
            `a`.`datebegin` as `datebegin`,`a`.`dateend` as `dateend`,`a`.`period` as `period`,
            `b`.`title` as `position`,
            `c`.`name` as `name` 
        ');
    $query->from('`#__store_banner` as `a`');
    $query->join('inner','`#__store_position` as `b` ON `a`.`positionid`=`b`.`id`');
    $query->join('inner','`#__store_seller` as `c` ON `a`.`sellerid`=`c`.`id`');
    unset($orderby);
    if (strlen($param->orderby)>1){
        $orderby[]=$param->orderby.' '.$param->desc;
    }else{
        $orderby[]='`status`, `dateorder`,`name`';
    }
    $query->order($orderby);
    if ($onlyquery=='1') {return $query;}
    $db->setQuery($query);
    $data=$db->LoadObjectList();
    return $data;
}

//Получить данные позиции
static function getPosition($id){
    $db=JFactory::getDBO();
    $query='SELECT * FROM `#__store_position` WHERE `id`="'.$id.'"';
    $db->setQuery($query);
    $data=$db->LoadObject();
    return $data; 
}
    
}