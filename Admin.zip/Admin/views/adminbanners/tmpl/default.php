<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
JHtml::_('behavior.tooltip');
//echo $this->orderby->desc;
$param=StoreHelper::getAllParam();
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
			Joomla.submitform(task, document.getElementById("item-form"));
	};
');

?>


<!-- HTML-код модального окна -->
<div id="modalDeleteDialog" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Заголовок модального окна -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title">Предупреждение</h4>
      </div>
      <!-- Основное содержимое модального окна -->
      <div class="modal-body">
        <p>
            Вы действительно хотите удалить заявку Производителя?
        </p>
      </div>
      <!-- Поле для подстановки if удаляемого пользователя -->
      <input type="hidden" name="deleteorder" id="deleteorder" value="" />
      <!-- Футер модального окна -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="closemodal">Отмена</button>
        <button type="button" class="btn btn-primary" onclick="deleteorder(jQuery('#deleteorder').val())" >Удалить Контрагента</button>
      </div>
    </div>
  </div>
</div>


<h1>Журнал заявок Баннеров</h1>

<form id="adminForm" name="adminForm" action="index.php?option=com_storecable&view=adminbanners" method="GET">
    <table class="adminlist table table-striped">
        <tr>
            <?php
                //определить, куда и какую поставить стрелочку сортировки
                if (strlen($this->filtr->orderby)>1){
                    //print_r($this->filtr);
                    if ($this->filtr->desc=='DESC'){
                            $class='down';
                        }else{
                            $class="up";
                        }
                    //
                    $name=$this->filtr->orderby;   
                }
            ?>
            <th class="<?php if ($name=='id') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('id')">ID</span></th>
            <th></th>
            <th></th>
            <!-- <th></th> -->
            <th class="<?php if ($name=='name') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('name')">Наименование организации</span></th>
            <th class="<?php if ($name=='dateorder') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('dateorder')">Дата подачи</span></th>
            <th class="<?php if ($name=='datebegin') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('datebegin')">Дата активации</span></th>
            <th class="<?php if ($name=='dateend') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('dateend')">Дата завершения</span></th>
            <th><span>Кол-во дней</span></th>
            <th><span class="">Баннер</span></th>
            <th class="<?php if ($name=='position') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('position')">Позиция</span></th>
            <th class="<?php if ($name=='status') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('status')">Статус</span></th>
            <th class="simple"><span class="">Примечание</span></th>
        </tr>
            <?php
                foreach ($this->items as $item){
                    ?>
                    <tr class="order<?php echo $item->id; ?>">
                    <td><?php echo $item->id; ?></td>
                    <td class="delplus1" onclick="deleteorder(<?php echo $item->id; ?>)"></td>
                    <td>
                        <?php if ($item->status=='0') { ?>
                            <input type="button" class="btn default orderok<?php echo $item->id; ?>" value="Подтвердить" onclick="orderOk(<?php echo $item->id; ?>,1)" />
                        <?php } else { ?>
                            <input type="button" class="btn default orderok<?php echo $item->id; ?>" value="Отменить" onclick="orderOk(<?php echo $item->id; ?>,0)" />
                        <?php } ?>
                    </td>
                    <!--
                    <td><a class="del" href="<?php echo JRoute::_("index.php?option=com_storecable&view=adminlistorder&sellerid=".$item->sellerid."&orderid=".$item->id); ?>"></a></div></td>
                    -->
                    <td><?php echo $item->name; ?></td>
                    <td><?php echo $item->dateorder; ?></td>
                    <td>
                        <?php 
                            if (strtotime($item->datebegin)>0){
                                echo $item->datebegin;   
                            } 
                        ?>
                    </td>
                    <td>
                        <?php 
                            if (strtotime($item->dateend)>0){
                                echo $item->dateend;   
                            } 
                        ?>
                    </td>
                    <td name='period'><?php echo $item->period/3600/24; ?></td>
                    <td><a href="<?php echo $item->bannerpath; ?>"><img class="smallbanner" src="<?php echo $item->bannerpath; ?>" /></a></td>
                    <td><?php echo $item->position; ?></td>
                    <td name="status"><?php echo $item->status; ?></td>
                    <td class="setdesc"><input type="text" class="description desc<?php echo $item->id; ?>" onclick="setDescription(<?php echo $item->id; ?>);" value="<?php echo $item->description; ?>" /></td>
                    </tr>
                    <?php
                }
            ?>
    </table>
    <input type="hidden" name="option" value="com_storecable" />
    <input type="hidden" name="view" value="adminbanners" />
    <input type="hidden" name="limitstart" value="0">
</form>    

<?php

echo $this->pagination->getListFooter();

?>
    
<script language="javascript">
param='';
    //Функции сортировки
    function orderby(param){
        //Поставить противоположную сортировку
        var desc="<?php if ($this->filtr->desc=='ASC') {echo "DESC";} else {echo "ASC";} ?>";
        //Добавить на форму поля сортировки
        jQuery("#adminForm").append('<input type="hidden" name="orderby" value="'+param+'">');
        jQuery("#adminForm").append('<input type="hidden" name="desc" value="'+desc+'">');
        //Отправить форму
        jQuery("#adminForm").submit();
    }
    
//Запрос на удалени заявки
function deleteorder(id){
    //Закрыть модальное окно
    jQuery("#closemodal").click();
    var url=SiteUrl+'/administrator/index.php?option=com_storecable&task=adminbanners.deleteorder&view=adminbanners';
    url+='&orderid='+id;
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        type:"get",
        success:function(data){
            //console.log(data);
            jQuery("tr.order"+id).remove();
            alert("Заявка удалена");
        },
        error:function(){
            alert("Не получилось отправить или обработать запрос");
        }
    })
}    


//Установить блок для редактирования Примечания
function setDescription(id){
    var el='<span class="spanlink dblock" onclick="endDescription('+id+')">Сохранить примечание</span>';
    var el_cancel='<span class="redtext canceltext dblock" onclick="cancelDesc('+id+')">Отменить</span>';
    jQuery("input.desc"+id).parent().append(el);
    jQuery("input.desc"+id).parent().append(el_cancel);
}

//Отменить редактирование
function cancelDesc(id){
    jQuery("input.desc"+id).parent().find(".spanlink").remove();
    jQuery("input.desc"+id).parent().find(".redtext").remove();
}

//Закончить редактирование Примечания
function endDescription(id){
    jQuery("input.desc"+id).parent().find(".spanlink").remove();
    jQuery("input.desc"+id).parent().find(".redtext").remove();
    var url=SiteUrl+'/administrator/index.php?option=com_storecable&task=adminbanners.setDescription&view=adminbanners';
    //console.log(url);
    url+='&orderid='+id+'&text='+jQuery("input.desc"+id).val();
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            //console.log(data);
        },
        error: function(){
            alert("Не получилось отправить запрос");
        }
    })
}

//Подтвердить заявку
function orderOk(id, status){
    var url=SiteUrl+'/administrator/index.php?option=com_storecable&task=adminbanners.orderOk&view=adminbanners';
    url+='&orderid='+id+'&status='+status;
    url+='&period='+jQuery("tr.order"+id+" td[name='period']").html();
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            //console.log(data);
            /*
            if (status==1){
                jQuery("input.orderok"+id).val("Отменить");
                jQuery("input.orderok"+id).attr("onclick",'orderOk('+data.id+',"1")');   
            }else{
                jQuery("input.orderok"+id).val("Подтвердить");
                jQuery("input.orderok"+id).attr("onclick",'orderOk('+data.id+',"0")');
            }
            */
            orderby(param);
        },
        error: function(){
            alert("Не получилось отправить запрос");
        }
    })
}
    
</script>    