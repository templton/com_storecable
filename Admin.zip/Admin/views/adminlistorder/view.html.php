<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewAdminlistorder extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
     
	public function display( $tpl = null )
	{
	    try
        {             
            $this->seller=StoreHelper::getDataSeller(0,$_GET['sellerid']);
            $this->order=$this->get('Order');
            
            $this->addToolbar();
 
            // Отображаем представление.
            parent::display($tpl);
        }
        catch (Exception $e)
        {
            throw new Exception($e->getMessage());
        }
    }

protected function addToolBar()
     {
         //JFactory::getApplication()->input->set('hidemainmenu', true);
         //$isNew = ($this->item->id == 0);
         
        JToolBarHelper::title($isNew ? JText::_('COM_STORECABLE') : JText::_('COM_STORECABLE'), 'storecable');
        //JToolBarHelper::apply('storecable.apply', 'JTOOLBAR_APPLY');
        JToolBarHelper::save('adminlistorder.saveorder');
        JToolbarHelper::cancel('adminlistorder.cancel');
         
         
     }  
}