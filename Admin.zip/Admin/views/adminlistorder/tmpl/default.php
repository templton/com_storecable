<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
JHtml::_('behavior.tooltip');
JFactory::getDocument()->addScriptDeclaration('

	Joomla.submitbutton = function(task)
	{
	   if (task=="adminlistorder.saveorder")
       {
            jQuery("#mainform").submit();
       }else{
        Joomla.submitform(task, document.getElementById("item-form"));
        }
	};
    
');
//echo $this->orderby->desc;
$param=StoreHelper::getAllParam();
/*
echo "<pre>";
print_r($this->order);
echo "</pre>";
*/


?>

<h1>Заявка на статус Производителя от контрагента <?php echo $this->seller->name; ?></h1>
<h4>Дата подачи заявки: <?php echo $this->order->datesend; ?></h4>

<form action="index.php?option=com_storecable&task=adminlistorder.saveorder" id="mainform">
<input type="hidden" name="option" value="com_storecable" />
<input type="hidden" name="task" value="adminlistorder.saveorder" />
<input type="hidden" name="cables" value="<?php echo $this->order->cableid; ?>" />
<input type="hidden" name="sellerid" value="<?php echo $this->order->sellerid; ?>" />
<input type="hidden" name="orderid" value="<?php echo $this->order->id; ?>" />

<div class="statusblock">
    <span>Установить статус: </span>
    <?php //echo $this->order->status." - sd"; ?>
    <select class="statusselect" name="status">
        <option value="0" <?php if ($this->order->status=='0') {echo 'selected';} ?> >В работе</option>
        <option value="1" <?php if ($this->order->status=='1') {echo 'selected';} ?> >Одобрено</option>
        <option value="-1" <?php if ($this->order->status=='-1') {echo 'selected';} ?> >Отказано</option>
    </select>
</div>
<div class="descblock">
    <textarea placeholder="Добавить примечание" class="textblock" name="description">   
        <?php echo trim(strip_tags($this->order->description)); ?>
    </textarea>
</div>
<div class="clear"></div>
<hr />

<?php if ($this->order->status!='0') { ?>
    <div class="errororder">
        <h5 class="error">Заявка уже обработана и заблокирована. Чтобы разблокировать заявку, сохраните ее со статусом "В работе"</h5>
        <!-- <input class="error" type="button" class="btn default" value="Разблокировать" onclick="unblockinput()" />
        -->
    </div>
<?php } ?>

<input type="checkbox" onclick="selectAll(this)" class="selectAll" />
<span> - выбрать все</span>
<div class="cables">
    <?php foreach ($this->order->cables as $cable) { ?>
        <input type="checkbox" <?php echo $cable->checked; ?> name="cableid<?php echo $cable->cableid; ?>" />
        <span><?php echo $cable->cable; ?></span>
        <br />
    <?php } ?>

</div>

<div class="docs">
    <h4>Документы пользователя к данной заявке:</h4>
    <table class="adminlist table table-striped">
        <tr>
            <th>Описание</th>
            <th>Файл</th>
        </tr>
        <?php foreach ($this->order->doc as $doc) { ?>
            <td><?php echo $doc->descroption; ?></td>
            <td><a href="<?php echo JURI::base(); ?>components/com_storecable/files/<?php echo $doc->filename; ?>" download><?php echo $doc->filename; ?></a></td>
        <?php } ?>
    </table>
</div>

</form>



<form action="<?php echo JRoute::_('index.php?option=com_storecable'); ?>" method="post" name="adminForm" id="item-form">

    <div>
        <input type="hidden" name="task" value="" />
        <input type="hidden" id="boxchecked" value="1" />
        <input type="hidden" name="limitstart" value="20" />
        <?php echo JHtml::_('form.token'); ?>
    </div>
</form>

<script language="javascript">



function selectAll(el){
    //console.log(jQuery(el));
    if (!jQuery(el).attr("checked"))
        {
            jQuery(".cables input").removeAttr("checked");
        }else{
            jQuery(".cables input").attr("checked","true");
        }
}

//Заблокировать элементы выбора кабеля для отработанной заявки
<?php if ($this->order->status!='0') {
    ?>
    jQuery(document).ready(function(){blockinput();})
    <?php
}?>

//Блокировка элементов выбора
function blockinput(){
    jQuery(".cables input").attr("disabled","true");
    jQuery(".selectAll").attr("disabled","true");
}

//Разблокировка элементов выбора
function unblockinput(){
    jQuery(".cables input").removeAttr("disabled");
}


</script>