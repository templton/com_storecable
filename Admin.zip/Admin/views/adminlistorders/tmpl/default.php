<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
JHtml::_('behavior.tooltip');
//echo $this->orderby->desc;
$param=StoreHelper::getAllParam();
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
			Joomla.submitform(task, document.getElementById("item-form"));
	};
');

?>


<!-- HTML-код модального окна -->
<div id="modalDeleteDialog" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Заголовок модального окна -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title">Предупреждение</h4>
      </div>
      <!-- Основное содержимое модального окна -->
      <div class="modal-body">
        <p>
            Вы действительно хотите удалить заявку Производителя?
        </p>
      </div>
      <!-- Поле для подстановки if удаляемого пользователя -->
      <input type="hidden" name="deleteorder" id="deleteorder" value="" />
      <!-- Футер модального окна -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="closemodal">Отмена</button>
        <button type="button" class="btn btn-primary" onclick="deleteorder(jQuery('#deleteorder').val())" >Удалить Контрагента</button>
      </div>
    </div>
  </div>
</div>


<h1>Журнал заявок Приозводителей</h1>

<form id="adminForm" name="adminForm" action="index.php?option=com_storecable&view=adminlistorder" method="GET">
    <table class="adminlist table table-striped">
        <tr>
            <?php
                //определить, куда и какую поставить стрелочку сортировки
                if (strlen($this->filtr->orderby)>1){
                    //print_r($this->filtr);
                    if ($this->filtr->desc=='DESC'){
                            $class='down';
                        }else{
                            $class="up";
                        }
                    //
                    $name=$this->filtr->orderby;   
                }
            ?>
            <th class="<?php if ($name=='id') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('id')">ID</span></th>
            <th></th>
            <!-- <th></th> -->
            <th class="<?php if ($name=='name') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('name')">Наименование организации</span></th>
            <th class="<?php if ($name=='datesend') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('datesend')">Дата подачи</span></th>
            <th class="<?php if ($name=='status') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('status')">Статус</span></th>
            <th class="<?php if ($name=='datefeatured') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('datefeatured')">Дата закрытия</span></th>
            <th class=""><span class="thtitle">Примечание</span></th>
        </tr>
            <?php
                foreach ($this->items as $item){
                    ?>
                    <tr class="order<?php echo $item->id; ?>">
                    <td><?php echo $item->id; ?></td>
                    <td><a class="edit" href="<?php echo JRoute::_("index.php?option=com_storecable&view=adminlistorder&sellerid=".$item->sellerid."&orderid=".$item->id); ?>"></a></div></td>
                    <!--
                    <td><a class="del" href="<?php echo JRoute::_("index.php?option=com_storecable&view=adminlistorder&sellerid=".$item->sellerid."&orderid=".$item->id); ?>"></a></div></td>
                    -->
                    <td><?php echo $item->name; ?></td>
                    <td><?php echo $item->datesend; ?></td>
                    <td><?php echo $item->status; ?></td>
                    <td><?php echo $item->datefeatured; ?></td>
                    <td><?php echo $item->description; ?></td>
                    </tr>
                    <?php
                }
            ?>
    </table>
    <input type="hidden" name="option" value="com_storecable" />
    <input type="hidden" name="view" value="adminlistorders" />
    <input type="hidden" name="limitstart" value="0">
</form>    

<?php

echo $this->pagination->getListFooter();

?>
    
<script language="javascript">
    //Функции сортировки
    function orderby(param){
        //Поставить противоположную сортировку
        var desc="<?php if ($this->filtr->desc=='ASC') {echo "DESC";} else {echo "ASC";} ?>";
        //Добавить на форму поля сортировки
        jQuery("#adminForm").append('<input type="hidden" name="orderby" value="'+param+'">');
        jQuery("#adminForm").append('<input type="hidden" name="desc" value="'+desc+'">');
        //Отправить форму
        jQuery("#adminForm").submit();
    }
    
//Запрос на удалени заявки
function deleteorder(orderid){
    //Закрыть модальное окно
    jQuery("#closemodal").click();
    var url='index.php?option=com_storecable&task=adminlistorder.deleteorder&orderid='+orderid;
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        type:"get",
        success:function(data){
            //console.log(data);
            jQuery("tr.order"+orderid).remove();
            alert("Заявка удалена");
        },
        error:function(){
            alert("Не поулчилось отправить или обработать запрос");
        }
    })
}    
    
</script>    