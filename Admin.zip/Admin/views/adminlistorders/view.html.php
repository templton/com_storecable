<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewAdminlistorders extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */
     
	public function display( $tpl = null )
	{
	    try
        {   $this->filtr=$this->get('Filtr');
        //print_r($this->filtr);
            // Получаем данные из модели.
            $this->items = $this->get('Items');
 
            // Получаем объект постраничной навигации.
            $this->pagination = $this->get('Pagination');
            
            
            $this->addToolbar();
 
            // Отображаем представление.
            parent::display($tpl);
        }
        catch (Exception $e)
        {
            throw new Exception($e->getMessage());
        }
    }

protected function addToolBar()
     {
         //JFactory::getApplication()->input->set('hidemainmenu', true);
         //$isNew = ($this->item->id == 0);
         
        JToolBarHelper::title($isNew ? JText::_('COM_STORECABLE') : JText::_('COM_STORECABLE'), 'storecable');
        //JToolBarHelper::apply('storecable.apply', 'JTOOLBAR_APPLY');
        //JToolBarHelper::save('storecable.save');
        //JToolbarHelper::cancel('adminseller.cancel');
         
         
     }  
}