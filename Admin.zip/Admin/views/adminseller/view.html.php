<?php
defined( '_JEXEC' ) or die; // No direct access

/**
 * View for  current element
 * @author Саламатов Дмитрий Викторович
 */
class StorecableViewAdminseller extends JViewLegacy
{
	/**
	 * Method of display current template
	 * @param type $tpl
	 */

     
public function display( $tpl = null )
	{
	    try
        {
            $this->items=$this->get('Items');
            $sellerid=JRequest::getVar('id');
            
            
            $db=JFactory::getDBO();
            $query=StoreHelper::getMakerCableQuery(JRequest::getVar('id'));
            $db->setQuery($query);
            $this->items=$db->LoadObjectList();
            
            
            $this->items=StoreHelper::getFullName($this->items,array("name","cablekv"));
            
            
            //$this->pagination=$this->get('Pagination');
            
            // Получаем данные из модели.
             $this->seller=$this->get('Seller');
             
             //Запрошен вид связанного пользователя joomla
             if ($_GET['layout']=='joomlauser'){
                //Получить связанного пользователя
                $userid=StoreHelperDB::getDataTable('store_seller',$sellerid)->userid;
                $this->joomlauser=StoreHelperDB::getDataTable('users',$userid);
                //Получить список всех несвязанных пользователей
                $db=JFactory::getDBO();
                $query=StoreHelper::getNotRelativeQuery();
                $db->setQuery($query);
                $select=$db->LoadObjectList();
                $this->notrelative = JHTML::_('select.genericlist',$select,$name="newuser");
             }
             
             /*
             echo "<pre>";
             print_r($this->table);
             echo "</pre>";
             */
            
            $this->addToolbar();
 
            // Отображаем представление.
            parent::display($tpl);
        }
        catch (Exception $e)
        {
            throw new Exception($e->getMessage());
        }
    }
    
    


protected function addToolBar()
     {
         //JFactory::getApplication()->input->set('hidemainmenu', true);
         //$isNew = ($this->item->id == 0);
         
        JToolBarHelper::title($isNew ? JText::_('COM_STORECABLE') : JText::_('COM_STORECABLE'), 'storecable');
        //JToolBarHelper::apply('storecable.apply', 'JTOOLBAR_APPLY');
        //JToolBarHelper::save('storecable.save');
        JToolbarHelper::cancel('adminseller.cancel');
         
         
     }  
}