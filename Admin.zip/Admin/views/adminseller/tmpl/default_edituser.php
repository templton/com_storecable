  
<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
/*
echo "<pre>";
print_r($this->seller);
echo "</pre>";
*/

?>

<h1>Контрагент <?php echo $this->seller->name; ?></h1>


<div class="urdatablock">
    <form id="formuser">
        <h4>Данные организации</h4>
        <table class="dataseller">
            <tr>
                <td>Наименование:</td>
                <td><input type="text" name="namefirm" class="namefirm" value='<?php echo $this->seller->name; ?>' /></td>
            </tr>
            <tr>
                <td>Город:</td>
                <td><input type="text" name="" value='<?php echo $this->seller->town; ?>' /></td>
            </tr>
            <tr>
                <td>Улица:</td>
                <td><input type="text" name="street" class="street" value='<?php echo $this->seller->street; ?>' /></td>
            </tr>
            <tr>
                <td>Корпус:</td>
                <td><input type="text" name="bilding" class="bilding" value='<?php echo $this->seller->bilding; ?>' /></td>
            </tr>
            <tr>
                <td>Дом:</td>
                <td><input type="text" name="house" class="house" value='<?php echo $this->seller->house; ?>' /></td>
            </tr>
            <tr>
                <td>Офис:</td>
                <td><input type="text" name="office" class="office" value='<?php echo $this->seller->office; ?>' /></td>
            </tr>
            <tr>
                <td>ИНН:</td>
                <td><input type="text" class="onlyint" name="inn" class="inn" value='<?php echo $this->seller->inn; ?>' /></td>
            </tr>
            <tr>
                <td>ОГРН:</td>
                <td><input type="text" class="onlyint" name="ogrn" class="ogrn" value='<?php echo $this->seller->ogrn; ?>' /></td>
            </tr>
            <tr>
                <td colspan="3">
                    <table class="phoneblocktable">
            <?php
                //Вывод телефонов
                $i=0;
                if (count($this->seller->phone)>0){
                foreach ($this->seller->phone as $phone){
                    $count=$i+1;
                    echo '
                    <tr class="phoneblock phonetr'.$i.'">
                        <td>Контактный телефон :</td>
                        <td>
                            <input type="text" class="phone onlyphone" name="phone-'.$i.'" value="'.$phone.'">
                            <div class="del inblock" onclick="deletephone('."'".$i."'".')"></div>
                        </td>
                    </tr>
                    ';
                    $i++;
                }
                }
                ?>
                    </table>
                </td>
            </tr>
            
                <tr>
                    <td class="upr"><input type="button" value="Добавить телефон" onclick="addphone()" /></td>
                </tr>
                
                
                <!-- Блок email-->
            <tr>
                <td colspan="3">
                    <table class="emailblocktable">
                <?php
                //Вывод email
                $i=0;
                foreach ($this->seller->email as $email){
                    $count=$i+1;
                    echo '
                    <tr class="emailtr'.$i.'">
                        <td>Электронная почта: </td>
                        <td>
                            <input type="text" class="email" name="email-'.$i.'" value="'.$email.'">
                            <div class="del inblock" onclick="deleteemail('."'".$i."'".')"></div>
                        </td>
                    </tr>
                    ';
                    $i++;
                }
                ?>
                    </table>
                </td>
            </tr>            
            
            <tr>
                    <td class="upr"><input type="button" value="Добавить почту" onclick="addemail()" /></td>
            </tr>
            
            
            <tr>
                <td>Сайт:</td>
                <td><input type="text" name="site" value='<?php echo $this->seller->site; ?>' /></td>
            </tr>
            <tr>
                <td>Режим работы:</td>
                <td>
                    <table class="modetable">
                        <tr class="daywork">
                            <td>ПН - ВТ: </td>
                            <td>
                                <?php
                                    $m=explode('-',$this->seller->mode[0]); 
                                ?>
                                <input class="mode time wdbegin" type="text" name="" value="<?php echo $m[0]; ?>" />
                                -   
                                <input class="mode time wdend" type="text" class="" name="" value="<?php echo $m[1]; ?>" />
                            </td>
                            <td></td>
                        </tr>
                        
                        <tr>
                            <td>Пятница: </td>
                           <td>
                                <?php
                                    $m=explode('-',$this->seller->mode[1]); 
                                    if (count($m)<2){$class='none';$classlabel='';}else{$class='';$classlabel='none';}
                                ?>
                                <div class="daypt <?php echo $class; ?>">
                                <input class="mode time ptbegin" type="text" name="" value="<?php echo $m[0]; ?>" />
                                -   
                                <input class="mode time ptend" type="text" name="" value="<?php echo $m[1]; ?>" />
                                </div>
                                <span class="labelpt <?php echo $classlabel; ?>">Так же, как ПН-ВТ</span>
                            </td>
                            <td>
                                <span class="setmode setpt" onclick="togglelabel('pt')">Установить, как ПН-ВТ</span>
                            </td>
                        </tr>
                        
                        <tr>
                            <td>Суббота: </td>
                           <td>
                                <?php
                                    $m=explode('-',$this->seller->mode[2]); 
                                    if (count($m)<2){$class='none';$classlabel='';}else{$class='';$classlabel='none';}
                                ?>
                                <div class="daysb <?php echo $class; ?>">
                                <input class="mode time sbbegin" type="text" name="" value="<?php echo $m[0]; ?>" />
                                -   
                                <input class="mode time sbend" type="text" name="" value="<?php echo $m[1]; ?>" />
                                </div>
                                <span class="labelsb <?php echo $classlabel; ?>">Выходной</span>
                            </td>
                            <td>
                                <span class="setmode setsb" onclick="togglelabel('sb')">Указать интервал</span>
                            </td>
                        </tr>
                        <tr>
                            <td>Воскресенье: </td>
                            <td>
                                <?php
                                    $m=explode('-',$this->seller->mode[3]); 
                                    if (count($m)<2){$class='none';$classlabel='';}else{$class='';$classlabel='none';}
                                ?>
                                <div class="dayvs <?php echo $class; ?>">
                                <input class="mode time vsbegin" type="text" name="" value="<?php echo $m[0]; ?>" />
                                -   
                                <input class="mode time vsend" type="text" name="" value="<?php echo $m[1]; ?>" />
                                </div>
                                <span class="labelvs <?php echo $classlabel; ?>">Выходной</span>
                            </td>
                            <td>
                                <span class="setmode setvs" onclick="togglelabel('vs')">Указать интервал</span>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="button" value="Сохранить изменения" onclick="senddata()" />
                </td>
            </tr>
        </table>
        
        
<!-- Блок контактных лиц -->
        <div class="faceblockmain">
            <div class="faceblock">
                <?php if (strlen($this->seller->face[0]->fio)>0) {?>
                    <?php $facecount=0; ?>
                    <?php foreach($this->seller->face as $item) { ?>
                    <table class="tableface face<?php echo $facecount; ?>">
                        <tr class="facetitle">
                            <td colspan="2"><div class="del delface" onclick="deleteface(<?php echo $facecount; ?>)"></div><span>Контактное лицо - <?php echo ($facecount+1); ?></span></td>
                        </tr>
                        <tr class="facefio">
                            <td>ФИО</td>
                            <td><input type="text" class="chars" name="face_fio<?php echo $facecount; ?>" value="<?php echo $item->fio; ?>" /></td>
                        </tr>
                        <tr class="facephone">
                            <td>Телефон</td>
                            <td><input type="text" class="phone onlyphone" name="face_phone<?php echo $facecount; ?>" value="<?php echo $item->phone; ?>" ></td>
                        </tr>
                        <tr class="faceicq">
                            <td>ICQ</td>
                            <td><input type="text" class="onlyint" name="face_icq<?php echo $facecount; ?>" value="<?php echo $item->icq; ?>" ></td>
                        </tr>
                        <tr class="faceskype">
                            <td>Skype</td>
                            <td><input type="text" class="chars" name="face_skype<?php echo $facecount; ?>" value="<?php echo $item->skype; ?>" ></td>
                        </tr>
                        <tr class="whatsupp">
                            <td>WhatsUpp</td>
                            <td><input type="text" class="onlyint" name="face_whatsupp<?php echo $facecount; ?>" value="<?php echo $item->whatsupp; ?>" ></td>
                        </tr>
                </table>
                    <?php $facecount++; ?>
                    <?php } ?>
                <?php } ?>
            </div>
            <div>
                <input type="button" value="Добавить контактное лицо" onclick="addface()" />
            </div>
        </div>        
        
        
    </form>
</div>
<script lang="javascript">
jQuery(document).ready(function(){
    //Макса для ввода времени
    $(".time").mask("99:99");
    
    //Инициализация надписей для графика работы
    setlabel('vs');
    setlabel('sb');
    setlabel('pt');
    //Ввод только цифр
    startonlyint();
    //Остальные правила ввода
    setMaska();
})


//Маски и ограничение ввода
function setMaska(){
    //Маска ввода для телефона
    $(".phone").mask("+9 (999) 9999999");
    //Ограничение ввода для email
    /*
    jQuery('.email').bind("change keyup input click", function() {
    if (this.value.match(/[^A-Za-z0-9@_]/g)) {
        this.value = this.value.replace(/[^A-Za-z0-9@_]/g, '');
    }
    });
    */    
}


//Добавить контактное лицо
function addface(){
    var count=jQuery(".tableface").length;
    var face='<table class="tableface face'+count+'">';
            face+='<tr class="facetitle">';
                face+='<td colspan="2"><div class="del delface"></div><span>Контактное лицо - '+(count+1)+'</span></td>';
            face+='</tr>';
            face+='<tr class="facefio">';
                face+='<td>ФИО</td>';
                face+='<td><input type="text" class="chars" name="face_fio'+count+'"></td>';
            face+='</tr>';
            face+='<tr class="facephone">';
                face+='<td>Телефон</td>';
                face+='<td><input type="text" class="phone onlyphone" name="face_phone'+count+'"></td>';
            face+='</tr>';
            face+='<tr class="faceicq">';
                face+='<td>ICQ</td>';
                face+='<td><input type="text" class="onlyint" name="face_icq'+count+'"></td>';
            face+='</tr>';
            face+='<tr class="faceskype">';
                face+='<td>Skype</td>';
                face+='<td><input type="text" class="chars" name="face_skype'+count+'"></td>';
            face+='</tr>';
            face+='<tr class="whatsupp">';
                face+='<td>WhatsUpp</td>';
                face+='<td><input type="text" class="onlyint" name="face_whatsupp'+count+'"></td>';
            face+='</tr>';
    face+='</table>';
    jQuery(".faceblock").append(face);
    //Ввод только цифр
    startonlyint();
    //Остальные правила ввода
    setMaska();
}


//Надписи для управления графиком работы
function setlabel(cl)
{
    //alert(".setmode.set"+cl);
    if (jQuery(".label"+cl).hasClass('none'))
        {
            if (cl=='pt'){
                jQuery(".setmode.set"+cl).html('Установить, как ПН-ВТ');
            }else{
                jQuery(".setmode.set"+cl).html('Выходной');   
            }
        }
        else
        {jQuery(".setmode.set"+cl).html('Указать интервал');}
}

function togglelabel(cl){
    jQuery(".day"+cl).toggleClass('none');
    jQuery(".label"+cl).toggleClass('none');
    setlabel(cl);
}

//Удалить телефон
function deletephone(count){
    jQuery(".phonetr"+count).remove();
}

//Добавить поле для телефона
function addphone()
{
    var i=0;
    //Определить кол-во уже введенных телефонов
    i=jQuery(".phoneblocktable tr").length;
    var item='<tr class="phoneblock phonetr'+i+'"><td>Контактный телефон :</td>'
    item+='<td><input class="phone onlyphone" type="text" name="phone-'+i+'">';
    item+='<div class="del inblock" onclick="deletephone('+"'"+i+"'"+')"></div>';
    item+='</td></tr>';
    jQuery(".phoneblocktable").append(item);
    startonlyint();
    setMaska();
}

//Удалить email
function deleteemail(count){
    jQuery(".emailtr"+count).remove();
}

//Добавить поле для email
function addemail()
{
    var i=0;
    //Определить кол-во уже введенных телефонов
    i=jQuery(".emailblocktable tr").length;
    var item='<tr class="emailblock emailtr'+i+'"><td>Электронная почта :</td>'
    item+='<td><input type="text" class="email" name="email-'+i+'">';
    item+='<div class="del inblock" onclick="deleteemail('+"'"+i+"'"+')"></div>';
    item+='</td></tr>';
    jQuery(".emailblocktable").append(item);
    setMaska();
}

//Обработка формы
function senddata(){
    //Валидация формы
    var valid='1';
    jQuery("input.email").each(function(){
        if (valid_email(this)=='0'){
            valid='0';
        }
    })
    
    //Если валидация формы прошла, то отправим форму
    if (valid=='1'){
        //Собрать данные графика работы
        var work='';
        //Для рабочих дней
        work+='wdbegin='+jQuery(".wdbegin").val();
        work+='&wdend='+jQuery(".wdend").val();
        //Для пятницы
        if (jQuery(".daypt").hasClass("none")){
            work+='&ptbegin=0';
            work+='&ptend=0';
        }else{
            work+='&ptbegin='+jQuery(".ptbegin").val();
            work+='&ptend='+jQuery(".ptend").val();
        }
        //Для субботы
        if (jQuery(".daysb").hasClass("none")){
            work+='&sbbegin=0';
            work+='&sbend=0';
        }else{
            work+='&sbbegin='+jQuery(".sbbegin").val();
            work+='&sbend='+jQuery(".sbend").val();
        }
        //Для воскресенья
        if (jQuery(".dayvs").hasClass("none")){
            work+='&vsbegin=0';
            work+='&vsend=0';
        }else{
            work+='&vsbegin='+jQuery(".vsbegin").val();
            work+='&vsend='+jQuery(".vsend").val();
        }
        
        //Данные формы
        var data=jQuery("#formuser").serialize();
        url=SiteUrl+'index.php?option=com_storecable&task=seller.saveuser&'+work+'&'+data+'&sellerid=<?php echo JRequest::getVar('id'); ?>';
        console.log(url);
        //console.log(data);
        jQuery.ajax({
            url:url,
            /*data:data,*/
            dataType:"json",
            type:"get",
            success:function(data){
                console.log(data);
                if (data.save.error=='1'){
                        alert(data.save.errmes);
                        return;
                }
                //alert(data.save.result);
                if (data.save.result){
                    alert("Данные успешно сохранены.");
                }else{
                    alert("Данные не были сохранены. Проверьте правильность ввода полей.")
                }
            },
            error:function(){
                alert("Не получилось сохранить данные. Мы уже работаем над этой ошибкой.");
            }
        })
    }
    
    
}


//Удалить контактное лицо
function deleteface(id){
    jQuery(".tableface.face"+id).remove();
}

</script>    
    