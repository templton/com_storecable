<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
// Загружаем тултипы.
JHtml::_('behavior.tooltip');

$selectid=JRequest::getVar('id');

JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
			Joomla.submitform(task, document.getElementById("item-form"));
	};
');

unset($menu);
$menu[0]['title']='Данные организации';
$menu[0]['layout']='edituser';

$menu[1]['title']='Производство кабеля';
$menu[1]['layout']='makercable';

$menu[2]['title']='Баннеры';
$menu[2]['layout']='banners';

$menu[3]['title']='Документы';
$menu[3]['layout']='documents';

$menu[3]['title']='Пользователь Joomla!';
$menu[3]['layout']='joomlauser';

?>

<div class="menublock">
    <ul class="sellermenu menu">
        <?php
            unset($list);
            foreach ($menu as $item)
            {
                $list.='<li>';
                if ($_GET['layout']==$item['layout']){
                    $list.='<span class="currentitem">'.$item['title'].'</span>';    
                }
                else{
                    //Для пагинации добавить start=1
                    $list.='<a href="'.JRoute::_("index.php?start=1&option=com_storecable&view=adminseller&layout=".$item['layout']).'&id='.$selectid.'">'.$item['title'].'</a>';
                }
                $list.='</li>';
            }
            echo $list;
        ?>
    </ul>
</div>


<?php
if ($_GET['layout'])
{
    echo $this->loadTemplate($_GET['layout']);   
}
?>


<form action="<?php echo JRoute::_('index.php?option=com_storecable&layout=edit&id=' . (int) $this->item->id); ?>" method="post" name="adminForm" id="item-form">

    <div>
        <input type="hidden" name="task" value="" />
        <input type="hidden" name="limitstart" value="20" />
        <?php echo JHtml::_('form.token'); ?>
    </div>
</form>
