  
<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
/*
echo "<pre>";
print_r($this->seller);
echo "</pre>";
*/

?>


<h1>Контрагент <?php echo $this->seller->name; ?></h1>
<h4>Назначение Контрагента Производителем</h4>
<div class="messageblock hidden">
    <div class="closeblock" onclick="jQuery('.messageblock').addClass('hidden');"></div>
    <div class="text bluetext">
    </div>
</div>
<div class="addfeatures">
    <input type="text" value="" name="typecable" class="typecable" id="typecable" placeholder="Введите первые буквы кабеля" />
    <input type="button" value="Назначить" onclick="addcablemaker()" />
</div>

<div class="">
    <table class="adminlist table table-striped mintable" id="resulttable">
        <tr>
            <th>Наименование кабеля</th>
            <th></th>
        </tr>
        <?php
            foreach($this->items as $cable){
                ?>
                <tr class="item<?php echo $cable->cablemakerid; ?>">
                    <td><?php echo $cable->fullname; ?></td>
                    <td><div class="del" onclick="deleteitem('<?php echo $cable->cablemakerid; ?>')"></div></td>
                </tr>
                <?php
            }
        ?>
    </table>
</div>

<!-- пагинация -->
<?php
    //echo $this->pagination->getPagesCounter();
    if ($this->pagination){
        echo $this->pagination->getListFooter();
    }
?>


<script lang="javascript">
//Поиск марки кабеля
jQuery(function(){
    var url=SiteUrl+'index.php?option=com_storecable&view=seller&task=seller.searchcable&makerid=<?php echo JRequest::getVar('id'); ?>';
    console.log(url);
    $( "#typecable" ).autocomplete({
      source: url
    });     
})

//Добавить кабель в таблицу Производителя
function addcablemaker(){
    var url='index.php?option=com_storecable&task=adminseller.addmakercable&cable='+jQuery("#typecable").val()+"&makerid=<?php echo JRequest::getVar('id'); ?>";
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        type:"get",
        success:function(data){
            console.log(data);
            if (data.result.result=='1'){
                //Сделать текст синим
                jQuery(".messageblock .text").removeClass("redtext");
                jQuery(".messageblock .text").addClass("bluetext");
                //Удачное сообщение
                jQuery(".messageblock").removeClass("hidden");
                jQuery(".messageblock .text").html("Кабель "+jQuery("#typecable").val()+" успешно добавлен в базу Контрагента");
                //Вставить новую позицию в таблицу
                var newpos='<tr class="item'+data.result.id+'"><td class="redtext">'+jQuery("#typecable").val()+'</td><td><div class="del" onclick="deleteitem('+data.result.id+')"></div></td></tr>';
                //jQuery("#resulttable").prepend(newpos);
                jQuery(newpos).insertAfter("#resulttable tr:eq(0)");
                //Очистить поле
                jQuery("#typecable").val('');
            }
            if (data.result.error=='1'){
                //Сделать текст красным
                jQuery(".messageblock .text").removeClass("bluetext");
                jQuery(".messageblock .text").addClass("redtext");
                
                jQuery(".messageblock").removeClass("hidden");
                jQuery(".messageblock .text").html(data.result.errmess);
                jQuery("#typecable").val('');
            }
        },
        error:function(){
            alert("Не получилось отправить запрос на внесение данных");
        }
    })
}

//Удалить поизцию из таблицы Производитлеля
function deleteitem(id){
    var url='index.php?option=com_storecable&task=adminseller.deleteitem&id='+id;
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        success:function(data){
            console.log(data);
            if (data.result.result=='1'){
                jQuery("tr.item"+id).remove();
            }
        },
        error: function(){
            alert("Не получилось отправить данные");
        }
    })
}



</script>

