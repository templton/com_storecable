  
<?php
/** @var $this StorecableViewVid1 */
defined( '_JEXEC' ) or die; // No direct access
/*
echo "<pre>";
print_r($this->joomlauser);
echo "</pre>";
*/
?>

<h1>Контрагент <?php echo $this->seller->name; ?></h1>

<div class="contentblock">
    <div class="relativeuser">
        <?php if ($this->joomlauser->id>0){
            ?>
            <div><h4>Связанный пользователь Joomla!:</h4></div>
            <table>
                <tr>
                    <td>ID</td>
                    <td><?php echo $this->joomlauser->id; ?></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><?php echo $this->joomlauser->username; ?></td>
                </tr>
                <tr>
                    <tr>
                        <td colspan="2">
                            <form action="index.php" method="GET">
                                <input type="hidden" name="id" value="<?php echo JRequest::getVar('id'); ?>" />
                                <input type="hidden" name="sellerid" value="<?php echo JRequest::getVar('id');?>" />
                                <input type="hidden" name="option" value="com_storecable" />
                                <input type="hidden" name="view" value="adminseller" />
                                <input type="hidden" name="layout" value="joomlauser" />
                                <input type="hidden" name="task" value="adminseller.unrelativeuser" />
                                <br />
                                <input type="submit" value="Отвязать пользователя" />
                            </form>
                        </td>
                    </tr>
                </tr>
            </table>
            <?php
        } else{
            ?>
            <div>В настоящий момент ни один пользователь Joomla! не связан с данным Контрагентом</div>
            <hr />
            <?php
        }?>
                <hr />
                <div><h4>Привязать пользователя Joomla!:</h4></div>
                <form>
                    <div>Список непривязанных ни к одному контрагенту пользователей:</div>
                    <?php echo ($this->notrelative); ?>
                    <input type="hidden" name="id" value="<?php echo JRequest::getVar('id'); ?>" />
                    <input type="hidden" name="sellerid" value="<?php echo JRequest::getVar('id');?>" />
                    <input type="hidden" name="option" value="com_storecable" />
                    <input type="hidden" name="view" value="adminseller" />
                    <input type="hidden" name="layout" value="joomlauser" />
                    <input type="hidden" name="task" value="adminseller.relativeuser" />
                    <br />
                    <input type="submit" value="Привязать нового пользователя" />
                </form>
    </div>
</div>