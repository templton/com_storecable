<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
JHtml::_('behavior.tooltip');
//echo $this->orderby->desc;
$param=StoreHelper::getAllParam();
/*
echo "<pre>";
print_r($param);
echo "</pre>";
*/
?>

<h1>Настройки компонента</h1>

<?php
if (strlen($_SESSION['errmess'])>0) {
    ?>
    <div class="messageblock">
        <div class="closeblock" onclick='jQuery(".messageblock").remove();'></div>
        <?php echo $_SESSION['errmess']; ?>
    </div>
    <?php
}
?>


<form action="index.php?option=com_storecable&view=adminsettings&task=editdata" method="GET">
    <table>
        <tr>
            <td>Почта администратора</td>
            <td><input type="text" name="adminemail" class="" value="<?php echo $param->adminemail; ?>"/></td>
        </tr>
        <tr>
            <td>Почта автоответчика</td>
            <td><input type="text" name="answeremail" class="" value="<?php echo $param->answeremail; ?>"/></td>
        </tr>
        <tr>
            <td>Имя автоответчика</td>
            <td><input type="text" name="answername" class="" value="<?php echo $param->answername; ?>"/></td>
        </tr>
        <tr>
            <td>Подсказака для оформления <br /> статуса производителя (ID материала)</td>
            <td><input type="text" name="helpmakerid" class="" value="<?php echo $param->helpmakerid; ?>"/></td>
        </tr>
        <tr>
            <td>Подсказака для оформления <br /> заявки на баннер (ID материала)</td>
            <td><input type="text" name="helpbannerid" class="" value="<?php echo $param->helpbannerid; ?>"/></td>
        </tr>
        <tr>
            <td>Возможность устанавливать цену для кабеля</td>
            <td>
                <select name="showprice">
                    <option value="0" <?php if ($param->showprice=='0') {echo "selected";} ?>>Нет</option>
                    <option value="1" <?php if ($param->showprice=='1') {echo "selected";} ?>>Да</option>
                </select>
            </td>
        </tr>
    </table>
    <input type="submit" value="Изменить" />
    <input type="hidden" name="option"  value="com_storecable"/>
    <input type="hidden" name="view"  value="adminsettings"/>
    <input type="hidden" name="task"  value="adminsettings.editdata"/>
</form>
