<?php
/** @var $this StorecableViewAdminvid1 */
defined( '_JEXEC' ) or die; // No direct access
JHtml::_('behavior.tooltip');
JFactory::getDocument()->addScriptDeclaration('
	Joomla.submitbutton = function(task)
	{
			Joomla.submitform(task, document.getElementById("item-form"));
	};
');
//echo $this->orderby->desc;

?>
<h1>Список всех контрагентов</h1>


<!-- HTML-код модального окна -->
<div id="modalDeleteDialog" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Заголовок модального окна -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title">Предупреждение</h4>
      </div>
      <!-- Основное содержимое модального окна -->
      <div class="modal-body">
        <p>
            При удалении контрагента будут также удалены без возможности восстановления:
        </p>
        <ul>
            <li>Связанный пользователь системы;</li>
            <li>Склад контрагента и все личные данные;</li>
        </ul>
      </div>
      <!-- Поле для подстановки if удаляемого пользователя -->
      <input type="hidden" name="deleteuser" id="deleteuser" value="" />
      <!-- Футер модального окна -->
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="closemodal">Отмена</button>
        <button type="button" class="btn btn-primary" onclick="deleteuser(jQuery('#deleteuser').val())" >Удалить Контрагента</button>
      </div>
    </div>
  </div>
</div>

<script>
/*
  jQuery(document).ready(function() {
    
    jQuery("#myModalBox").modal('show');
  });
  */
  
//показать модальное коно
function showModalDeleteDialog(sellerid){
    jQuery("#deleteuser").val(sellerid)
    jQuery("#modalDeleteDialog").modal('show');    
}

</script>


<form action="<?php echo JRoute::_('index.php?option=com_storecable&view=adminsellers'); ?>" method="post" name="adminForm" id="adminForm">
<!-- Фильтр: поставщики, производители, все-->
<!--
<select name="kontragent" onchange="filtrbyseller()">
    <option value="all" <?php if ($this->filtr->kontragent=='all') { ?> selected="true" <?php } ?> >Все</option>
    <option value="seller" <?php if ($this->filtr->kontragent=='seller') { ?> selected="true" <?php } ?> >Поставщики</option>
    <option value="maker" <?php if ($this->filtr->kontragent=='maker') { ?> selected="true" <?php } ?> >Производители</option>
</select>
-->


    <table class="adminlist table table-striped">
        <tr>
            <?php
                //определить, куда и какую поставить стрелочку сортировки
                if (strlen($this->filtr->orderby)>1){
                    //print_r($this->filtr);
                    if ($this->filtr->desc=='DESC'){
                            $class='down';
                        }else{
                            $class="up";
                        }
                    //
                    $name=$this->filtr->orderby;   
                }
            ?>
            <th class="<?php if ($name=='id') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('id')">ID</span></th>
            <th></th>
            <th></th>
            <th class="<?php if ($name=='name') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('name')">Наименование организации</span></th>
            <th class="<?php if ($name=='town') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('town')">Город</span></th>
            <th class="<?php if ($name=='userid') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('userid')">Userid Joomla!</span></th>
            <th class="<?php if ($name=='username') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('username')">Пользователь Joomla!</span></th>
            <!--
            <th class="<?php if ($name=='seller') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('seller')">Поставщик</span></th>
            <th class="<?php if ($name=='maker') {echo $class;}  ?>"><span class="thtitle" onclick="orderby('maker')">Производитель</span></th>
            -->
        </tr>
        <?php foreach ($this->items as $seller){ ?>
            <tr class="seller<?php echo $seller->id; ?>">
                <td><?php echo $seller->id; ?></td>
                <td><a class="edit" href="<?php echo JRoute::_("index.php?option=com_storecable&view=adminseller&id=".$seller->id."&layout=edituser"); ?>"></a></div></td>
                
                <td><a class="del" onclick="showModalDeleteDialog('<?php echo $seller->id; ?>');"></a></div></td>
                <td><?php echo $seller->name; ?></td>
                <td><?php echo $seller->town; ?></td>
                <td><?php echo $seller->userid; ?></td>
                <td><?php echo $seller->username; ?></td>
                <!--
                <td><?php if ($seller->seller=='1'){echo "ДА";}?></td>
                <td><?php if ($seller->maker=='1'){echo "ДА";}?></td>
                -->
            </tr>
        <?php } ?>
    </table>
    
    
    <div>
        <input type="hidden" name="task" value="" />
        <input type="hidden" name="boxchecked" value="0" />
        <input type="hidden" name="limitstart" value="0">
        <?php echo JHtml::_('form.token'); ?>
    </div>
</form>

<script language="javascript">
//Функции сортировки
    function orderby(param){
        //Поставить противоположную сортировку
        var desc="<?php if ($this->filtr->desc=='ASC') {echo "DESC";} else {echo "ASC";} ?>";
        //Добавить на форму поля сортировки
        jQuery("#adminForm").append('<input type="hidden" name="orderby" value="'+param+'">');
        jQuery("#adminForm").append('<input type="hidden" name="desc" value="'+desc+'">');
        //Отправить форму
        jQuery("#adminForm").submit();
    }
    
//Фильтр по выпадающему списку
function filtrbyseller()
{
    <?php if ($this->filtr->orderby) { ?>
    jQuery("#adminForm").append('<input type="hidden" name="orderby" value="<?php echo $this->filtr->orderby; ?>">');
    jQuery("#adminForm").append('<input type="hidden" name="desc" value="<?php echo $this->filtr->desc; ?>">');
    <?php } ?>
    jQuery("#adminForm").submit();
}    

//Запрос на удалени пользователя
function deleteuser(sellerid){
    //Закрыть модальное окно
    jQuery("#closemodal").click();
    var url='index.php?option=com_storecable&task=adminseller.deleteuser&sellerid='+sellerid;
    console.log(url);
    jQuery.ajax({
        url:url,
        dataType:"json",
        type:"get",
        success:function(data){
            //console.log(data);
            jQuery("tr.seller"+sellerid).remove();
            alert("Пользователь удален");
        },
        error:function(){
            alert("Не поулчилось отправить или обработать запрос");
        }
    })
}
</script>
<!-- Пагинцаия -->
<?php
    echo $this->pagination->getPagesCounter();
    echo $this->pagination->getListFooter();
?>