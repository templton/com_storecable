<?php

// No direct access
defined( '_JEXEC' ) or die;

/**
 * Object Class Table
 * @author Саламатов Дмитрий Викторович
 */
class TableStore_setorder extends JTable
{

	/**
	 * Class constructor
	 * @param Object $db (database link object)
	 */
	function __construct( &$db )
	{
		parent::__construct( '#__store_setorder', 'id', $db );
	}

public function store($updateNulls = false)
    {
        $this->datesend=date('Y-m-d');
        return parent::store($updateNulls);
    }


//Загрузить таблицы со списком документов   
    public function loadFull($sellerid, $orderid=0){
        if ($orderid>0) {$where=' AND `id`="'.$orderid.'" ';}
        $db=JFactory::getDBO();
        $query='SELECT * FROM `#__store_setorder` WHERE `sellerid`="'.$sellerid.'" '.$where.' ORDER BY `datesend`';
        $db->setQuery($query);
        $data=$db->LoadObjectList();
        foreach($data as $item){
            //Добавить загруженные документы
            $query='SELECT * FROM `#__store_doc` WHERE (`flag`="'.$item->id.'" AND `sellerid`="'.$sellerid.'")';
            $db->setQuery($query);
            $doc=$db->LoadObjectList();
            $item->doc=$doc;
            //Добавить имена кабелей
            $cable=explode("|",$item->cableid);
            //print_r($cable);
            foreach ($cable as $cab){
                $item->cables[]=StoreHelper::getCableNameShortOne($cab);
            }
        }
        
        return $data;
    }
//Загрузить таблицу со списком документов и со списком кабелей
    public function LoadAll($sellerid,$orderid){
        $data=self::loadFull($sellerid,$orderid);
        foreach ($data as $item){
            $cable=$item->cableid;
            $cable=explode("|",$cable);
            $count=0;
            foreach ($cable as $cab){
                $item->cables[$count]->cable=StoreHelper::getCableNameShortOne($cab)->cable;
                $item->cables[$count]->cableid=$cab;
                $count++;
            }
        }
        return $data;
    }
    
//Загрузить таблицу со списком документов и со списком кабелей
//и добавить фильтр, если такой кабель уже есть в базе Производителя
    public function LoadAllwithFiltr($sellerid,$orderid){
        //Запросить кабеля из таблицы для данного Производителя
        $db=JFactory::getDBO();
        $query='SELECT `cableid` FROM `#__store_cablemaker` WHERE `makerid`="'.$sellerid.'"';
        $db->setQuery($query);
        $addedCables=$db->LoadAssocList();
        /*
        foreach ($addedCables as $add){
            $mas[]=$add['id'];
        }
        $addedCables=$mas;
        */
        /*
        echo "<pre>";
                print_r($addedCables);
                echo "</pre>";
          */      
                
        
        $data=self::LoadAll($sellerid,$orderid);
        foreach ($data as $item){
            foreach ($item->cables as $cable){
                //$checked='';
                $num=StoreHelper::arraySearch('cableid',$cable->cableid,$addedCables);
                /*
                echo "sad=".$cable->cableid."<br>";
                echo "<pre>";
                print_r($addedCables);
                echo "</pre>";
                echo "<br>";
                */
                
                //echo $num."<br>";
                //echo (int)$num."<br>";
                //echo $this->items[$i]->cableid." - id<br>";
                if ((int)$num>=-1) {$cable->checked='checked="true"';}
                else {$cable->chacked='';}
                /*
                $checkbox='<input type="checkbox" '.$checked.' name="" class="checkboxcable" id="'.$this->items[$i]->cableid.'" onchange="setList(this)" value=""><span class="checkboxlabel" id="'.$this->items[$i]->cableid.'">'.$this->items[$i]->fullname."</span>";
                $this->items[$i]->checkbox=$checkbox;
                $checked='';
                */
            }
        }
        return $data;
    }

}