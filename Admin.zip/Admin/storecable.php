<?php
defined( '_JEXEC' ) or die; // No direct access
/**
 * Component storecable
 * @author Саламатов Дмитрий Викторович
 */
require_once JPATH_SITE.'/components/com_storecable/helpers/helper.php';
require_once JPATH_SITE.'/components/com_storecable/helpers/helperdb.php';

$doc=JFactory::getDocument();
$doc->addStyleSheet(JURI::base().'components/com_storecable/assests/styles/style.css');
$doc->addStyleSheet(JURI::root().'/components/com_storecable/assets/styles/storecable.css');

$doc->addScript(JURI::root()."components/com_storecable/assets/scripts/jquery-2.2.0.min.js");
$doc->addScript(JURI::root()."components/com_storecable/assets/scripts/helper.js");
$doc->addScript(JURI::root()."components/com_storecable/assets/scripts/jquery.maskedinput-1.2.2.js");

//Виджет автозавершения ввода
            $doc->addScript(JURI::root()."components/com_storecable/assets/scripts/ui/jquery-ui.min.js");
            $doc->addStyleSheet(JURI::root()."components/com_storecable/assets/styles/ui/jquery-ui.min.css");
//Дополнительные функции
$doc->addScriptDeclaration('var SiteUrl="'.JURI::root().'"');


$controller = JControllerLegacy::getInstance( 'storecable' );
$controller->execute( JFactory::getApplication()->input->get( 'task' ) );
$controller->redirect();