<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку modellist Joomla.
jimport('joomla.application.component.modellist');
 
/**
 * Модель списка сообщений компонента HelloWorld.
 */
class StorecableModelAdminlistorder extends JModelList
{

public function cancel(){
        $this->setRedirect(JRoute::_("index.php?option=com_storecable&view=adminlistorders"));
        return false;
    }
    
//Получить детализацию ордера
    public function getOrder(){
        $table=$this->getTable('store_setorder');
        $data=$table->LoadAllwithFiltr($_GET['sellerid'],$_GET['orderid']);
        $data=$data[0];
        return $data;
    }    
    
public function saveorder()
{
    echo "SAD";
    $this->setRedirect(JRoute::_("index.php?option=com_storecable&view=adminlistorders"));
}    

public function getform()
{
    
} 
    

}