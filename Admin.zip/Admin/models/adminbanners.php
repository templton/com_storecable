<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку modellist Joomla.
jimport('joomla.application.component.modellist');
 
/**
 * Модель списка сообщений компонента HelloWorld.
 */
class StorecableModelAdminbanners extends JModelList
{
    /**
     * Метод для построения SQL запроса для загрузки списка данных.
     *
     * @return  string  SQL запрос.
     */
    protected function getListQuery()
    {
        //Параметры фильтров
        $param=self::getFiltr();
        //print_r($param);echo "<br>";
        
        //Запрос
        $query=StoreHelper::getBannerOrdersAll(1,$param);
        //echo $query;
        return $query;
    }
    
    //Поучить параметры фильтров
    public function getFiltr()
    {
        //print_r($_POST);
        $param=new stdClass();
        //$param->kontragent=JRequest::getVar('kontragent');
        if (JRequest::getVar('orderby')){
            $param->orderby=JRequest::getVar('orderby');
            $param->desc=JRequest::getVar('desc');   
        }
        return $param;
    }
}