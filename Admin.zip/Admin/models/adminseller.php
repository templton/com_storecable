<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку modellist Joomla.
jimport('joomla.application.component.modellist');

class StorecableModelAdminseller extends JModelList
{
    
protected function getListQuery(){
    $query=StoreHelper::getMakerCableQuery(JRequest::getVar('id'));
    return $query;
}     
    
    public function cancel(){
        $this->setRedirect(JRoute::_("index.php?option=com_storecable&view=adminsellers"));
        return false;
    }
    
    public function getSeller()
    {
        $data=StoreHelper::getDataSeller(0,JRequest::getVar('id'));
        /*
        //Разбить телефоны
        if (($data->phone)){
            $data->phone=explode('|',$data->phone);   
        }else{
            unset($data->phone);
        }
        //Разбить мыло
        
        //echo $data->email." - мыло";
        
        $data->email=explode('|',$data->email);
        //Разбить график работы
        $data->mode=explode('|',$data->mode);
        /*
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        */
        return $data;
    }

}