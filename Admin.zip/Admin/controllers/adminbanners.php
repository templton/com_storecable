<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку controlleradmin Joomla.
jimport('joomla.application.component.controlleradmin');
 
/**
 * HelloWorlds контроллер.
 */
class StorecableControllerAdminbanners extends JControllerAdmin
{

    
//Обновить примечание
public function setDescription(){
    $res=new stdClass();
    $res->get=$_GET;
    $text=JRequest::getVar('text');
    $id=JRequest::getVar('orderid');
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->update('`#__store_banner`')->set('`description`='.$db->quote($text).'')->where('`id`="'.$id.'"');
    $db->setQuery($query);
    $db->execute();
    echo json_encode($res);
    jExit();
}

//Подтвердить заявку
public function orderOk(){
    $res=new stdClass();
    $res->get=$_GET;
    $res->id=$_GET['id'];
    $status=JRequest::getVar('status');
    $id=JRequest::getVar('orderid');
    if ($status=='1'){
        $datebegin=date('Y-m-d');
        $dateend=date('Y-m-d',strtotime("now")+JRequest::getVar('period')*24*3600);
        $res->datebegin=$datebegin;
        $res->dateend=$dateend;
        $res->period=JRequest::getVar('period');
    }else{
        $datebegin='';
        $dateend='';
    }   
    $fields=array(
        '`status`="'.$status.'"',
        '`datebegin`="'.$datebegin.'"',
        '`dateend`="'.$dateend.'"'
    );
    //$period=
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $query->update('`#__store_banner`')->set($fields)->where('`id`="'.$id.'"');
    $db->setQuery($query);
    $db->execute();
    echo json_encode($res);
    jExit();
}


//Удалить заявку
public function deleteorder(){
    $res=new stdClass();
    $db=JFactory::getDBO();
    $query='DELETE FROM `#__store_banner` WHERE `id`="'.$_GET['orderid'].'"';
    $db->setQuery($query);
    $res->result=$db->execute();
    echo json_encode($res);
    jExit();
    
}
    
}