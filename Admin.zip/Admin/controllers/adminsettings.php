<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку controlleradmin Joomla.
jimport('joomla.application.component.controlleradmin');


class StorecableControllerAdminsettings extends JControllerForm
{
    
public function display($cachable = false, $urlparams = false) {
		parent::display();
	}
    
public function editdata(){
    $db=JFactory::getDBO();
    /*
    echo "<pre>";
    print_r($_GET);
    echo "</pre>";
*/
    $query=$db->getQuery(true);
    $query->update('`#__store_settings`')
        ->set(array($db->quoteName('val').'='.$db->quote($_GET['adminemail'])))
        ->where('`name` LIKE "adminemail"');
    $db->setQuery($query)->execute();
    
    $query=$db->getQuery(true);
    $query->update('`#__store_settings`')
        ->set(array($db->quoteName('val').'='.$db->quote($_GET['answeremail'])))
        ->where('`name` LIKE "answeremail"');
    $db->setQuery($query)->execute();
    
    $query=$db->getQuery(true);
    $query->update('`#__store_settings`')
        ->set(array($db->quoteName('val').'='.$db->quote($_GET['answername'])))
        ->where('`name` LIKE "answername"');
    $db->setQuery($query)->execute();
    
    $query=$db->getQuery(true);
    $query->update('`#__store_settings`')
        ->set(array($db->quoteName('val').'='.$db->quote($_GET['helpmakerid'])))
        ->where('`name` LIKE "helpmakerid"');
    $db->setQuery($query)->execute();
    
    $query=$db->getQuery(true);
    $query->update('`#__store_settings`')
        ->set(array($db->quoteName('val').'='.$db->quote($_GET['helpbannerid'])))
        ->where('`name` LIKE "helpbannerid"');
    $db->setQuery($query)->execute();
    
    $query=$db->getQuery(true);
    $query->update('`#__store_settings`')
        ->set(array($db->quoteName('val').'='.$db->quote($_GET['showprice'])))
        ->where('`name` LIKE "showprice"');
    $db->setQuery($query)->execute();
    
    
    $_SESSION['errmess']="Данные обновлены";
    
    self::display();
}


}