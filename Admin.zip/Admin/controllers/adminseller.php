<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку controlleradmin Joomla.
jimport('joomla.application.component.controlleradmin');


class StorecableControllerAdminseller extends JControllerForm
{
    
public function display($cachable = false, $urlparams = false) {
		parent::display();
	}

//Внести кабель в базу Производителя
    public function addmakercable(){
        $res=new stdClass();
        $cond=new stdClass();
        $res->get=$_GET;//Вернем список GET для отладки
        $cond->makerid=JRequest::getVar('makerid');
        $cond->cableid=StoreHelper::getIdCable(JRequest::getVar('cable'));
        //Если кабель не найден
        if ($cond->cableid==0){
            $res->result=new stdClass();
            $res->result->result='0';
            $res->result->error='1';
            $res->result->errmess='Кабель '.JRequest::getVar('cable').' не найден. Проверьте правильность написания наименования кабеля. Либо такого кабеля еще нет в базе данных.';
            echo json_encode($res);
            jExit();
        }
        $res->result=StoreHelper::addMakerCable($cond);
        echo json_encode($res);
        jExit();
    }
    
//Удалить запись из таблицы Производителя
public function deleteitem(){
    $res=new stdClass();
    $res->get=$_GET;
    $res->result=new stdClass();
    if (StoreHelperDB::delete('store_cablemaker',JRequest::getVar('id'))){
        $res->result->result='1';
    }else
    {
        $res->result->result='0';
    }
    echo json_encode($res);
    jExit();
}    

//Удалить контрагента
public function deleteuser(){
    $res=new stdClass();
    $res->get=$_GET;
    $sellerid=JRequest::getVar('sellerid');
    $res->sellerid=$sellerid;
    $res->result=StoreHelper::deleteUser($sellerid);
    echo json_encode($res);
    jExit();    
}

//Привязать нового пользователя к учетной записи Контрагента
public function relativeuser(){
    //id привязываемого пользователя
    $userid=JRequest::getVar('newuser');
    if ($userid==0){return;}
    //id Контрагента
    $sellerid=JRequest::getVar('sellerid');
    StoreHelper::setRelativeUser($sellerid,$userid);
    self::display();
}

//Отвязать пользователя
public function unrelativeuser(){
    $sellerid=JRequest::getVar('sellerid');
    if ($sellerid==0){return;}
    StoreHelper::unsetRelativeUser($sellerid);
    self::display();
}

}