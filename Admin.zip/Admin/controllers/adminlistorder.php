<?php
// Запрет прямого доступа.
defined('_JEXEC') or die;
 
// Подключаем библиотеку controlleradmin Joomla.
jimport('joomla.application.component.controlleradmin');


class StorecableControllerAdminlistorder extends JControllerForm
{
    
public function display($cachable = false, $urlparams = false) {
		parent::display();
	}
    
public function saveorder(){
    $cables=$_GET['cables'];
    $cond=new stdClass();
    $cond->makerid=$_GET['sellerid'];
    
    $cables=explode("|",$cables);
    foreach($cables as $cable){
        if ($_GET['cableid'.$cable]=='on'){
            //те, что отмечены - добавить
            $cond->cableid=$cable;
            $res=StoreHelper::addMakerCable($cond);
           // print_r($res);
        }else{
            //которые не отмечены - удалить из таблицы
            
            $cond->cableid=$cable;
            $res=StoreHelper::deleteMakerCable($cond);
            //print_r($res);
        }
    }
    
    //Обновить запись заявки
    $db=JFactory::getDBO();
    $query=$db->getQuery(true);
    $fields=array(
        $db->quoteName('status').'='.$db->quote($_GET['status']),
        $db->quoteName('description').'='.$db->quote($_GET['description']),
        $db->quoteName('datefeatured').'='.$db->quote(date('Y-m-d'))
    );
    $query->update('`#__store_setorder`')->set($fields)->where('`id`="'.$_GET['orderid'].'"');
    $db->setQuery($query);
    $db->execute();
    
    
    
    header("Location:index.php?option=com_storecable&view=adminlistorders");
    /*
    echo "<pre>";
    print_r($_GET);
    echo "</pre>";
    */
    
}    

}