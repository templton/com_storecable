<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author Саламатов Дмитрий Викторович
 */
class StorecableControllerAdminvid1 extends JControllerLegacy
{

}